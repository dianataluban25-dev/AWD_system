import{r as l,j as n,a as nn,R as qn,c as Bn}from"./vendor-Ch-GEUUF.js";(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const c of document.querySelectorAll('link[rel="modulepreload"]'))g(c);new MutationObserver(c=>{for(const u of c)if(u.type==="childList")for(const m of u.addedNodes)m.tagName==="LINK"&&m.rel==="modulepreload"&&g(m)}).observe(document,{childList:!0,subtree:!0});function o(c){const u={};return c.integrity&&(u.integrity=c.integrity),c.referrerPolicy&&(u.referrerPolicy=c.referrerPolicy),c.crossOrigin==="use-credentials"?u.credentials="include":c.crossOrigin==="anonymous"?u.credentials="omit":u.credentials="same-origin",u}function g(c){if(c.ep)return;c.ep=!0;const u=o(c);fetch(c.href,u)}})();function Un({fetcher:e=fetch,storage:a=sessionStorage}={}){const o="elee.staff.token";async function g(c,{method:u="GET",body:m,token:x=a.getItem(o)}={}){const t=await e(`/api/${c}`,{method:u,headers:{Accept:"application/json",...m?{"Content-Type":"application/json"}:{},...x?{Authorization:`Bearer ${x}`}:{}},...m?{body:JSON.stringify(m)}:{},signal:AbortSignal.timeout(15e3)}),s=t.status===204?null:await t.json();if(!t.ok){const h=new Error(Object.values((s==null?void 0:s.errors)||{}).flat()[0]||(s==null?void 0:s.message)||"Request failed. Please retry.");throw h.status=t.status,h}return s}return{request:g,hasToken:()=>!!a.getItem(o),forget:()=>a.removeItem(o),async login(c,u){const m=await g("staff/login",{method:"POST",token:null,body:{email:c,password:u}});return a.setItem(o,m.token),m.user},async all(c){var m;const u=[];for(let x=1;;x++){const t=await g(`${c}${c.includes("?")?"&":"?"}page=${x}`);if(u.push(...t.data),!((m=t.links)!=null&&m.next))return u}}}}const Fn=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
\r
    <title>EleeSiWeb - Admin Login</title>\r
\r
    <style>\r
\r
        * {\r
            box-sizing: border-box;\r
            margin: 0;\r
            padding: 0;\r
        }\r
\r
        body {\r
            font-family: Arial, Helvetica, sans-serif;\r
            background: #f4f7f5;\r
            min-height: 100vh;\r
\r
            display: flex;\r
            justify-content: center;\r
            align-items: center;\r
        }\r
\r
        .login-container {\r
            width: 420px;\r
            max-width: 90%;\r
        }\r
\r
        .login-card {\r
            background: white;\r
            border-radius: 14px;\r
            padding: 40px;\r
            box-shadow: 0 8px 30px rgba(0,0,0,0.10);\r
        }\r
\r
        /* ================= LOGO ================= */\r
\r
        .logo {\r
            text-align: center;\r
            font-size: 42px;\r
            font-weight: 900;\r
            letter-spacing: -3px;\r
            color: #ffbd00;\r
            margin-bottom: 3px;\r
        }\r
\r
        .logo span {\r
            color: #00551f;\r
        }\r
\r
        .hardware {\r
            text-align: center;\r
            color: #ffbd00;\r
            font-size: 13px;\r
            font-weight: bold;\r
            letter-spacing: 1px;\r
            margin-bottom: 30px;\r
        }\r
\r
        /* ================= TITLE ================= */\r
\r
        .login-title {\r
            text-align: center;\r
            color: #147a36;\r
            font-size: 27px;\r
            font-weight: 600;\r
            margin-bottom: 7px;\r
        }\r
\r
        .login-subtitle {\r
            text-align: center;\r
            color: #777;\r
            font-size: 14px;\r
            margin-bottom: 28px;\r
        }\r
\r
        /* ================= FORM ================= */\r
\r
        .form-group {\r
            margin-bottom: 18px;\r
        }\r
\r
        .form-group label {\r
            display: block;\r
            font-size: 14px;\r
            font-weight: 600;\r
            color: #333;\r
            margin-bottom: 7px;\r
        }\r
\r
        .form-group input {\r
            width: 100%;\r
            height: 48px;\r
            border: 1px solid #d8d8d8;\r
            border-radius: 8px;\r
            padding: 0 14px;\r
            font-size: 15px;\r
            outline: none;\r
        }\r
\r
        .form-group input:focus {\r
            border-color: #299b4d;\r
            box-shadow: 0 0 0 3px rgba(41,155,77,0.10);\r
        }\r
\r
        /* ================= PASSWORD ================= */\r
\r
        .password-wrapper {\r
            position: relative;\r
        }\r
\r
        .password-wrapper input {\r
            padding-right: 50px;\r
        }\r
\r
        .show-password {\r
            position: absolute;\r
            right: 14px;\r
            top: 50%;\r
            transform: translateY(-50%);\r
\r
            border: none;\r
            background: transparent;\r
            cursor: pointer;\r
\r
            font-size: 18px;\r
            color: #777;\r
        }\r
\r
        /* ================= REMEMBER ================= */\r
\r
        .remember {\r
            display: flex;\r
            align-items: center;\r
            gap: 8px;\r
            margin-bottom: 22px;\r
            font-size: 13px;\r
            color: #555;\r
        }\r
\r
        .remember input {\r
            width: 15px;\r
            height: 15px;\r
            accent-color: #08752f;\r
        }\r
\r
        /* ================= LOGIN BUTTON ================= */\r
\r
        .login-btn {\r
            width: 100%;\r
            height: 48px;\r
\r
            background: #08752f;\r
            color: white;\r
\r
            border: none;\r
            border-radius: 8px;\r
\r
            font-size: 15px;\r
            font-weight: 600;\r
\r
            cursor: pointer;\r
            transition: 0.2s;\r
        }\r
\r
        .login-btn:hover {\r
            background: #065b25;\r
        }\r
\r
        /* ================= ERROR ================= */\r
\r
        .error-message {\r
            background: #ffe3e3;\r
            color: #c62828;\r
            border: 1px solid #ffc7c7;\r
\r
            padding: 10px 12px;\r
            border-radius: 7px;\r
\r
            font-size: 13px;\r
            margin-bottom: 18px;\r
        }\r
\r
        /* ================= FOOTER ================= */\r
\r
        .footer {\r
            text-align: center;\r
            margin-top: 22px;\r
            color: #999;\r
            font-size: 12px;\r
        }\r
\r
        @media(max-width: 500px) {\r
\r
            .login-card {\r
                padding: 30px 25px;\r
            }\r
\r
            .logo {\r
                font-size: 36px;\r
            }\r
\r
            .login-title {\r
                font-size: 24px;\r
            }\r
        }\r
\r
    </style>\r
</head>\r
\r
<body>\r
\r
    <div class="login-container">\r
\r
        <div class="login-card">\r
\r
            <!-- LOGO -->\r
\r
            <div class="logo">\r
                <span>E</span>LEE\r
            </div>\r
\r
            <div class="hardware">\r
                HARDWARE\r
            </div>\r
\r
\r
            <!-- TITLE -->\r
\r
            <div class="login-title">\r
                Admin Login\r
            </div>\r
\r
            <div class="login-subtitle">\r
                Sign in to access the EleeSiWeb admin system\r
            </div>\r
\r
\r
            <!-- ERROR MESSAGE -->\r
\r
            @if(session('error'))\r
\r
                <div class="error-message">\r
                    {{ session('error') }}\r
                </div>\r
\r
            @endif\r
\r
\r
            <!-- LOGIN FORM -->\r
\r
            <form action="{{ url('/admin/login') }}" method="POST">\r
\r
                @csrf\r
\r
\r
                <!-- USERNAME -->\r
\r
                <div class="form-group">\r
\r
                    <label for="username">\r
                        Username\r
                    </label>\r
\r
                    <input\r
                        type="text"\r
                        id="username"\r
                        name="username"\r
                        placeholder="Enter admin username"\r
                        required\r
                    >\r
\r
                </div>\r
\r
\r
                <!-- PASSWORD -->\r
\r
                <div class="form-group">\r
\r
                    <label for="password">\r
                        Password\r
                    </label>\r
\r
                    <div class="password-wrapper">\r
\r
                        <input\r
                            type="password"\r
                            id="password"\r
                            name="password"\r
                            placeholder="Enter admin password"\r
                            required\r
                        >\r
\r
                        <button\r
                            type="button"\r
                            class="show-password"\r
                            onclick="togglePassword()">\r
                            👁\r
                        </button>\r
\r
                    </div>\r
\r
                </div>\r
\r
\r
                <!-- REMEMBER -->\r
\r
                <div class="remember">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="remember"\r
                        name="remember"\r
                    >\r
\r
                    <label for="remember">\r
                        Remember me\r
                    </label>\r
\r
                </div>\r
\r
\r
                <!-- LOGIN -->\r
\r
                <button\r
                    type="submit"\r
                    class="login-btn">\r
\r
                    Login \r
\r
                </button>\r
\r
            </form>\r
\r
\r
            <div class="footer">\r
                EleeSiWeb Admin System\r
            </div>\r
\r
        </div>\r
\r
    </div>\r
\r
\r
    \r
\r
</body>\r
</html>`,Hn=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
    <title>AI Recommendations - ELEE Hardware</title>\r
\r
    <style>\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
            font-family: Arial, Helvetica, sans-serif;\r
        }\r
\r
        body {\r
            background: #f5f7f6;\r
            min-height: 100vh;\r
        }\r
\r
        .dashboard {\r
            display: flex;\r
            width: 100%;\r
            min-height: 100vh;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            flex-shrink: 0;\r
            z-index: 1000;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .menu-icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= CONTENT ================= */\r
\r
        .content {\r
            background: #f8faf9;\r
            flex: 1;\r
            min-height: 100vh;\r
            margin-left: 235px;\r
            padding: 35px 40px;\r
            overflow-x: hidden;\r
        }\r
\r
        .page-header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: flex-start;\r
            gap: 20px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .page-title {\r
            color: #19803c;\r
            font-size: 28px;\r
            font-weight: 700;\r
            margin-bottom: 5px;\r
        }\r
\r
        .page-subtitle {\r
            color: #888;\r
            font-size: 14px;\r
        }\r
\r
        .add-btn {\r
            background: #069b45;\r
            border: none;\r
            color: white;\r
            padding: 12px 18px;\r
            border-radius: 8px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            font-weight: 600;\r
            transition: 0.2s;\r
        }\r
\r
        .add-btn:hover {\r
            background: #057c37;\r
        }\r
\r
        /* ================= SUMMARY ================= */\r
\r
        .summary {\r
            display: grid;\r
            grid-template-columns: repeat(3, 1fr);\r
            gap: 15px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .summary-card {\r
            background: white;\r
            border: 1px solid #e5e8e6;\r
            border-radius: 12px;\r
            padding: 18px;\r
            display: flex;\r
            align-items: center;\r
            gap: 14px;\r
        }\r
\r
        .summary-icon {\r
            width: 45px;\r
            height: 45px;\r
            border-radius: 10px;\r
            background: #e7f8ec;\r
            color: #08752a;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-size: 21px;\r
        }\r
\r
        .summary-info small {\r
            display: block;\r
            color: #999;\r
            font-size: 12px;\r
            margin-bottom: 4px;\r
        }\r
\r
        .summary-info strong {\r
            color: #222;\r
            font-size: 20px;\r
        }\r
\r
        /* ================= SEARCH ================= */\r
\r
        .search-section {\r
            background: white;\r
            border: 1px solid #e5e8e6;\r
            border-radius: 12px;\r
            padding: 15px;\r
            margin-bottom: 20px;\r
        }\r
\r
        .search-box {\r
            position: relative;\r
        }\r
\r
        .search-box input {\r
            width: 100%;\r
            height: 42px;\r
            border: 1px solid #ddd;\r
            border-radius: 8px;\r
            padding: 0 15px 0 40px;\r
            outline: none;\r
            font-size: 13px;\r
        }\r
\r
        .search-box input:focus {\r
            border-color: #19803c;\r
        }\r
\r
        .search-icon {\r
            position: absolute;\r
            left: 14px;\r
            top: 12px;\r
            color: #999;\r
        }\r
\r
        /* ================= MAIN RECOMMENDATION ================= */\r
\r
        .recommendation-wrapper {\r
            display: flex;\r
            gap: 18px;\r
            align-items: stretch;\r
        }\r
\r
        /* ================= TRIGGER PRODUCT ================= */\r
\r
        .trigger-box {\r
            width: 220px;\r
            border: 1px solid #e2e6e3;\r
            border-radius: 13px;\r
            overflow: hidden;\r
            background: white;\r
            flex-shrink: 0;\r
        }\r
\r
        .trigger-title {\r
            height: 60px;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 20px;\r
            color: #444;\r
            font-size: 15px;\r
            font-weight: 700;\r
            border-bottom: 1px solid #eeeeee;\r
        }\r
\r
        .trigger-subtitle {\r
            padding: 12px 20px;\r
            color: #999;\r
            font-size: 11px;\r
            border-bottom: 1px solid #f1f1f1;\r
        }\r
\r
        .trigger-list {\r
            display: flex;\r
            flex-direction: column;\r
            max-height: 480px;\r
            overflow-y: auto;\r
        }\r
\r
        .trigger-item {\r
            width: 100%;\r
            border: none;\r
            background: white;\r
            text-align: left;\r
            padding: 14px 16px;\r
            min-height: 55px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: space-between;\r
            font-size: 13px;\r
            color: #222;\r
            border-bottom: 1px solid #f1f1f1;\r
            cursor: pointer;\r
            transition: 0.2s;\r
        }\r
\r
        .trigger-item:hover {\r
            background: #f1faee;\r
        }\r
\r
        .trigger-item.active {\r
            background: #d9f5ce;\r
            color: #08752a;\r
            font-weight: 700;\r
            border-left: 4px solid #069b45;\r
        }\r
\r
        .trigger-count {\r
            background: #e9e9e9;\r
            color: #777;\r
            border-radius: 20px;\r
            padding: 3px 8px;\r
            font-size: 10px;\r
        }\r
\r
        .trigger-item.active .trigger-count {\r
            background: #b9e9aa;\r
            color: #08752a;\r
        }\r
\r
        /* ================= RECOMMENDED ================= */\r
\r
        .recommended-box {\r
            flex: 1;\r
            border: 1px solid #e2e6e3;\r
            border-radius: 13px;\r
            padding: 22px;\r
            background: white;\r
            min-height: 500px;\r
        }\r
\r
        .recommended-header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: flex-start;\r
            gap: 15px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .recommended-title {\r
            font-size: 20px;\r
            font-weight: 700;\r
            color: #111;\r
        }\r
\r
        .recommended-subtitle {\r
            color: #999;\r
            font-size: 13px;\r
            margin-top: 5px;\r
        }\r
\r
        .current-trigger {\r
            background: #e8f7ec;\r
            color: #19803c;\r
            border-radius: 20px;\r
            padding: 7px 12px;\r
            font-size: 11px;\r
            font-weight: 600;\r
            white-space: nowrap;\r
        }\r
\r
        .product-grid {\r
            display: grid;\r
            grid-template-columns: repeat(3, 1fr);\r
            gap: 16px;\r
        }\r
\r
        /* ================= PRODUCT CARD ================= */\r
\r
        .product-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 12px;\r
            overflow: hidden;\r
            background: #fff;\r
            min-height: 300px;\r
            display: flex;\r
            flex-direction: column;\r
            transition: 0.2s;\r
        }\r
\r
        .product-card:hover {\r
            transform: translateY(-3px);\r
            box-shadow: 0 6px 18px rgba(0,0,0,0.09);\r
            border-color: #2c984d;\r
        }\r
\r
        .product-image-wrapper {\r
            position: relative;\r
            height: 145px;\r
            background: #f2f2f2;\r
            overflow: hidden;\r
        }\r
\r
        .product-image {\r
            width: 100%;\r
            height: 100%;\r
            object-fit: cover;\r
            display: block;\r
        }\r
\r
        .recommend-badge {\r
            position: absolute;\r
            top: 9px;\r
            left: 9px;\r
            background: #19803c;\r
            color: white;\r
            padding: 5px 8px;\r
            border-radius: 6px;\r
            font-size: 9px;\r
            font-weight: bold;\r
        }\r
\r
        .product-info {\r
            padding: 12px;\r
            flex: 1;\r
            display: flex;\r
            flex-direction: column;\r
        }\r
\r
        .product-name {\r
            font-size: 14px;\r
            font-weight: 700;\r
            color: #111;\r
            line-height: 1.3;\r
            margin-bottom: 6px;\r
        }\r
\r
        .product-category {\r
            font-size: 11px;\r
            color: #999;\r
            margin-bottom: 8px;\r
        }\r
\r
        .product-price {\r
            font-size: 15px;\r
            font-weight: 700;\r
            color: #19803c;\r
            margin-top: auto;\r
        }\r
\r
        .card-actions {\r
            display: flex;\r
            gap: 6px;\r
            margin-top: 10px;\r
        }\r
\r
        .card-btn {\r
            flex: 1;\r
            border: none;\r
            border-radius: 6px;\r
            padding: 8px 5px;\r
            cursor: pointer;\r
            font-size: 11px;\r
            font-weight: 600;\r
        }\r
\r
        .view-btn {\r
            background: #eef7f0;\r
            color: #19803c;\r
        }\r
\r
        .edit-btn {\r
            background: #fff5d8;\r
            color: #9a7100;\r
        }\r
\r
        .delete-btn {\r
            background: #ffe9e9;\r
            color: #c62828;\r
        }\r
\r
        .card-btn:hover {\r
            opacity: 0.8;\r
        }\r
\r
        /* ================= EMPTY ================= */\r
\r
        .empty-state {\r
            display: none;\r
            text-align: center;\r
            padding: 60px 20px;\r
            color: #999;\r
        }\r
\r
        .empty-state .empty-icon {\r
            font-size: 45px;\r
            margin-bottom: 12px;\r
        }\r
\r
        .empty-state h3 {\r
            color: #555;\r
            margin-bottom: 5px;\r
        }\r
\r
        /* ================= INFO ================= */\r
\r
        .info-box {\r
            margin-top: 22px;\r
            background: #c9f0d5;\r
            border-radius: 13px;\r
            min-height: 70px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            text-align: center;\r
            padding: 15px 20px;\r
        }\r
\r
        .info-box p {\r
            color: #258642;\r
            font-size: 13px;\r
            font-weight: 600;\r
        }\r
\r
        /* ================= MODAL ================= */\r
\r
        .modal {\r
            display: none;\r
            position: fixed;\r
            inset: 0;\r
            background: rgba(0,0,0,0.55);\r
            justify-content: center;\r
            align-items: center;\r
            z-index: 9999;\r
            padding: 20px;\r
        }\r
\r
        .modal.show {\r
            display: flex;\r
        }\r
\r
        .modal-content {\r
            width: 470px;\r
            max-width: 100%;\r
            max-height: 90vh;\r
            overflow-y: auto;\r
            background: white;\r
            border-radius: 15px;\r
            padding: 25px;\r
            position: relative;\r
        }\r
\r
        .modal-header {\r
            margin-bottom: 20px;\r
        }\r
\r
        .modal-header h2 {\r
            color: #19803c;\r
            font-size: 21px;\r
            margin-bottom: 5px;\r
        }\r
\r
        .modal-header p {\r
            color: #999;\r
            font-size: 12px;\r
        }\r
\r
        .close-modal {\r
            position: absolute;\r
            top: 12px;\r
            right: 15px;\r
            border: none;\r
            background: transparent;\r
            font-size: 25px;\r
            cursor: pointer;\r
            color: #555;\r
        }\r
\r
        .form-group {\r
            margin-bottom: 14px;\r
        }\r
\r
        .form-group label {\r
            display: block;\r
            color: #444;\r
            font-size: 12px;\r
            font-weight: 600;\r
            margin-bottom: 6px;\r
        }\r
\r
        .form-group input,\r
        .form-group select {\r
            width: 100%;\r
            height: 40px;\r
            border: 1px solid #ddd;\r
            border-radius: 7px;\r
            padding: 0 11px;\r
            outline: none;\r
            font-size: 13px;\r
        }\r
\r
        .form-group input:focus,\r
        .form-group select:focus {\r
            border-color: #19803c;\r
        }\r
\r
        .image-preview {\r
            width: 100%;\r
            height: 150px;\r
            border: 1px dashed #ccc;\r
            border-radius: 9px;\r
            margin-top: 8px;\r
            overflow: hidden;\r
            background: #f5f5f5;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            color: #999;\r
            font-size: 12px;\r
        }\r
\r
        .image-preview img {\r
            width: 100%;\r
            height: 100%;\r
            object-fit: cover;\r
        }\r
\r
        .modal-actions {\r
            display: flex;\r
            gap: 10px;\r
            margin-top: 20px;\r
        }\r
\r
        .save-btn,\r
        .cancel-btn {\r
            flex: 1;\r
            height: 42px;\r
            border: none;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            font-weight: 600;\r
        }\r
\r
        .save-btn {\r
            background: #069b45;\r
            color: white;\r
        }\r
\r
        .cancel-btn {\r
            background: #eeeeee;\r
            color: #555;\r
        }\r
\r
        /* ================= PRODUCT DETAILS MODAL ================= */\r
\r
        .details-modal-content {\r
            width: 420px;\r
            text-align: center;\r
        }\r
\r
        .details-modal-content img {\r
            width: 100%;\r
            height: 230px;\r
            object-fit: cover;\r
            border-radius: 10px;\r
            margin-bottom: 15px;\r
        }\r
\r
        .details-modal-content h2 {\r
            color: #111;\r
            margin-bottom: 7px;\r
        }\r
\r
        .details-modal-content p {\r
            color: #777;\r
            margin-bottom: 8px;\r
            font-size: 13px;\r
        }\r
\r
        .modal-price {\r
            font-size: 21px;\r
            font-weight: bold;\r
            color: #19803c;\r
            margin-bottom: 15px;\r
        }\r
\r
        .relation-label {\r
            display: inline-block;\r
            background: #e7f8ec;\r
            color: #19803c;\r
            padding: 6px 10px;\r
            border-radius: 20px;\r
            font-size: 11px;\r
            font-weight: 600;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media (max-width: 1100px) {\r
            .product-grid {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
            .summary {\r
                grid-template-columns: repeat(3, 1fr);\r
            }\r
        }\r
\r
        @media (max-width: 850px) {\r
            .sidebar {\r
                width: 190px;\r
            }\r
\r
            .content {\r
                margin-left: 190px;\r
                padding: 30px 20px;\r
            }\r
\r
            .recommendation-wrapper {\r
                flex-direction: column;\r
            }\r
\r
            .trigger-box {\r
                width: 100%;\r
            }\r
\r
            .trigger-list {\r
                max-height: 250px;\r
            }\r
\r
            .trigger-item {\r
                min-height: 48px;\r
            }\r
        }\r
\r
        @media (max-width: 650px) {\r
            .dashboard {\r
                flex-direction: column;\r
            }\r
\r
            .sidebar {\r
                display: none;\r
            }\r
\r
            .content {\r
                margin-left: 0;\r
            }\r
\r
            .page-header {\r
                flex-direction: column;\r
            }\r
\r
            .add-btn {\r
                width: 100%;\r
            }\r
\r
            .summary {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .product-grid {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .recommended-header {\r
                flex-direction: column;\r
            }\r
        }\r
    </style>\r
</head>\r
\r
<body>\r
\r
<div class="dashboard">\r
\r
    <!-- ================= SIDEBAR ================= -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <nav class="menu">\r
\r
            <a href="{{ url('/dashboard') }}">\r
                <span class="menu-icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="menu-icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}">\r
                <span class="menu-icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}" class="active">\r
                <span class="menu-icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}">\r
                <span class="menu-icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}">\r
                <span class="menu-icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="menu-icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}">\r
                <span class="menu-icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="menu-icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </nav>\r
    </aside>\r
\r
\r
    <!-- ================= MAIN CONTENT ================= -->\r
\r
    <main class="content">\r
\r
        <div class="page-header">\r
\r
            <div>\r
                <h1 class="page-title">\r
                    AI Recommendations\r
                </h1>\r
\r
                <p class="page-subtitle">\r
                    Manage related products used for AI-assisted product recommendations\r
                </p>\r
            </div>\r
\r
            <button class="add-btn" onclick="openAddModal()">\r
                + Add Recommendation\r
            </button>\r
\r
        </div>\r
\r
\r
        <!-- ================= SUMMARY ================= -->\r
\r
        <div class="summary">\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ♧\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Trigger Products</small>\r
                    <strong id="triggerCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ◈\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Recommended Products</small>\r
                    <strong id="recommendationCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ✓\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Recommendation Links</small>\r
                    <strong id="linkCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= SEARCH ================= -->\r
\r
        <div class="search-section">\r
\r
            <div class="search-box">\r
\r
                <span class="search-icon">⌕</span>\r
\r
                <input\r
                    type="text"\r
                    id="searchInput"\r
                    placeholder="Search trigger or recommended product..."\r
                    oninput="searchRecommendations()"\r
                >\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= RECOMMENDATION AREA ================= -->\r
\r
        <div class="recommendation-wrapper">\r
\r
            <div class="trigger-box">\r
\r
                <div class="trigger-title">\r
                    Trigger Products\r
                </div>\r
\r
                <div class="trigger-subtitle">\r
                    Select a product to see its related recommendations.\r
                </div>\r
\r
                <div class="trigger-list" id="triggerList">\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="recommended-box">\r
\r
                <div class="recommended-header">\r
\r
                    <div>\r
\r
                        <h2 class="recommended-title">\r
                            Recommended Products\r
                        </h2>\r
\r
                        <p class="recommended-subtitle" id="recommendationText">\r
                            Products that will be suggested when the selected item is added to cart.\r
                        </p>\r
\r
                    </div>\r
\r
                    <div class="current-trigger" id="currentTrigger">\r
                        No trigger selected\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="product-grid" id="productGrid">\r
                </div>\r
\r
\r
                <div class="empty-state" id="emptyState">\r
\r
                    <div class="empty-icon">\r
                        ♧\r
                    </div>\r
\r
                    <h3>\r
                        No Recommendations Yet\r
                    </h3>\r
\r
                    <p>\r
                        Add related products for this trigger product.\r
                    </p>\r
\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= INFO ================= -->\r
\r
        <div class="info-box">\r
\r
            <p>\r
                AI recommendations help customers discover related products based on the item they are viewing or adding to their cart.\r
            </p>\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
\r
<!-- ================= ADD / EDIT MODAL ================= -->\r
\r
<div class="modal" id="recommendationModal">\r
\r
    <div class="modal-content">\r
\r
        <button class="close-modal" onclick="closeRecommendationModal()">\r
            ×\r
        </button>\r
\r
        <div class="modal-header">\r
\r
            <h2 id="formTitle">\r
                Add Recommendation\r
            </h2>\r
\r
            <p>\r
                Add a related product that can be suggested to customers.\r
            </p>\r
\r
        </div>\r
\r
\r
        <form id="recommendationForm">\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Trigger Product\r
                </label>\r
\r
                <select id="triggerProduct" required>\r
                </select>\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Recommended Product Name\r
                </label>\r
\r
                <input\r
                    type="text"\r
                    id="recommendedName"\r
                    placeholder="Example: Sand (1 cu.ft)"\r
                    required\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Category\r
                </label>\r
\r
                <input\r
                    type="text"\r
                    id="recommendedCategory"\r
                    placeholder="Example: Construction Materials"\r
                    required\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Price\r
                </label>\r
\r
                <input\r
                    type="number"\r
                    id="recommendedPrice"\r
                    placeholder="0.00"\r
                    min="0"\r
                    step="0.01"\r
                    required\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Product Image\r
                </label>\r
\r
                <input\r
                    type="file"\r
                    id="recommendedImage"\r
                    accept="image/*"\r
                    onchange="previewImage(event)"\r
                >\r
\r
                <div class="image-preview" id="imagePreview">\r
                    No image selected\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="modal-actions">\r
\r
                <button\r
                    type="button"\r
                    class="cancel-btn"\r
                    onclick="closeRecommendationModal()"\r
                >\r
                    Cancel\r
                </button>\r
\r
                <button\r
                    type="submit"\r
                    class="save-btn"\r
                >\r
                    Save Recommendation\r
                </button>\r
\r
            </div>\r
\r
        </form>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
<!-- ================= PRODUCT DETAILS MODAL ================= -->\r
\r
<div class="modal" id="productModal">\r
\r
    <div class="modal-content details-modal-content">\r
\r
        <button class="close-modal" onclick="closeProductModal()">\r
            ×\r
        </button>\r
\r
        <img id="modalImage" src="" alt="Product">\r
\r
        <h2 id="modalName">\r
            Product\r
        </h2>\r
\r
        <p id="modalCategory">\r
            Category\r
        </p>\r
\r
        <div class="modal-price" id="modalPrice">\r
            ₱0.00\r
        </div>\r
\r
        <span class="relation-label">\r
            AI Recommended Product\r
        </span>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
\r
</body>\r
</html>`,$n=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
    <title>Customers - ELEE Hardware</title>\r
\r
    <style>\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
            font-family: Arial, Helvetica, sans-serif;\r
        }\r
\r
        body {\r
            background: #ffffff;\r
            color: #111;\r
        }\r
\r
        .layout {\r
            display: flex;\r
            min-height: 100vh;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            z-index: 100;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= MAIN ================= */\r
\r
        .main {\r
            margin-left: 235px;\r
            width: calc(100% - 235px);\r
            min-height: 100vh;\r
            padding: 30px 40px;\r
        }\r
\r
        .page-header {\r
            margin-bottom: 25px;\r
        }\r
\r
        .page-header h1 {\r
            font-size: 28px;\r
            font-weight: 700;\r
            margin-bottom: 6px;\r
        }\r
\r
        .page-header p {\r
            color: #8c8c8c;\r
            font-size: 14px;\r
        }\r
\r
        /* ================= SUMMARY CARDS ================= */\r
\r
        .summary-grid {\r
            display: grid;\r
            grid-template-columns: repeat(4, 1fr);\r
            gap: 15px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .summary-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 12px;\r
            padding: 18px;\r
            background: white;\r
        }\r
\r
        .summary-label {\r
            color: #777;\r
            font-size: 12px;\r
            margin-bottom: 8px;\r
        }\r
\r
        .summary-value {\r
            font-size: 24px;\r
            font-weight: 700;\r
            color: #00551b;\r
        }\r
\r
        /* ================= TOOLBAR ================= */\r
\r
        .toolbar {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            gap: 15px;\r
            margin-bottom: 25px;\r
            flex-wrap: wrap;\r
        }\r
\r
        .search-container {\r
            width: 350px;\r
            height: 43px;\r
            border: 1px solid #dddddd;\r
            border-radius: 10px;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 13px;\r
            background: white;\r
        }\r
\r
        .search-icon {\r
            font-size: 22px;\r
            color: #999;\r
            margin-right: 10px;\r
        }\r
\r
        .search-container input {\r
            border: none;\r
            outline: none;\r
            width: 100%;\r
            font-size: 13px;\r
        }\r
\r
        .search-container input::placeholder {\r
            color: #999;\r
        }\r
\r
        .clear-search {\r
            border: none;\r
            background: none;\r
            cursor: pointer;\r
            color: #999;\r
            font-size: 17px;\r
            display: none;\r
        }\r
\r
        .clear-search:hover {\r
            color: #00551b;\r
        }\r
\r
        .customer-count {\r
            color: #777;\r
            font-size: 13px;\r
        }\r
\r
        /* ================= TABLE CARD ================= */\r
\r
        .table-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 12px;\r
            overflow: hidden;\r
            background: white;\r
        }\r
\r
        .table-wrapper {\r
            width: 100%;\r
            overflow-x: auto;\r
        }\r
\r
        .customer-table {\r
            width: 100%;\r
            border-collapse: collapse;\r
            min-width: 1000px;\r
        }\r
\r
        .customer-table thead {\r
            background: #f8f9f8;\r
        }\r
\r
        .customer-table th {\r
            text-align: left;\r
            font-size: 12px;\r
            font-weight: 700;\r
            color: #555;\r
            padding: 16px 18px;\r
            border-bottom: 1px solid #e5e5e5;\r
            white-space: nowrap;\r
        }\r
\r
        .customer-table td {\r
            padding: 17px 18px;\r
            font-size: 13px;\r
            border-bottom: 1px solid #eeeeee;\r
            vertical-align: middle;\r
        }\r
\r
        .customer-table tbody tr:hover {\r
            background: #fafafa;\r
        }\r
\r
        .customer-table tbody tr:last-child td {\r
            border-bottom: none;\r
        }\r
\r
        .customer-name {\r
            font-weight: 700;\r
            color: #222;\r
        }\r
\r
        .mobile-number {\r
            color: #444;\r
        }\r
\r
        .address {\r
            color: #666;\r
            max-width: 260px;\r
            white-space: normal !important;\r
            line-height: 1.4;\r
        }\r
\r
        .orders-count {\r
            font-weight: 600;\r
            color: #00551b;\r
        }\r
\r
        .amount {\r
            font-weight: 600;\r
        }\r
\r
        .last-order {\r
            color: #555;\r
        }\r
\r
        /* ================= VIEW HISTORY BUTTON ================= */\r
\r
        .history-btn {\r
            border: 1px solid #00551b;\r
            background: white;\r
            color: #00551b;\r
            padding: 8px 12px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 12px;\r
            font-weight: 600;\r
            transition: 0.2s;\r
        }\r
\r
        .history-btn:hover {\r
            background: #00551b;\r
            color: white;\r
        }\r
\r
        /* ================= EMPTY STATE ================= */\r
\r
        .empty-state {\r
            display: none;\r
            text-align: center;\r
            padding: 55px 20px;\r
        }\r
\r
        .empty-icon {\r
            font-size: 40px;\r
            color: #bbb;\r
            margin-bottom: 12px;\r
        }\r
\r
        .empty-state h3 {\r
            font-size: 17px;\r
            margin-bottom: 6px;\r
        }\r
\r
        .empty-state p {\r
            color: #888;\r
            font-size: 13px;\r
        }\r
\r
        /* ================= PAGINATION ================= */\r
\r
        .pagination-area {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            padding: 18px 20px;\r
            border-top: 1px solid #eeeeee;\r
        }\r
\r
        .pagination-info {\r
            color: #777;\r
            font-size: 12px;\r
        }\r
\r
        .pagination {\r
            display: flex;\r
            align-items: center;\r
            gap: 5px;\r
        }\r
\r
        .page-btn {\r
            min-width: 30px;\r
            height: 30px;\r
            border: 1px solid #dddddd;\r
            background: white;\r
            border-radius: 6px;\r
            cursor: pointer;\r
            font-size: 12px;\r
            color: #555;\r
        }\r
\r
        .page-btn:hover {\r
            background: #f0f0f0;\r
        }\r
\r
        .page-btn.active {\r
            background: #299447;\r
            border-color: #299447;\r
            color: white;\r
            font-weight: bold;\r
        }\r
\r
        .page-btn:disabled {\r
            opacity: 0.4;\r
            cursor: not-allowed;\r
        }\r
\r
        /* ================= MODAL ================= */\r
\r
        .modal-overlay {\r
            display: none;\r
            position: fixed;\r
            inset: 0;\r
            background: rgba(0, 0, 0, 0.45);\r
            z-index: 500;\r
            align-items: center;\r
            justify-content: center;\r
            padding: 20px;\r
        }\r
\r
        .modal-overlay.show {\r
            display: flex;\r
        }\r
\r
        .modal {\r
            width: 100%;\r
            max-width: 750px;\r
            max-height: 90vh;\r
            overflow-y: auto;\r
            background: white;\r
            border-radius: 14px;\r
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.2);\r
        }\r
\r
        .modal-header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            padding: 20px 24px;\r
            border-bottom: 1px solid #eeeeee;\r
            position: sticky;\r
            top: 0;\r
            background: white;\r
            z-index: 2;\r
        }\r
\r
        .modal-header h2 {\r
            font-size: 19px;\r
            color: #222;\r
        }\r
\r
        .close-btn {\r
            border: none;\r
            background: #f1f1f1;\r
            width: 32px;\r
            height: 32px;\r
            border-radius: 50%;\r
            cursor: pointer;\r
            font-size: 18px;\r
            color: #555;\r
        }\r
\r
        .close-btn:hover {\r
            background: #e5e5e5;\r
        }\r
\r
        .modal-body {\r
            padding: 24px;\r
        }\r
\r
        /* ================= CUSTOMER INFO ================= */\r
\r
        .customer-info {\r
            display: grid;\r
            grid-template-columns: repeat(2, 1fr);\r
            gap: 15px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .info-box {\r
            background: #f8faf8;\r
            border-radius: 9px;\r
            padding: 14px;\r
        }\r
\r
        .info-box.full {\r
            grid-column: 1 / -1;\r
        }\r
\r
        .info-label {\r
            font-size: 11px;\r
            color: #888;\r
            margin-bottom: 5px;\r
        }\r
\r
        .info-value {\r
            font-size: 13px;\r
            font-weight: 600;\r
            color: #222;\r
        }\r
\r
        /* ================= ORDER HISTORY ================= */\r
\r
        .history-title {\r
            font-size: 16px;\r
            margin-bottom: 12px;\r
            color: #222;\r
        }\r
\r
        .history-table-wrapper {\r
            overflow-x: auto;\r
            border: 1px solid #e5e5e5;\r
            border-radius: 9px;\r
        }\r
\r
        .history-table {\r
            width: 100%;\r
            border-collapse: collapse;\r
            min-width: 600px;\r
        }\r
\r
        .history-table th {\r
            background: #f7f8f7;\r
            text-align: left;\r
            padding: 12px;\r
            font-size: 11px;\r
            color: #666;\r
            white-space: nowrap;\r
        }\r
\r
        .history-table td {\r
            padding: 12px;\r
            border-top: 1px solid #eeeeee;\r
            font-size: 12px;\r
            white-space: nowrap;\r
        }\r
\r
        .status {\r
            display: inline-block;\r
            padding: 5px 9px;\r
            border-radius: 20px;\r
            font-size: 10px;\r
            font-weight: 700;\r
        }\r
\r
        .status.paid {\r
            background: #e4f6e9;\r
            color: #168139;\r
        }\r
\r
        .status.unpaid {\r
            background: #fff4d6;\r
            color: #9a7000;\r
        }\r
\r
        .status.cancelled {\r
            background: #fce8e8;\r
            color: #b52a2a;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media (max-width: 1100px) {\r
            .summary-grid {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
        }\r
\r
        @media (max-width: 900px) {\r
\r
            .sidebar {\r
                width: 190px;\r
            }\r
\r
            .main {\r
                margin-left: 190px;\r
                width: calc(100% - 190px);\r
                padding: 25px;\r
            }\r
\r
            .customer-table {\r
                min-width: 1050px;\r
            }\r
\r
            .toolbar {\r
                align-items: flex-start;\r
            }\r
        }\r
\r
        @media (max-width: 650px) {\r
\r
            .sidebar {\r
                width: 70px;\r
                padding: 20px 8px;\r
            }\r
\r
            .logo {\r
                margin-left: 5px;\r
            }\r
\r
            .logo-name {\r
                font-size: 20px;\r
                letter-spacing: -1px;\r
            }\r
\r
            .hardware {\r
                display: none;\r
            }\r
\r
            .menu a {\r
                justify-content: center;\r
                padding: 12px 5px;\r
            }\r
\r
            .menu a span:not(.icon) {\r
                display: none;\r
            }\r
\r
            .main {\r
                margin-left: 70px;\r
                width: calc(100% - 70px);\r
                padding: 20px;\r
            }\r
\r
            .summary-grid {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .search-container {\r
                width: 100%;\r
            }\r
\r
            .toolbar {\r
                display: block;\r
            }\r
\r
            .customer-count {\r
                display: block;\r
                margin-top: 10px;\r
            }\r
\r
            .pagination-area {\r
                display: block;\r
            }\r
\r
            .pagination {\r
                margin-top: 12px;\r
                justify-content: center;\r
            }\r
\r
            .customer-info {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .info-box.full {\r
                grid-column: auto;\r
            }\r
        }\r
    </style>\r
</head>\r
\r
<body>\r
\r
<div class="layout">\r
\r
    <!-- ================= SIDEBAR ================= -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <nav class="menu">\r
\r
            <a href="{{ url('/dashboard') }}">\r
                <span class="icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}">\r
                <span class="icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}">\r
                <span class="icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}">\r
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}" class="active">\r
                <span class="icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}">\r
                <span class="icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </nav>\r
\r
    </aside>\r
\r
\r
    <!-- ================= MAIN ================= -->\r
\r
    <main class="main customer-page">\r
\r
        <div class="page-header">\r
            <h1>Customer Records</h1>\r
            <p>View customer information and order history</p>\r
        </div>\r
\r
\r
        <!-- ================= SUMMARY ================= -->\r
\r
        <div class="summary-grid">\r
\r
            <div class="summary-card">\r
                <div class="summary-label">Total Customers</div>\r
                <div class="summary-value" id="totalCustomers">0</div>\r
            </div>\r
\r
            <div class="summary-card">\r
                <div class="summary-label">Total Orders</div>\r
                <div class="summary-value" id="totalOrders">0</div>\r
            </div>\r
\r
            <div class="summary-card">\r
                <div class="summary-label">Total Sales</div>\r
                <div class="summary-value" id="totalSales">₱ 0.00</div>\r
            </div>\r
\r
            <div class="summary-card">\r
                <div class="summary-label">Active Customers</div>\r
                <div class="summary-value" id="activeCustomers">0</div>\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= SEARCH ================= -->\r
\r
        <div class="toolbar">\r
\r
            <div class="search-container">\r
\r
                <span class="search-icon">⌕</span>\r
\r
                <input\r
                    type="text"\r
                    id="customerSearch"\r
                    placeholder="Search customer, mobile number, or address..."\r
                    oninput="searchCustomer()"\r
                >\r
\r
                <button\r
                    type="button"\r
                    class="clear-search"\r
                    id="clearSearch"\r
                    onclick="clearSearch()"\r
                >\r
                    ×\r
                </button>\r
\r
            </div>\r
\r
            <div class="customer-count" id="customerCount">\r
                Showing 0 customers\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= CUSTOMER TABLE ================= -->\r
\r
        <div class="table-card">\r
\r
            <div class="table-wrapper">\r
\r
                <table class="customer-table">\r
\r
                    <thead>\r
                        <tr>\r
                            <th>Customer Name</th>\r
                            <th>Mobile Number</th>\r
                            <th>Delivery Address</th>\r
                            <th>Total Orders</th>\r
                            <th>Total Spent</th>\r
                            <th>Last Order</th>\r
                            <th>Order History</th>\r
                        </tr>\r
                    </thead>\r
\r
                    <tbody id="customerTable"></tbody>\r
\r
                </table>\r
\r
            </div>\r
\r
\r
            <!-- EMPTY STATE -->\r
\r
            <div class="empty-state" id="emptyState">\r
\r
                <div class="empty-icon">⌕</div>\r
\r
                <h3>No customer found</h3>\r
\r
                <p>\r
                    Try searching using a different customer name,\r
                    mobile number, or address.\r
                </p>\r
\r
            </div>\r
\r
\r
            <!-- PAGINATION -->\r
\r
            <div class="pagination-area">\r
\r
                <div class="pagination-info" id="paginationInfo">\r
                    Showing 0 to 0 of 0 customers\r
                </div>\r
\r
                <div class="pagination" id="pagination">\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
<!-- ================= ORDER HISTORY MODAL ================= -->\r
\r
<div class="modal-overlay" id="historyModal">\r
\r
    <div class="modal">\r
\r
        <div class="modal-header">\r
\r
            <h2>Customer Details</h2>\r
\r
            <button\r
                class="close-btn"\r
                onclick="closeHistory()"\r
            >\r
                ×\r
            </button>\r
\r
        </div>\r
\r
\r
        <div class="modal-body">\r
\r
            <!-- CUSTOMER INFORMATION -->\r
\r
            <div class="customer-info">\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Customer Name\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalCustomerName"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Mobile Number\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalMobile"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box full">\r
\r
                    <div class="info-label">\r
                        Delivery Address\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalAddress"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Total Orders\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalTotalOrders"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Total Spent\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalTotalSpent"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- ORDER HISTORY -->\r
\r
            <h3 class="history-title">\r
                Order History\r
            </h3>\r
\r
            <div class="history-table-wrapper">\r
\r
                <table class="history-table">\r
\r
                    <thead>\r
                        <tr>\r
                            <th>Order ID</th>\r
                            <th>Date</th>\r
                            <th>Items</th>\r
                            <th>Amount</th>\r
                            <th>Payment</th>\r
                            <th>Status</th>\r
                        </tr>\r
                    </thead>\r
\r
                    <tbody id="historyTable"></tbody>\r
\r
                </table>\r
\r
            </div>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
</body>\r
</html>\r
`,Yn=`<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>EleeSiWeb - Dashboard</title>

    

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        body {
            background: #ffffff;
            color: #151515;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }


        /* ================= SIDEBAR ================= */

        .sidebar {
            width: 235px;
            min-height: 100vh;
            background: #00551f;
            color: white;
            padding: 28px 16px;
            flex-shrink: 0;
        }

        .logo {
            font-size: 36px;
            font-weight: 900;
            margin-left: 12px;
            letter-spacing: -2px;
        }

        .logo span {
            color: #ffbd00;
        }

        .hardware {
            color: #ffbd00;
            font-size: 14px;
            font-weight: bold;
            margin-left: 13px;
            margin-top: 3px;
            margin-bottom: 25px;
        }

        .menu {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .menu a {
            text-decoration: none;
            color: white;
            padding: 13px 14px;
            border-radius: 7px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: 0.2s;
        }

        .menu a:hover {
            background: #08732e;
        }

        .menu a.active {
            background: #08732e;
        }

        .icon {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        /* ================= LOGOUT ================= */

        .menu a.logout {
            margin-top: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            padding-top: 16px;
        }

        .menu a.logout:hover {
            background: #8b1e1e;
        }


        /* ================= MAIN ================= */

        .main {
            flex: 1;
            min-width: 0;
            background: #ffffff;
        }

        .content {
            padding: 30px 28px 35px;
        }

        .header {
            margin-bottom: 22px;
        }

        .header h1 {
            font-size: 31px;
            margin-bottom: 4px;
        }

        .header p {
            color: #8b8b8b;
            font-size: 15px;
        }


        /* ================= SUMMARY CARDS ================= */

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 20px;
        }

        .card {
            background: #ffffff;
            border: 1px solid #e5e7e5;
            border-radius: 13px;
            padding: 18px;
            min-height: 135px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        }

        .card-top {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .card-icon {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .green-icon {
            background: #d9f8e5;
            color: #08752a;
        }

        .yellow-icon {
            background: #fff0c8;
            color: #e49a00;
        }

        .purple-icon {
            background: #efd8ff;
            color: #8b00c9;
        }

        .red-icon {
            background: #ffe0e0;
            color: #d63031;
        }

        .card-title {
            font-size: 14px;
            font-weight: 600;
        }

        .card-number {
            font-size: 27px;
            font-weight: 700;
            margin-top: 8px;
            margin-left: 54px;
        }

        .card-change {
            color: #16a34a;
            font-size: 11px;
            margin-left: 54px;
            margin-top: 6px;
        }

        .card-warning {
            color: #d63031;
            font-size: 11px;
            margin-left: 54px;
            margin-top: 6px;
        }


        /* ================= CHART ROW ================= */

        .chart-row {
            display: grid;
            grid-template-columns: 1.65fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .box {
            background: white;
            border: 1px solid #e4e7e4;
            border-radius: 13px;
            padding: 18px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        }

        .box-title {
            font-size: 16px;
            font-weight: 700;
        }

        .box-subtitle {
            color: #999;
            font-size: 12px;
            margin-top: 4px;
        }

        .chart-container {
            height: 250px;
            margin-top: 10px;
        }


        /* ================= PAYMENT OVERVIEW ================= */

        .payment-overview {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 20px;
        }

        .payment-card {
            border: 1px solid #e5e7e5;
            border-radius: 10px;
            padding: 15px;
        }

        .payment-label {
            color: #777;
            font-size: 12px;
            margin-bottom: 7px;
        }

        .payment-value {
            font-size: 21px;
            font-weight: bold;
        }

        .paid-value {
            color: #08752a;
        }

        .unpaid-value {
            color: #d97706;
        }


        /* ================= ORDER STATUS ================= */

        .order-status {
            display: flex;
            align-items: center;
            justify-content: space-between;
            min-height: 250px;
            gap: 15px;
        }

        .donut {
            width: 205px;
            height: 205px;
            position: relative;
            flex-shrink: 0;
        }

        .donut canvas {
            width: 100% !important;
            height: 100% !important;
        }

        .donut-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            pointer-events: none;
        }

        .donut-number {
            font-size: 23px;
            font-weight: 700;
        }

        .donut-total {
            font-size: 11px;
            color: #888;
            margin-top: 2px;
        }

        .status-list {
            display: flex;
            flex-direction: column;
            gap: 17px;
            flex: 1;
        }

        .status-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 11px;
        }

        .status-item strong {
            margin-left: auto;
            font-size: 10px;
        }

        .status-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            flex-shrink: 0;
        }

        .completed {
            background: #08752a;
        }

        .processing {
            background: #16a34a;
        }

        .pending {
            background: #ffad00;
        }

        .ready {
            background: #8e00c7;
        }


        /* ================= BOTTOM ================= */

        .bottom-row {
            display: grid;
            grid-template-columns: 1.65fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .box-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .see-all {
            color: #08752a;
            font-size: 12px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
        }

        .see-all:hover {
            text-decoration: underline;
        }


        /* ================= TABLE ================= */

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th {
            text-align: left;
            color: #888;
            font-size: 11px;
            font-weight: 500;
            padding: 9px 5px;
            border-bottom: 1px solid #eeeeee;
        }

        td {
            padding: 12px 5px;
            font-size: 12px;
            border-bottom: 1px solid #eeeeee;
        }

        .order-id {
            font-weight: 600;
        }

        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: bold;
        }

        .badge-completed {
            background: #d7f8e4;
            color: #08752a;
        }

        .badge-pending {
            background: #fff0bd;
            color: #8a6200;
        }

        .badge-ready {
            background: #efd7ff;
            color: #7800a8;
        }


        /* ================= LOW STOCK ================= */

        .stock-list {
            margin-top: 13px;
        }

        .stock-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 13px 0;
            border-bottom: 1px solid #eeeeee;
        }

        .stock-image {
            width: 43px;
            height: 43px;
            border-radius: 7px;
            background: #ffeaea;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 21px;
        }

        .stock-info {
            flex: 1;
        }

        .stock-name {
            font-size: 12px;
            font-weight: 700;
        }

        .stock-description {
            font-size: 10px;
            color: #888;
            margin-top: 3px;
        }

        .stock-number {
            text-align: right;
        }

        .stock-quantity {
            color: #d63031;
            font-size: 12px;
            font-weight: bold;
        }

        .stock-label {
            color: #888;
            font-size: 9px;
        }


        /* ================= TOP SELLING PRODUCTS ================= */

        .product-list {
            margin-top: 13px;
        }

        .product {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 0;
            border-bottom: 1px solid #eeeeee;
        }

        .product-image {
            width: 43px;
            height: 43px;
            border-radius: 7px;
            background: #eeeeee;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .product-info {
            flex: 1;
        }

        .product-name {
            font-size: 12px;
            font-weight: 700;
        }

        .product-price {
            font-size: 10px;
            color: #888;
            margin-top: 3px;
        }

        .product-sales {
            text-align: right;
        }

        .sales-number {
            color: #08752a;
            font-size: 12px;
            font-weight: bold;
        }

        .sold {
            color: #888;
            font-size: 9px;
        }


        /* ================= RESPONSIVE ================= */

        @media (max-width: 1100px) {

            .sidebar {
                width: 200px;
            }

            .cards {
                grid-template-columns: repeat(2, 1fr);
            }

            .chart-row,
            .bottom-row {
                grid-template-columns: 1fr;
            }
        }


        @media (max-width: 700px) {

            .sidebar {
                display: none;
            }

            .cards {
                grid-template-columns: 1fr;
            }

            .content {
                padding: 20px;
            }

            .payment-overview {
                grid-template-columns: 1fr;
            }

            .order-status {
                flex-direction: column;
                padding: 15px 0;
            }

            .donut {
                width: 180px;
                height: 180px;
            }

            .box {
                overflow-x: auto;
            }

            table {
                min-width: 600px;
            }
        }

    </style>

</head>


<body>


<div class="dashboard">


    <!-- ================= SIDEBAR ================= -->

    <aside class="sidebar">

        <div class="logo">
            <span style="color:white;">E</span><span>LEE</span>
        </div>

        <div class="hardware">
            HARDWARE
        </div>

        <div class="menu">

            <a href="{{ url('/') }}" class="active">
                <span class="icon">☼</span>
                Dashboard
            </a>

            <a href="{{ url('/orders') }}">
                <span class="icon">▣</span>
                Orders
            </a>

            <a href="{{ url('/products') }}">
                <span class="icon">◇</span>
                Products
            </a>

            <a href="{{ url('/ai-recommendations') }}">
                <span class="icon">↗</span>
                AI Recommendations
            </a>

            <a href="{{ url('/payments') }}">
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>
                Payments
            </a>

            <a href="{{ url('/customers') }}">
                <span class="icon">♙</span>
                Customers
            </a>

            <a href="{{ url('/queuing') }}">
                <span class="icon">▱</span>
                Queuing
            </a>

            <a href="{{ url('/receipt-records') }}">
                <span class="icon">▤</span>
                Receipt Records
            </a>

            <a href="{{ url('/settings') }}">
                <span class="icon">⚙</span>
                Settings
            </a>

            <!-- ================= LOGOUT ================= -->

            <a href="{{ url('/admin/logout') }}" class="logout">
                <span class="icon">↪</span>
                Logout
            </a>

        </div>

    </aside>


    <!-- ================= MAIN ================= -->

    <main class="main">

        <div class="content">


            <!-- ================= HEADER ================= -->

            <div class="header">

                <h1>
                    Dashboard
                </h1>

                <p>
                    Overview of your store orders, sales, payments, and inventory.
                </p>

            </div>


            <!-- ================= SUMMARY CARDS ================= -->

            <div class="cards">


                <!-- TOTAL ORDERS -->

                <div class="card">

                    <div class="card-top">

                        <div class="card-icon green-icon">
                            🛒
                        </div>

                        <div class="card-title">
                            Total Orders
                        </div>

                    </div>

                    <div class="card-number">
                        128
                    </div>

                    <div class="card-change">
                        ↑ 12% from yesterday
                    </div>

                </div>


                <!-- PENDING ORDERS -->

                <div class="card">

                    <div class="card-top">

                        <div class="card-icon yellow-icon">
                            ◷
                        </div>

                        <div class="card-title">
                            Pending Orders
                        </div>

                    </div>

                    <div class="card-number">
                        28
                    </div>

                    <div class="card-change">
                        21.9% of total orders
                    </div>

                </div>


                <!-- TOTAL SALES -->

                <div class="card">

                    <div class="card-top">

                        <div class="card-icon purple-icon">
                            ₱
                        </div>

                        <div class="card-title">
                            Total Sales
                        </div>

                    </div>

                    <div class="card-number">
                        ₱98,450.00
                    </div>

                    <div class="card-change">
                        ↑ 12% from yesterday
                    </div>

                </div>


                <!-- LOW STOCK -->

                <div class="card">

                    <div class="card-top">

                        <div class="card-icon red-icon">
                            ⚠
                        </div>

                        <div class="card-title">
                            Low-Stock Products
                        </div>

                    </div>

                    <div class="card-number">
                        6
                    </div>

                    <div class="card-warning">
                        Requires attention
                    </div>

                </div>


            </div>


            <!-- ================= CHART ROW ================= -->

            <div class="chart-row">


                <!-- SALES REVENUE -->

                <div class="box">

                    <div class="box-title">
                        Sales Revenue Trend
                    </div>

                    <div class="box-subtitle">
                        Monthly performance overview
                    </div>

                    <div class="chart-container">

                        <canvas id="salesChart"></canvas>

                    </div>

                </div>


                <!-- ORDER STATUS -->

                <div class="box">

                    <div class="box-title">
                        Order Status
                    </div>

                    <div class="box-subtitle">
                        Current order overview
                    </div>


                    <div class="order-status">


                        <div class="donut">

                            <canvas id="orderChart"></canvas>

                            <div class="donut-center">

                                <div class="donut-number">
                                    128
                                </div>

                                <div class="donut-total">
                                    Total Orders
                                </div>

                            </div>

                        </div>


                        <div class="status-list">


                            <div class="status-item">

                                <span class="status-dot completed"></span>

                                <span>
                                    Completed
                                </span>

                                <strong>
                                    98
                                </strong>

                            </div>


                            <div class="status-item">

                                <span class="status-dot pending"></span>

                                <span>
                                    Pending
                                </span>

                                <strong>
                                    28
                                </strong>

                            </div>


                            <div class="status-item">

                                <span class="status-dot processing"></span>

                                <span>
                                    Processing
                                </span>

                                <strong>
                                    1
                                </strong>

                            </div>


                            <div class="status-item">

                                <span class="status-dot ready"></span>

                                <span>
                                    Ready
                                </span>

                                <strong>
                                    1
                                </strong>

                            </div>


                        </div>

                    </div>

                </div>


            </div>


            <!-- ================= PAYMENT OVERVIEW ================= -->

            <div class="box" style="margin-bottom:20px;">

                <div class="box-title">
                    Payment Overview
                </div>

                <div class="box-subtitle">
                    Summary of customer payment status
                </div>


                <div class="payment-overview">


                    <div class="payment-card">

                        <div class="payment-label">
                            Paid Orders
                        </div>

                        <div class="payment-value paid-value">
                            98 Orders
                        </div>

                    </div>


                    <div class="payment-card">

                        <div class="payment-label">
                            Unpaid Orders
                        </div>

                        <div class="payment-value unpaid-value">
                            30 Orders
                        </div>

                    </div>


                    <div class="payment-card">

                        <div class="payment-label">
                            Paid Amount
                        </div>

                        <div class="payment-value paid-value">
                            ₱78,320.00
                        </div>

                    </div>


                    <div class="payment-card">

                        <div class="payment-label">
                            Unpaid Amount
                        </div>

                        <div class="payment-value unpaid-value">
                            ₱20,130.00
                        </div>

                    </div>


                </div>

            </div>


            <!-- ================= BOTTOM ROW ================= -->

            <div class="bottom-row">


                <!-- RECENT ORDERS -->

                <div class="box">

                    <div class="box-header">

                        <div>

                            <div class="box-title">
                                Recent Orders
                            </div>

                            <div class="box-subtitle">
                                Latest customer orders
                            </div>

                        </div>

                        <!-- CLICKABLE SEE ALL ORDERS -->

                        <a href="{{ url('/orders') }}" class="see-all">
                            See All Orders →
                        </a>

                    </div>


                    <table>

                        <thead>

                            <tr>

                                <th>
                                    Order ID
                                </th>

                                <th>
                                    Customer
                                </th>

                                <th>
                                    Date
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Amount
                                </th>

                            </tr>

                        </thead>


                        <tbody></tbody>

                    </table>

                </div>


                <!-- LOW STOCK PRODUCTS -->

                <div class="box">

                    <div class="box-title">
                        Low-Stock Products
                    </div>

                    <div class="box-subtitle">
                        Products that need restocking
                    </div>


                    <div class="stock-list">


                        <div class="stock-item">

                            <div class="stock-image">
                                🧱
                            </div>

                            <div class="stock-info">

                                <div class="stock-name">
                                    Cement 25kg
                                </div>

                                <div class="stock-description">
                                    Inventory level is low
                                </div>

                            </div>

                            <div class="stock-number">

                                <div class="stock-quantity">
                                    8
                                </div>

                                <div class="stock-label">
                                    left
                                </div>

                            </div>

                        </div>


                        <div class="stock-item">

                            <div class="stock-image">
                                🔩
                            </div>

                            <div class="stock-info">

                                <div class="stock-name">
                                    GI Sheet 0.3mm
                                </div>

                                <div class="stock-description">
                                    Inventory level is low
                                </div>

                            </div>

                            <div class="stock-number">

                                <div class="stock-quantity">
                                    5
                                </div>

                                <div class="stock-label">
                                    left
                                </div>

                            </div>

                        </div>


                        <div class="stock-item">

                            <div class="stock-image">
                                🔨
                            </div>

                            <div class="stock-info">

                                <div class="stock-name">
                                    Hammer
                                </div>

                                <div class="stock-description">
                                    Inventory level is low
                                </div>

                            </div>

                            <div class="stock-number">

                                <div class="stock-quantity">
                                    4
                                </div>

                                <div class="stock-label">
                                    left
                                </div>

                            </div>

                        </div>


                        <div class="stock-item">

                            <div class="stock-image">
                                🔩
                            </div>

                            <div class="stock-info">

                                <div class="stock-name">
                                    Nails 1kg
                                </div>

                                <div class="stock-description">
                                    Inventory level is low
                                </div>

                            </div>

                            <div class="stock-number">

                                <div class="stock-quantity">
                                    3
                                </div>

                                <div class="stock-label">
                                    left
                                </div>

                            </div>

                        </div>


                    </div>

                </div>


            </div>


            <!-- ================= TOP SELLING PRODUCTS ================= -->

            <div class="box">

                <div class="box-title">
                    Top-Selling Products
                </div>

                <div class="box-subtitle">
                    Highest demand products this week
                </div>


                <div class="product-list">


                    <div class="product">

                        <div class="product-image">
                            🧱
                        </div>

                        <div class="product-info">

                            <div class="product-name">
                                Hollow Blocks 4"
                            </div>

                            <div class="product-price">
                                ₱250.00/pc
                            </div>

                        </div>

                        <div class="product-sales">

                            <div class="sales-number">
                                340
                            </div>

                            <div class="sold">
                                sold
                            </div>

                        </div>

                    </div>


                    <div class="product">

                        <div class="product-image">
                            🔩
                        </div>

                        <div class="product-info">

                            <div class="product-name">
                                GI Sheet 0.3mm
                            </div>

                            <div class="product-price">
                                ₱350.00/pc
                            </div>

                        </div>

                        <div class="product-sales">

                            <div class="sales-number">
                                180
                            </div>

                            <div class="sold">
                                sold
                            </div>

                        </div>

                    </div>


                    <div class="product">

                        <div class="product-image">
                            🧱
                        </div>

                        <div class="product-info">

                            <div class="product-name">
                                Cement 25kg
                            </div>

                            <div class="product-price">
                                ₱125.00/pc
                            </div>

                        </div>

                        <div class="product-sales">

                            <div class="sales-number">
                                124
                            </div>

                            <div class="sold">
                                sold
                            </div>

                        </div>

                    </div>


                </div>

            </div>


        </div>

    </main>

</div>


<!-- ================= JAVASCRIPT ================= -->




</body>
</html>`,Wn=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
<meta charset="UTF-8">\r
<meta name="viewport" content="width=device-width, initial-scale=1.0">\r
<title>EleeSiWeb - Orders & Products</title>\r
\r
<style>\r
*{box-sizing:border-box;margin:0;padding:0}\r
body{font-family:Arial,Helvetica,sans-serif;background:#fff;color:#111}\r
\r
.sidebar{position:fixed;left:0;top:0;width:235px;height:100vh;background:#00551f;color:#fff;padding:28px 16px;z-index:100}\r
.logo{font-size:36px;font-weight:900;margin-left:12px;letter-spacing:-2px}\r
.logo span{color:#ffbd00}\r
.hardware{color:#ffbd00;font-size:14px;font-weight:bold;margin-left:13px;margin-top:3px;margin-bottom:25px}\r
.menu{display:flex;flex-direction:column;gap:7px}\r
.menu a{text-decoration:none;color:#fff;padding:13px 14px;border-radius:7px;font-size:14px;display:flex;align-items:center;gap:12px}\r
.menu a:hover,.menu a.active{background:#08732e}\r
.icon{width:20px;text-align:center;font-size:18px}\r
\r
.main{margin-left:235px;padding:46px 42px;min-height:100vh}\r
.section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;gap:20px}\r
.section-title{font-size:25px;color:#147a36;font-weight:600}\r
.section-description{color:#777;font-size:14px;margin-top:4px}\r
\r
.tabs{\r
    display:grid;\r
    grid-template-columns:repeat(6,minmax(0,1fr));\r
    align-items:center;\r
    column-gap:18px;\r
    width:100%;\r
    min-width:950px;\r
    margin-bottom:18px\r
}\r
.tab{\r
    width:100%;border:none;background:transparent;font-size:15px;\r
    font-weight:600;cursor:pointer;padding:10px 8px;white-space:nowrap;\r
    color:#111;border-radius:7px;text-align:center\r
}\r
.tab.active{background:#b9e8c0;color:#075b21}\r
.tab:hover{background:#e4f5e7;color:#075b21}\r
\r
.search-container{width:100%;margin-bottom:25px}\r
.search-box{\r
    width:100%;height:55px;border:1px solid #dedede;border-radius:10px;\r
    display:flex;align-items:center;padding:0 18px;\r
    box-shadow:0 1px 4px rgba(0,0,0,.03)\r
}\r
.search-icon{font-size:28px;color:#999;margin-right:15px}\r
.search-box input{border:none;outline:none;width:100%;font-size:16px;color:#333}\r
.search-box input::placeholder{color:#999}\r
\r
.orders-table,.products-table{width:100%;overflow-x:auto}\r
.table-header,.order-row{\r
    display:grid;\r
    grid-template-columns:1.45fr 1.25fr 1fr .75fr 1.55fr .55fr;\r
    align-items:center;column-gap:18px;min-width:950px\r
}\r
.table-header{padding:0 3px 16px;font-size:15px;font-weight:700}\r
.order-row{min-height:75px;border-top:1px solid #eee;font-size:14px}\r
.order-id,.customer,.total{font-weight:600}\r
.date{color:#555}\r
\r
.status{display:inline-block;width:max-content;padding:6px 10px;border-radius:5px;font-size:12px;font-weight:600}\r
.pending{background:#fff0bd;color:#e49b00}\r
.processing{background:#c9e0ff;color:#277ed8}\r
.ready{background:#c3edc5;color:#13a52a}\r
.completed{background:#bcebbf;color:#08a425}\r
.cancelled{background:#ffc5c5;color:#e33b3b}\r
\r
.view-btn,.edit-btn{\r
    border:none;background:#b9e8c0;color:#16833a;padding:7px 13px;\r
    border-radius:5px;cursor:pointer;font-size:13px;font-weight:600\r
}\r
.view-btn:hover,.edit-btn:hover{background:#91d99d}\r
\r
.add-btn{\r
    background:#08752f;color:#fff;border:none;padding:11px 18px;\r
    border-radius:7px;cursor:pointer;font-size:14px;font-weight:600\r
}\r
.add-btn:hover{background:#065b25}\r
\r
.no-results{display:none;padding:25px;text-align:center;color:#777}\r
\r
.bottom{\r
    display:flex;justify-content:space-between;align-items:center;\r
    margin-top:30px;margin-bottom:70px;font-size:14px;color:#444\r
}\r
.pagination{display:flex;align-items:center;gap:8px}\r
.page{\r
    cursor:pointer;font-weight:500;min-width:32px;height:32px;\r
    display:flex;align-items:center;justify-content:center;\r
    border-radius:5px;padding:0 7px\r
}\r
.page.active{background:#299b4d;color:#fff}\r
.page:hover{background:#e4f5e7;color:#147a36}\r
.page.disabled{color:#bbb;cursor:not-allowed;background:none}\r
\r
.section-divider{height:1px;background:#e5e5e5;margin:20px 0 45px}\r
\r
.product-header,.product-row{\r
    display:grid;\r
    grid-template-columns:2fr 1fr 1fr 1.2fr 1fr 1fr .8fr;\r
    align-items:center;column-gap:18px;min-width:900px\r
}\r
.product-header{padding:0 3px 16px;font-size:15px;font-weight:700}\r
.product-row{min-height:82px;border-top:1px solid #eee;font-size:14px}\r
.product-info{display:flex;align-items:center;gap:12px}\r
.product-image{\r
    width:48px;height:48px;border-radius:8px;background:#e8f5eb;\r
    display:flex;align-items:center;justify-content:center;\r
    color:#147a36;font-size:22px;font-weight:bold\r
}\r
.product-name{font-weight:700}\r
.product-category{color:#777;font-size:12px;margin-top:3px}\r
.price,.stock{font-weight:600}\r
.stock.low{color:#e49b00}\r
.stock.critical{color:#e33b3b}\r
.availability{\r
    display:inline-block;padding:6px 10px;border-radius:5px;\r
    font-size:12px;font-weight:600\r
}\r
.available{background:#bcebbf;color:#08a425}\r
.unavailable{background:#ffc5c5;color:#e33b3b}\r
\r
.product-form{\r
    display:none;background:#f8faf8;border:1px solid #e2e8e3;\r
    border-radius:12px;padding:25px;margin-bottom:25px\r
}\r
.product-form.show{display:block}\r
.form-title{font-size:20px;color:#147a36;margin-bottom:20px;font-weight:600}\r
.form-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}\r
.form-group{display:flex;flex-direction:column}\r
.form-group label{font-size:13px;font-weight:600;margin-bottom:7px;color:#444}\r
.form-group input,.form-group select{\r
    width:100%;height:43px;padding:0 12px;border:1px solid #d7d7d7;\r
    border-radius:7px;outline:none;background:#fff;font-size:14px\r
}\r
.form-buttons{display:flex;justify-content:flex-end;gap:10px;margin-top:20px}\r
.cancel-form{background:#eee;border:none;padding:10px 18px;border-radius:6px;cursor:pointer}\r
.save-product,.save-btn{\r
    background:#08752f;color:#fff;border:none;padding:10px 18px;\r
    border-radius:6px;cursor:pointer\r
}\r
\r
.modal-bg{\r
    display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);\r
    justify-content:center;align-items:center;z-index:999;padding:20px\r
}\r
.modal{\r
    background:#fff;width:500px;max-width:100%;border-radius:12px;\r
    padding:28px;box-shadow:0 10px 40px rgba(0,0,0,.2)\r
}\r
.modal h2{color:#147a36;margin-bottom:22px}\r
.detail{margin-bottom:15px}\r
.detail label{display:block;color:#777;font-size:13px;margin-bottom:5px}\r
.detail strong{font-size:16px}\r
.status-select{\r
    width:100%;padding:11px;border:1px solid #ddd;\r
    border-radius:7px;font-size:15px;outline:none\r
}\r
.modal-buttons{display:flex;justify-content:flex-end;gap:10px;margin-top:25px}\r
.close-btn{background:#eee;border:none;padding:10px 18px;border-radius:6px;cursor:pointer}\r
\r
@media(max-width:1100px){\r
.sidebar{width:190px}\r
.main{margin-left:190px;padding:35px 25px}\r
.form-grid{grid-template-columns:repeat(2,1fr)}\r
}\r
@media(max-width:700px){\r
.sidebar{position:relative;width:100%;height:auto}\r
.menu{display:grid;grid-template-columns:repeat(2,1fr)}\r
.main{margin-left:0;padding:30px 18px}\r
.section-header{align-items:flex-start;flex-direction:column}\r
.form-grid{grid-template-columns:1fr}\r
.bottom{flex-direction:column;gap:20px;align-items:flex-start}\r
}\r
</style>\r
</head>\r
\r
<body>\r
\r
<div class="sidebar">\r
    <div class="logo"><span style="color:white">E</span><span>LEE</span></div>\r
    <div class="hardware">HARDWARE</div>\r
\r
    <div class="menu">\r
        <a href="/"><span class="icon">☼</span><span>Dashboard</span></a>\r
        <a href="/orders" class="active"><span class="icon">▣</span><span>Orders</span></a>\r
        <a href="/products"><span class="icon">◇</span><span>Products</span></a>\r
        <a href="/ai-recommendations"><span class="icon">↗</span><span>AI Recommendations</span></a>\r
        <a href="/payments"><span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span><span>Payments</span></a>\r
        <a href="/customers"><span class="icon">♙</span><span>Customers</span></a>\r
        <a href="/queuing"><span class="icon">▱</span><span>Queuing</span></a>\r
        <a href="/receipt-records"><span class="icon">▤</span><span>Receipt Records</span></a>\r
        <a href="/settings"><span class="icon">⚙</span><span>Settings</span></a>\r
    </div>\r
</div>\r
\r
<div class="main">\r
\r
<div class="section-header">\r
    <div>\r
        <div class="section-title">Order Management</div>\r
        <div class="section-description">View customer orders and update order status</div>\r
    </div>\r
</div>\r
\r
<div class="tabs">\r
    <button class="tab active" data-status="All Orders">All Orders</button>\r
    <button class="tab" data-status="Pending">Pending</button>\r
    <button class="tab" data-status="Processing">Processing</button>\r
    <button class="tab" data-status="Ready for Delivery">Ready for Delivery</button>\r
    <button class="tab" data-status="Completed">Completed</button>\r
    <button class="tab" data-status="Cancelled">Cancelled</button>\r
</div>\r
\r
<div class="search-container" id="searchContainer">\r
    <div class="search-box">\r
        <span class="search-icon">⌕</span>\r
        <input type="text" id="searchInput" placeholder="Search order ID or customer...">\r
    </div>\r
</div>\r
\r
<div class="orders-table">\r
\r
    <div class="table-header">\r
        <div>Order ID</div>\r
        <div>Customer</div>\r
        <div>Status</div>\r
        <div>Total</div>\r
        <div>Date</div>\r
        <div>Actions</div>\r
    </div>\r
\r
    <div id="ordersList"></div>\r
\r
    <div class="no-results" id="noResults">\r
        No orders found.\r
    </div>\r
</div>\r
\r
<div class="bottom">\r
    <div id="orderCount">Showing 0 to 0 of 0 orders</div>\r
    <div class="pagination" id="pagination"></div>\r
</div>\r
\r
<div class="section-divider"></div>\r
\r
<div class="section-header">\r
    <div>\r
        <div class="section-title">Products & Inventory</div>\r
        <div class="section-description">\r
            Add, edit, and manage product information, prices, units, categories, availability, images, and stock quantities\r
        </div>\r
    </div>\r
\r
    <button class="add-btn" id="addProductButton" type="button">+ Add Product</button>\r
</div>\r
\r
<div class="product-form" id="productForm">\r
\r
    <div class="form-title">Add / Edit Product</div>\r
\r
    <div class="form-grid">\r
\r
        <div class="form-group">\r
            <label>Product Name</label>\r
            <input type="text" id="productName" placeholder="Enter product name">\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Price</label>\r
            <input type="number" id="productPrice" placeholder="Enter price">\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Unit</label>\r
            <select id="productUnit">\r
                <option value="pc">Piece (pc)</option>\r
                <option value="kg">Kilogram (kg)</option>\r
                <option value="bag">Bag</option>\r
                <option value="box">Box</option>\r
                <option value="meter">Meter</option>\r
            </select>\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Category</label>\r
            <select id="productCategory">\r
                <option value="Construction">Construction</option>\r
                <option value="Electrical">Electrical</option>\r
                <option value="Plumbing">Plumbing</option>\r
                <option value="Tools">Tools</option>\r
                <option value="Others">Others</option>\r
            </select>\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Stock Quantity</label>\r
            <input type="number" id="productStock" placeholder="Enter stock quantity">\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Availability</label>\r
            <select id="productAvailability">\r
                <option value="Available">Available</option>\r
                <option value="Unavailable">Unavailable</option>\r
            </select>\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Product Image</label>\r
            <input type="file" id="productImage" accept="image/*">\r
        </div>\r
\r
    </div>\r
\r
    <div class="form-buttons">\r
        <button class="cancel-form" id="cancelProductButton" type="button">Cancel</button>\r
        <button class="save-product" id="productSaveButton" type="button">Save Product</button>\r
    </div>\r
</div>\r
\r
<div class="search-container">\r
    <div class="search-box">\r
        <span class="search-icon">⌕</span>\r
        <input type="text" id="productSearch" placeholder="Search product...">\r
    </div>\r
</div>\r
\r
<div class="products-table">\r
\r
    <div class="product-header">\r
        <div>Product</div>\r
        <div>Price</div>\r
        <div>Unit</div>\r
        <div>Category</div>\r
        <div>Stock</div>\r
        <div>Availability</div>\r
        <div>Actions</div>\r
    </div>\r
\r
    <div id="productsList"></div>\r
</div>\r
\r
</div>\r
\r
<!-- ORDER MODAL -->\r
\r
<div class="modal-bg" id="modalBg">\r
    <div class="modal">\r
\r
        <h2>Order Details</h2>\r
\r
        <div class="detail">\r
            <label>Order ID</label>\r
            <strong id="modalOrderId"></strong>\r
        </div>\r
\r
        <div class="detail">\r
            <label>Customer</label>\r
            <strong id="modalCustomer"></strong>\r
        </div>\r
\r
        <div class="detail">\r
            <label>Total</label>\r
            <strong id="modalTotal"></strong>\r
        </div>\r
\r
        <div class="detail">\r
            <label>Date</label>\r
            <strong id="modalDate"></strong>\r
        </div>\r
\r
        <div class="detail">\r
            <label>Order Status</label>\r
            <select id="statusSelect" class="status-select">\r
                <option value="Pending">Pending</option>\r
                <option value="Processing">Processing</option>\r
                <option value="Ready for Delivery">Ready for Delivery</option>\r
                <option value="Completed">Completed</option>\r
                <option value="Cancelled">Cancelled</option>\r
            </select>\r
        </div>\r
\r
        <div class="modal-buttons">\r
            <button class="close-btn" id="closeOrderButton" type="button">Close</button>\r
            <button class="save-btn" id="saveOrderStatusButton" type="button">Save Status</button>\r
        </div>\r
\r
    </div>\r
</div>\r
\r
\r
\r
</body>\r
</html>\r
`,Vn=`<!DOCTYPE html>\r
<html lang="en">\r
\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
\r
    <title>Payments - ELEE Hardware</title>\r
\r
    <style>\r
\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
            font-family: Arial, Helvetica, sans-serif;\r
        }\r
\r
        body {\r
            background: #f5f7f6;\r
            min-height: 100vh;\r
        }\r
\r
        .dashboard {\r
            display: flex;\r
            min-height: 100vh;\r
            width: 100%;\r
        }\r
\r
\r
        /* =====================================================\r
           SIDEBAR\r
        ===================================================== */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            z-index: 1000;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
            color: white;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
\r
        /* =====================================================\r
           CONTENT\r
        ===================================================== */\r
\r
        .content {\r
            flex: 1;\r
            min-height: 100vh;\r
            background: #f8faf9;\r
            padding: 35px 40px;\r
            margin-left: 235px;\r
            overflow-x: hidden;\r
        }\r
\r
        .page-header {\r
            margin-bottom: 25px;\r
        }\r
\r
        .page-title {\r
            color: #0b5c25;\r
            font-size: 28px;\r
            font-weight: 700;\r
            margin-bottom: 5px;\r
        }\r
\r
        .page-subtitle {\r
            color: #929292;\r
            font-size: 14px;\r
        }\r
\r
\r
        /* =====================================================\r
           SUMMARY CARDS\r
        ===================================================== */\r
\r
        .summary {\r
            display: grid;\r
            grid-template-columns: repeat(4, 1fr);\r
            gap: 15px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .summary-card {\r
            background: white;\r
            border: 1px solid #e2e7e4;\r
            border-radius: 12px;\r
            padding: 17px;\r
            display: flex;\r
            align-items: center;\r
            gap: 13px;\r
        }\r
\r
        .summary-icon {\r
            width: 43px;\r
            height: 43px;\r
            border-radius: 10px;\r
            background: #e8f7ec;\r
            color: #19803c;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-size: 20px;\r
        }\r
\r
        .summary-info small {\r
            display: block;\r
            color: #999;\r
            font-size: 11px;\r
            margin-bottom: 4px;\r
        }\r
\r
        .summary-info strong {\r
            color: #222;\r
            font-size: 19px;\r
        }\r
\r
\r
        /* =====================================================\r
           FILTERS\r
        ===================================================== */\r
\r
        .filters {\r
            display: grid;\r
            grid-template-columns: 170px 1fr 220px;\r
            gap: 15px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .filter-wrapper {\r
            position: relative;\r
        }\r
\r
        .filter-box {\r
            width: 100%;\r
            height: 46px;\r
            border: 1px solid #dedede;\r
            border-radius: 7px;\r
            background: white;\r
            display: flex;\r
            align-items: center;\r
            justify-content: space-between;\r
            padding: 0 14px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            color: #333;\r
        }\r
\r
        .filter-box:hover {\r
            border-color: #239447;\r
        }\r
\r
        .filter-arrow {\r
            color: #555;\r
        }\r
\r
        .filter-dropdown {\r
            display: none;\r
            position: absolute;\r
            top: 52px;\r
            left: 0;\r
            width: 100%;\r
            background: white;\r
            border: 1px solid #dedede;\r
            border-radius: 7px;\r
            box-shadow: 0 5px 15px rgba(0,0,0,0.12);\r
            z-index: 1000;\r
            overflow: hidden;\r
        }\r
\r
        .filter-dropdown.show {\r
            display: block;\r
        }\r
\r
        .filter-dropdown button {\r
            width: 100%;\r
            padding: 11px 14px;\r
            border: none;\r
            background: white;\r
            text-align: left;\r
            cursor: pointer;\r
            font-size: 12px;\r
            color: #333;\r
        }\r
\r
        .filter-dropdown button:hover {\r
            background: #eaf8ed;\r
            color: #19803c;\r
        }\r
\r
\r
        /* =====================================================\r
           SEARCH\r
        ===================================================== */\r
\r
        .search-box {\r
            height: 46px;\r
            border: 1px solid #dedede;\r
            border-radius: 7px;\r
            background: white;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 14px;\r
            gap: 10px;\r
        }\r
\r
        .search-icon {\r
            font-size: 20px;\r
            color: #555;\r
        }\r
\r
        .search-box input {\r
            border: none;\r
            outline: none;\r
            width: 100%;\r
            font-size: 13px;\r
        }\r
\r
\r
        /* =====================================================\r
           DATE\r
        ===================================================== */\r
\r
        .date-box {\r
            height: 46px;\r
            border: 1px solid #dedede;\r
            border-radius: 7px;\r
            background: white;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 12px;\r
            gap: 8px;\r
        }\r
\r
        .calendar-icon {\r
            font-size: 17px;\r
        }\r
\r
        .date-box input {\r
            border: none;\r
            outline: none;\r
            width: 100%;\r
            font-size: 12px;\r
            background: transparent;\r
        }\r
\r
\r
        /* =====================================================\r
           PAYMENT TABLE\r
        ===================================================== */\r
\r
        .table-card {\r
            background: white;\r
            border: 1px solid #e2e7e4;\r
            border-radius: 12px;\r
            overflow: hidden;\r
        }\r
\r
        .table-wrapper {\r
            width: 100%;\r
            overflow-x: auto;\r
        }\r
\r
        table {\r
            width: 100%;\r
            min-width: 1100px;\r
            border-collapse: collapse;\r
        }\r
\r
        thead {\r
            background: #f8faf9;\r
        }\r
\r
        thead th {\r
            text-align: left;\r
            font-size: 12px;\r
            font-weight: 700;\r
            color: #444;\r
            padding: 16px 12px;\r
            border-bottom: 1px solid #e5e5e5;\r
            white-space: nowrap;\r
        }\r
\r
        tbody td {\r
            font-size: 12px;\r
            color: #222;\r
            padding: 16px 12px;\r
            border-bottom: 1px solid #f0f0f0;\r
            vertical-align: middle;\r
            white-space: nowrap;\r
        }\r
\r
        tbody tr:hover {\r
            background: #fbfdfb;\r
        }\r
\r
\r
        /* =====================================================\r
           PAYMENT METHOD\r
        ===================================================== */\r
\r
        .payment-method {\r
            display: inline-flex;\r
            align-items: center;\r
            gap: 6px;\r
            background: #f1f7f3;\r
            color: #167636;\r
            padding: 6px 9px;\r
            border-radius: 6px;\r
            font-size: 10px;\r
            font-weight: 600;\r
        }\r
\r
        .method-icon {\r
            font-size: 12px;\r
        }\r
\r
\r
        /* =====================================================\r
           STATUS\r
        ===================================================== */\r
\r
        .status {\r
            display: inline-flex;\r
            align-items: center;\r
            justify-content: center;\r
            min-width: 68px;\r
            height: 24px;\r
            padding: 0 9px;\r
            border-radius: 6px;\r
            font-size: 10px;\r
            font-weight: 700;\r
        }\r
\r
        .unpaid {\r
            background: #fff0bd;\r
            color: #966f00;\r
        }\r
\r
        .paid {\r
            background: #b8f2b9;\r
            color: #268238;\r
        }\r
\r
        .cancelled {\r
            background: #ffb6b6;\r
            color: #d83c3c;\r
        }\r
\r
\r
        /* =====================================================\r
           ACTION BUTTONS\r
        ===================================================== */\r
\r
        .actions {\r
            display: flex;\r
            gap: 6px;\r
            flex-wrap: wrap;\r
        }\r
\r
        .action-btn {\r
            border: none;\r
            border-radius: 6px;\r
            padding: 7px 9px;\r
            cursor: pointer;\r
            font-size: 10px;\r
            font-weight: 600;\r
            transition: 0.2s;\r
        }\r
\r
        .action-btn:hover {\r
            opacity: 0.8;\r
        }\r
\r
        .view-btn {\r
            background: #edf5ff;\r
            color: #2766a5;\r
        }\r
\r
        .pay-btn {\r
            background: #dff6e5;\r
            color: #16813a;\r
        }\r
\r
        .undo-btn {\r
            background: #fff0bd;\r
            color: #966f00;\r
        }\r
\r
        .cancel-btn {\r
            background: #ffe8e8;\r
            color: #c93434;\r
        }\r
\r
\r
        /* =====================================================\r
           EMPTY\r
        ===================================================== */\r
\r
        .no-results {\r
            display: none;\r
            text-align: center;\r
            padding: 45px;\r
            color: #999;\r
            font-size: 14px;\r
        }\r
\r
\r
        /* =====================================================\r
           BOTTOM\r
        ===================================================== */\r
\r
        .table-bottom {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            padding: 18px 20px;\r
            gap: 20px;\r
        }\r
\r
        .showing {\r
            color: #929292;\r
            font-size: 12px;\r
            font-weight: 600;\r
        }\r
\r
        .pagination {\r
            display: flex;\r
            align-items: center;\r
            gap: 7px;\r
        }\r
\r
        .page-number,\r
        .next {\r
            width: 28px;\r
            height: 28px;\r
            border: none;\r
            background: transparent;\r
            color: #777;\r
            border-radius: 5px;\r
            cursor: pointer;\r
            font-size: 12px;\r
        }\r
\r
        .page-number:hover,\r
        .next:hover {\r
            background: #eaf8ed;\r
            color: #19803c;\r
        }\r
\r
        .page-number.active {\r
            background: #239447;\r
            color: white;\r
        }\r
\r
        .next:disabled {\r
            color: #ccc;\r
            cursor: not-allowed;\r
            background: transparent;\r
        }\r
\r
        .page-dots {\r
            color: #777;\r
            font-size: 12px;\r
            padding: 0 2px;\r
        }\r
\r
\r
        /* =====================================================\r
           MODAL\r
        ===================================================== */\r
\r
        .modal {\r
            display: none;\r
            position: fixed;\r
            inset: 0;\r
            background: rgba(0,0,0,0.55);\r
            align-items: center;\r
            justify-content: center;\r
            z-index: 9999;\r
            padding: 20px;\r
        }\r
\r
        .modal.show {\r
            display: flex;\r
        }\r
\r
        .modal-content {\r
            width: 470px;\r
            max-width: 100%;\r
            max-height: 90vh;\r
            overflow-y: auto;\r
            background: white;\r
            border-radius: 15px;\r
            padding: 25px;\r
            position: relative;\r
        }\r
\r
        .close-modal {\r
            position: absolute;\r
            right: 15px;\r
            top: 10px;\r
            border: none;\r
            background: transparent;\r
            font-size: 25px;\r
            color: #555;\r
            cursor: pointer;\r
        }\r
\r
        .modal-title {\r
            color: #19803c;\r
            font-size: 21px;\r
            margin-bottom: 5px;\r
        }\r
\r
        .modal-subtitle {\r
            color: #999;\r
            font-size: 12px;\r
            margin-bottom: 20px;\r
        }\r
\r
\r
        /* =====================================================\r
           RECEIPT\r
        ===================================================== */\r
\r
        .receipt {\r
            border: 1px solid #ddd;\r
            border-radius: 10px;\r
            padding: 20px;\r
            background: white;\r
        }\r
\r
        .receipt-header {\r
            text-align: center;\r
            border-bottom: 1px dashed #bbb;\r
            padding-bottom: 15px;\r
            margin-bottom: 15px;\r
        }\r
\r
        .receipt-logo {\r
            color: #00551b;\r
            font-size: 25px;\r
            font-weight: 900;\r
        }\r
\r
        .receipt-logo span {\r
            color: #ffc400;\r
        }\r
\r
        .receipt-title {\r
            color: #777;\r
            font-size: 12px;\r
            margin-top: 4px;\r
        }\r
\r
        .receipt-row {\r
            display: flex;\r
            justify-content: space-between;\r
            gap: 15px;\r
            padding: 7px 0;\r
            font-size: 12px;\r
        }\r
\r
        .receipt-row span:first-child {\r
            color: #888;\r
        }\r
\r
        .receipt-row span:last-child {\r
            color: #222;\r
            font-weight: 600;\r
            text-align: right;\r
        }\r
\r
        .receipt-total {\r
            border-top: 1px dashed #bbb;\r
            margin-top: 10px;\r
            padding-top: 12px;\r
        }\r
\r
        .receipt-total span:last-child {\r
            color: #19803c;\r
            font-size: 17px;\r
        }\r
\r
        .receipt-note {\r
            margin-top: 15px;\r
            background: #eaf8ed;\r
            padding: 10px;\r
            border-radius: 7px;\r
            text-align: center;\r
            color: #19803c;\r
            font-size: 11px;\r
            font-weight: 600;\r
        }\r
\r
        .modal-actions {\r
            display: flex;\r
            gap: 10px;\r
            margin-top: 18px;\r
        }\r
\r
        .modal-btn {\r
            flex: 1;\r
            height: 40px;\r
            border: none;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 12px;\r
            font-weight: 600;\r
        }\r
\r
        .modal-green {\r
            background: #069b45;\r
            color: white;\r
        }\r
\r
        .modal-gray {\r
            background: #eeeeee;\r
            color: #555;\r
        }\r
\r
\r
        /* =====================================================\r
           PAYMENT FLOW\r
        ===================================================== */\r
\r
        .flow-box {\r
            margin-top: 18px;\r
            background: #f7faf8;\r
            border: 1px solid #e5ebe7;\r
            border-radius: 10px;\r
            padding: 15px;\r
        }\r
\r
        .flow-title {\r
            color: #19803c;\r
            font-size: 13px;\r
            font-weight: 700;\r
            margin-bottom: 12px;\r
        }\r
\r
        .flow-step {\r
            display: flex;\r
            align-items: center;\r
            gap: 10px;\r
            margin-bottom: 8px;\r
            font-size: 11px;\r
            color: #555;\r
        }\r
\r
        .flow-number {\r
            width: 22px;\r
            height: 22px;\r
            border-radius: 50%;\r
            background: #dff4e5;\r
            color: #19803c;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-weight: bold;\r
            flex-shrink: 0;\r
        }\r
\r
\r
        /* =====================================================\r
           PRINT\r
        ===================================================== */\r
\r
        @media print {\r
\r
            body * {\r
                visibility: hidden;\r
            }\r
\r
            #receiptModal,\r
            #receiptModal * {\r
                visibility: visible;\r
            }\r
\r
            #receiptModal {\r
                position: absolute;\r
                left: 0;\r
                top: 0;\r
                width: 100%;\r
                background: white;\r
            }\r
\r
            .close-modal,\r
            .modal-actions {\r
                display: none !important;\r
            }\r
\r
            .modal-content {\r
                box-shadow: none;\r
                width: 100%;\r
            }\r
\r
        }\r
\r
\r
        /* =====================================================\r
           RESPONSIVE\r
        ===================================================== */\r
\r
        @media (max-width: 1100px) {\r
\r
            .content {\r
                padding: 30px;\r
            }\r
\r
            .summary {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
            .filters {\r
                grid-template-columns: 1fr 1fr;\r
            }\r
\r
            .date-box {\r
                grid-column: 1 / 3;\r
            }\r
\r
        }\r
\r
\r
        @media (max-width: 800px) {\r
\r
            .dashboard {\r
                flex-direction: column;\r
            }\r
\r
            .sidebar {\r
                position: relative;\r
                width: 100%;\r
                height: auto;\r
                min-height: auto;\r
            }\r
\r
            .content {\r
                margin-left: 0;\r
                padding: 25px 20px;\r
            }\r
\r
            .menu {\r
                display: grid;\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
            .summary {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .filters {\r
                display: flex;\r
                flex-direction: column;\r
            }\r
\r
            .date-box {\r
                width: 100%;\r
            }\r
\r
            .table-bottom {\r
                flex-direction: column;\r
                align-items: flex-start;\r
            }\r
\r
        }\r
\r
    </style>\r
</head>\r
\r
\r
<body>\r
\r
<div class="dashboard">\r
\r
\r
    <!-- =====================================================\r
         SIDEBAR\r
    ===================================================== -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <nav class="menu">\r
\r
            <a href="{{ url('/dashboard') }}">\r
                <span class="icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}">\r
                <span class="icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}">\r
                <span class="icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}" class="active">\r
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}">\r
                <span class="icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}">\r
                <span class="icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </nav>\r
\r
    </aside>\r
\r
\r
\r
    <!-- =====================================================\r
         MAIN CONTENT\r
    ===================================================== -->\r
\r
    <main class="content">\r
\r
\r
        <div class="page-header">\r
\r
            <h1 class="page-title">\r
                Payments\r
            </h1>\r
\r
            <p class="page-subtitle">\r
                Manage customer payments and payment status\r
            </p>\r
\r
        </div>\r
\r
\r
\r
        <!-- =====================================================\r
             SUMMARY\r
        ===================================================== -->\r
\r
        <div class="summary">\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ₱\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Total Payments</small>\r
                    <strong id="totalPayments">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ✓\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Paid</small>\r
                    <strong id="paidCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    !\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Unpaid</small>\r
                    <strong id="unpaidCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    #\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Cancelled</small>\r
                    <strong id="cancelledCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
\r
        <!-- =====================================================\r
             FILTERS\r
        ===================================================== -->\r
\r
        <div class="filters">\r
\r
\r
            <!-- STATUS FILTER -->\r
\r
            <div class="filter-wrapper">\r
\r
                <button\r
                    type="button"\r
                    class="filter-box"\r
                    onclick="toggleFilter()"\r
                >\r
\r
                    <span id="filterText">\r
                        All Payments\r
                    </span>\r
\r
                    <span class="filter-arrow">\r
                        ▾\r
                    </span>\r
\r
                </button>\r
\r
\r
                <div\r
                    class="filter-dropdown"\r
                    id="filterDropdown"\r
                >\r
\r
                    <button\r
                        type="button"\r
                        onclick="filterPayments('all')"\r
                    >\r
                        All Payments\r
                    </button>\r
\r
                    <button\r
                        type="button"\r
                        onclick="filterPayments('unpaid')"\r
                    >\r
                        Unpaid\r
                    </button>\r
\r
                    <button\r
                        type="button"\r
                        onclick="filterPayments('paid')"\r
                    >\r
                        Paid\r
                    </button>\r
\r
                    <button\r
                        type="button"\r
                        onclick="filterPayments('cancelled')"\r
                    >\r
                        Cancelled\r
                    </button>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
\r
            <!-- SEARCH -->\r
\r
            <div class="search-box">\r
\r
                <span class="search-icon">\r
                    ⌕\r
                </span>\r
\r
                <input\r
                    type="text"\r
                    id="searchInput"\r
                    placeholder="Search payment ID, order ID, customer..."\r
                    oninput="applyFilters()"\r
                >\r
\r
            </div>\r
\r
\r
\r
            <!-- DATE -->\r
\r
            <div class="date-box">\r
\r
                <span class="calendar-icon">\r
                    ▣\r
                </span>\r
\r
                <input\r
                    type="date"\r
                    id="dateFilter"\r
                    onchange="applyFilters()"\r
                >\r
\r
            </div>\r
\r
        </div>\r
\r
\r
\r
        <!-- =====================================================\r
             TABLE\r
        ===================================================== -->\r
\r
        <div class="table-card">\r
\r
            <div class="table-wrapper">\r
\r
                <table id="paymentTable">\r
\r
                    <thead>\r
\r
                        <tr>\r
\r
                            <th>Payment ID</th>\r
\r
                            <th>Order ID</th>\r
\r
                            <th>Customer</th>\r
\r
                            <th>Amount</th>\r
\r
                            <th>Payment Method</th>\r
\r
                            <th>Status</th>\r
\r
                            <th>Date</th>\r
\r
                            <th>Actions</th>\r
\r
                        </tr>\r
\r
                    </thead>\r
\r
\r
                    <tbody id="paymentBody"></tbody>\r
\r
                </table>\r
\r
\r
                <div\r
                    class="no-results"\r
                    id="noResults"\r
                >\r
                    No payments found.\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- TABLE BOTTOM -->\r
\r
            <div class="table-bottom">\r
\r
                <div\r
                    class="showing"\r
                    id="showingText"\r
                >\r
                    Showing 0 payments\r
                </div>\r
\r
\r
                <div\r
                    class="pagination"\r
                    id="pagination"\r
                >\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
\r
<!-- =====================================================\r
     PAYMENT DETAILS MODAL\r
===================================================== -->\r
\r
<div\r
    class="modal"\r
    id="paymentModal"\r
>\r
\r
    <div class="modal-content">\r
\r
        <button\r
            class="close-modal"\r
            onclick="closePaymentModal()"\r
        >\r
            ×\r
        </button>\r
\r
\r
        <h2 class="modal-title">\r
            Payment Details\r
        </h2>\r
\r
        <p class="modal-subtitle">\r
            Review the customer's payment information.\r
        </p>\r
\r
\r
        <div class="receipt">\r
\r
            <div class="receipt-header">\r
\r
                <div class="receipt-logo">\r
                    EL<span>EE</span>\r
                </div>\r
\r
                <div class="receipt-title">\r
                    HARDWARE\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="receipt-row">\r
                <span>Payment ID</span>\r
                <span id="detailPaymentId">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Order ID</span>\r
                <span id="detailOrderId">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Customer</span>\r
                <span id="detailCustomer">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Amount</span>\r
                <span id="detailAmount">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Payment Method</span>\r
                <span id="detailMethod">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Status</span>\r
                <span id="detailStatus">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Date</span>\r
                <span id="detailDate">-</span>\r
            </div>\r
\r
\r
            <div\r
                class="flow-box"\r
                id="flowBox"\r
            >\r
\r
                <div class="flow-title">\r
                    Payment Flow\r
                </div>\r
\r
                <div id="flowContent">\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="modal-actions">\r
\r
            <button\r
                class="modal-btn modal-gray"\r
                onclick="closePaymentModal()"\r
            >\r
                Close\r
            </button>\r
\r
            <button\r
                class="modal-btn modal-green"\r
                id="modalPayButton"\r
                onclick="markModalPaymentPaid()"\r
            >\r
                Mark as Paid\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
<!-- =====================================================\r
     PAID RECEIPT MODAL\r
===================================================== -->\r
\r
<div\r
    class="modal"\r
    id="receiptModal"\r
>\r
\r
    <div class="modal-content">\r
\r
        <button\r
            class="close-modal"\r
            onclick="closeReceiptModal()"\r
        >\r
            ×\r
        </button>\r
\r
\r
        <h2 class="modal-title">\r
            Paid Receipt\r
        </h2>\r
\r
        <p class="modal-subtitle">\r
            Physical receipt record\r
        </p>\r
\r
\r
        <div class="receipt">\r
\r
            <div class="receipt-header">\r
\r
                <div class="receipt-logo">\r
                    EL<span>EE</span>\r
                </div>\r
\r
                <div class="receipt-title">\r
                    HARDWARE\r
                </div>\r
\r
                <div\r
                    style="\r
                        color:#19803c;\r
                        font-size:12px;\r
                        font-weight:bold;\r
                        margin-top:8px;\r
                    "\r
                >\r
                    PAID RECEIPT\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="receipt-row">\r
                <span>Payment ID</span>\r
                <span id="receiptPaymentId">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Order ID</span>\r
                <span id="receiptOrderId">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Customer</span>\r
                <span id="receiptCustomer">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Payment Method</span>\r
                <span id="receiptMethod">-</span>\r
            </div>\r
\r
            <div class="receipt-row receipt-total">\r
                <span>Total Paid</span>\r
                <span id="receiptAmount">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Date Paid</span>\r
                <span id="receiptDate">-</span>\r
            </div>\r
\r
\r
            <div class="receipt-note">\r
                Payment received successfully.\r
                Thank you for shopping at ELEE Hardware.\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="modal-actions">\r
\r
            <button\r
                class="modal-btn modal-gray"\r
                onclick="closeReceiptModal()"\r
            >\r
                Close\r
            </button>\r
\r
            <button\r
                class="modal-btn modal-green"\r
                onclick="window.print()"\r
            >\r
                Print Receipt\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
\r
</body>\r
</html>`,Gn=`<!DOCTYPE html>\r
<html lang="en">\r
\r
<head>\r
\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
\r
    <title>EleeSiWeb - Products</title>\r
\r
    <style>\r
\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
            font-family: Arial, Helvetica, sans-serif;\r
        }\r
\r
        body {\r
            background: #fff;\r
            color: #111;\r
        }\r
\r
        .layout {\r
            display: flex;\r
            min-height: 100vh;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            z-index: 100;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
            cursor: pointer;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= MAIN ================= */\r
\r
        .main {\r
            flex: 1;\r
            min-width: 0;\r
            margin-left: 235px;\r
        }\r
\r
        .content {\r
            padding: 28px 25px;\r
        }\r
\r
        .header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: flex-start;\r
        }\r
\r
        .title {\r
            font-size: 30px;\r
            font-weight: 700;\r
            margin-bottom: 3px;\r
        }\r
\r
        .subtitle {\r
            color: #888;\r
            font-size: 14px;\r
        }\r
\r
        .add-btn {\r
            border: none;\r
            background: #069b45;\r
            color: white;\r
            padding: 10px 16px;\r
            border-radius: 9px;\r
            font-size: 13px;\r
            cursor: pointer;\r
        }\r
\r
        .add-btn:hover {\r
            background: #057d38;\r
        }\r
\r
        /* ================= INVENTORY SUMMARY ================= */\r
\r
        .inventory-summary {\r
            display: grid;\r
            grid-template-columns: repeat(4, 1fr);\r
            gap: 15px;\r
            margin-top: 30px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .summary-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 10px;\r
            padding: 18px;\r
            background: white;\r
        }\r
\r
        .summary-title {\r
            font-size: 12px;\r
            color: #888;\r
            margin-bottom: 8px;\r
        }\r
\r
        .summary-number {\r
            font-size: 25px;\r
            font-weight: 700;\r
        }\r
\r
        .summary-green {\r
            color: #069b45;\r
        }\r
\r
        .summary-yellow {\r
            color: #c58a00;\r
        }\r
\r
        .summary-red {\r
            color: #d84848;\r
        }\r
\r
        /* ================= SEARCH ================= */\r
\r
        .search-area {\r
            margin-top: 15px;\r
            margin-bottom: 28px;\r
        }\r
\r
        .search-box {\r
            width: 100%;\r
            height: 48px;\r
            border: 1px solid #ddd;\r
            border-radius: 9px;\r
            display: flex;\r
            align-items: center;\r
        }\r
\r
        .search-icon {\r
            font-size: 27px;\r
            color: #999;\r
            margin-left: 12px;\r
            margin-right: 12px;\r
        }\r
\r
        .search-box input {\r
            width: 100%;\r
            border: none;\r
            outline: none;\r
            font-size: 14px;\r
        }\r
\r
        .filter-area {\r
            display: flex;\r
            justify-content: flex-end;\r
            gap: 10px;\r
            margin-top: 15px;\r
        }\r
\r
        .filter-area select {\r
            border: 1px solid #ddd;\r
            border-radius: 7px;\r
            padding: 8px 12px;\r
            color: #666;\r
            outline: none;\r
            background: white;\r
        }\r
\r
        /* ================= PRODUCT TABLE ================= */\r
\r
        .product-table {\r
            width: 100%;\r
            overflow-x: auto;\r
        }\r
\r
        .product-header,\r
        .product-row {\r
            display: grid;\r
\r
            grid-template-columns:\r
                80px\r
                1.4fr\r
                1.1fr\r
                .7fr\r
                .7fr\r
                .7fr\r
                .8fr\r
                85px;\r
\r
            align-items: center;\r
            column-gap: 15px;\r
            min-width: 900px;\r
        }\r
\r
        .product-header {\r
            font-weight: 700;\r
            font-size: 13px;\r
            padding: 0 10px 16px;\r
        }\r
\r
        .product-row {\r
            min-height: 83px;\r
            border: 1px solid #e5e5e5;\r
            border-radius: 9px;\r
            padding: 10px;\r
            margin-bottom: 14px;\r
            background: white;\r
        }\r
\r
        .product-row:hover {\r
            border-color: #b9dfc5;\r
            box-shadow: 0 2px 8px rgba(0,0,0,.04);\r
        }\r
\r
        /* ================= IMAGE ================= */\r
\r
        .product-image-box {\r
            width: 60px;\r
            height: 55px;\r
            border: 1px solid #e5e5e5;\r
            border-radius: 7px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            overflow: hidden;\r
            background: #fafafa;\r
        }\r
\r
        .product-image {\r
            width: 100%;\r
            height: 100%;\r
            object-fit: contain;\r
        }\r
\r
        .image-placeholder {\r
            font-size: 27px;\r
        }\r
\r
        .product-name {\r
            font-size: 14px;\r
            font-weight: 600;\r
        }\r
\r
        .category {\r
            font-size: 12px;\r
            color: #888;\r
        }\r
\r
        .price,\r
        .stock,\r
        .unit {\r
            font-size: 12px;\r
            font-weight: 600;\r
        }\r
\r
        /* ================= STATUS ================= */\r
\r
        .status {\r
            display: inline-block;\r
            padding: 5px 9px;\r
            border-radius: 5px;\r
            font-size: 10px;\r
            font-weight: 600;\r
        }\r
\r
        .in-stock {\r
            background: #c9f1ce;\r
            color: #258b3e;\r
        }\r
\r
        .low-stock {\r
            background: #fff0c2;\r
            color: #a87500;\r
        }\r
\r
        .out-stock {\r
            background: #ffd6d6;\r
            color: #c53b3b;\r
        }\r
\r
        .unavailable {\r
            background: #eeeeee;\r
            color: #777;\r
        }\r
\r
        /* ================= ACTIONS ================= */\r
\r
        .actions {\r
            display: flex;\r
            gap: 7px;\r
        }\r
\r
        .edit,\r
        .stock-btn,\r
        .delete {\r
            width: 30px;\r
            height: 30px;\r
            border: none;\r
            background: none;\r
            border-radius: 6px;\r
            cursor: pointer;\r
            font-size: 16px;\r
        }\r
\r
        .edit {\r
            color: #777;\r
        }\r
\r
        .edit:hover {\r
            background: #eeeeee;\r
        }\r
\r
        .stock-btn {\r
            color: #069b45;\r
        }\r
\r
        .stock-btn:hover {\r
            background: #e4f5e9;\r
        }\r
\r
        .delete {\r
            color: #e75b5b;\r
        }\r
\r
        .delete:hover {\r
            background: #ffe7e7;\r
        }\r
\r
        /* ================= NO RESULTS ================= */\r
\r
        .no-results {\r
            display: none;\r
            text-align: center;\r
            padding: 35px;\r
            color: #888;\r
            font-size: 14px;\r
            border: 1px solid #eee;\r
            border-radius: 9px;\r
            min-width: 900px;\r
        }\r
\r
        /* ================= STOCK NOTICE ================= */\r
\r
        .stock-notice {\r
            display: flex;\r
            align-items: center;\r
            gap: 10px;\r
            background: #f4faf5;\r
            border: 1px solid #d6eadb;\r
            border-radius: 9px;\r
            padding: 13px 15px;\r
            margin-top: 30px;\r
            color: #397049;\r
            font-size: 12px;\r
        }\r
\r
        .stock-notice strong {\r
            color: #17612d;\r
        }\r
\r
        /* ================= PAGINATION ================= */\r
\r
        .bottom {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            margin-top: 35px;\r
            padding: 0 10px;\r
            gap: 15px;\r
        }\r
\r
        .showing-text {\r
            font-size: 12px;\r
            color: #777;\r
        }\r
\r
        .pagination {\r
            display: flex;\r
            align-items: center;\r
            gap: 6px;\r
        }\r
\r
        .page {\r
            min-width: 30px;\r
            height: 30px;\r
            padding: 0 8px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            border: 1px solid #ddd;\r
            border-radius: 6px;\r
            font-size: 12px;\r
            color: #555;\r
            cursor: pointer;\r
            background: white;\r
            user-select: none;\r
        }\r
\r
        .page:hover:not(.disabled):not(.dots) {\r
            border-color: #299447;\r
            color: #299447;\r
        }\r
\r
        .page.active {\r
            background: #299447;\r
            color: white;\r
            border-color: #299447;\r
        }\r
\r
        .page.disabled {\r
            color: #ccc;\r
            cursor: not-allowed;\r
            background: #f8f8f8;\r
        }\r
\r
        .page.dots {\r
            border: none;\r
            cursor: default;\r
            background: transparent;\r
        }\r
\r
        /* ================= MODAL ================= */\r
\r
        .modal {\r
            display: none;\r
            position: fixed;\r
            inset: 0;\r
            background: rgba(0,0,0,.45);\r
            align-items: center;\r
            justify-content: center;\r
            z-index: 1000;\r
            padding: 20px;\r
        }\r
\r
        .modal-box {\r
            background: white;\r
            width: 470px;\r
            max-width: 100%;\r
            max-height: 92vh;\r
            overflow-y: auto;\r
            border-radius: 12px;\r
            padding: 25px;\r
        }\r
\r
        .modal-box h2 {\r
            margin-bottom: 20px;\r
            font-size: 22px;\r
        }\r
\r
        .form-group {\r
            margin-bottom: 15px;\r
        }\r
\r
        .form-group label {\r
            display: block;\r
            font-size: 13px;\r
            font-weight: 600;\r
            margin-bottom: 6px;\r
        }\r
\r
        .form-group input,\r
        .form-group select {\r
            width: 100%;\r
            padding: 10px;\r
            border: 1px solid #ddd;\r
            border-radius: 7px;\r
            outline: none;\r
            background: white;\r
        }\r
\r
        .form-group input:focus,\r
        .form-group select:focus {\r
            border-color: #069b45;\r
        }\r
\r
        /* ================= IMAGE UPLOAD ================= */\r
\r
        .image-upload-area {\r
            border: 2px dashed #cfcfcf;\r
            border-radius: 9px;\r
            padding: 15px;\r
            text-align: center;\r
            background: #fafafa;\r
        }\r
\r
        .image-upload-area:hover {\r
            border-color: #069b45;\r
        }\r
\r
        .image-upload-area input[type="file"] {\r
            border: none;\r
            padding: 0;\r
            cursor: pointer;\r
        }\r
\r
        .image-preview {\r
            width: 120px;\r
            height: 100px;\r
            object-fit: contain;\r
            border: 1px solid #ddd;\r
            border-radius: 8px;\r
            margin: 10px auto;\r
            display: none;\r
            background: white;\r
        }\r
\r
        .upload-text {\r
            color: #888;\r
            font-size: 12px;\r
            margin-top: 5px;\r
        }\r
\r
        /* ================= AVAILABILITY ================= */\r
\r
        .availability-box {\r
            display: flex;\r
            align-items: center;\r
            gap: 8px;\r
        }\r
\r
        .availability-box input {\r
            width: auto;\r
        }\r
\r
        /* ================= MODAL BUTTONS ================= */\r
\r
        .modal-buttons {\r
            display: flex;\r
            justify-content: flex-end;\r
            gap: 10px;\r
            margin-top: 20px;\r
        }\r
\r
        .cancel-btn {\r
            border: 1px solid #ccc;\r
            background: white;\r
            padding: 9px 15px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
        }\r
\r
        .save-btn {\r
            border: none;\r
            background: #069b45;\r
            color: white;\r
            padding: 9px 15px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
        }\r
\r
        .save-btn:hover {\r
            background: #057d38;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media (max-width: 1000px) {\r
\r
            .sidebar {\r
                width: 190px;\r
            }\r
\r
            .main {\r
                margin-left: 190px;\r
            }\r
\r
            .inventory-summary {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
        }\r
\r
        @media (max-width: 650px) {\r
\r
            .sidebar {\r
                display: none;\r
            }\r
\r
            .main {\r
                margin-left: 0;\r
            }\r
\r
            .content {\r
                padding: 18px;\r
            }\r
\r
            .header {\r
                align-items: center;\r
            }\r
\r
            .title {\r
                font-size: 25px;\r
            }\r
\r
            .add-btn {\r
                padding: 8px 12px;\r
            }\r
\r
            .inventory-summary {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .bottom {\r
                flex-direction: column;\r
                align-items: flex-start;\r
            }\r
\r
        }\r
\r
    </style>\r
\r
</head>\r
\r
\r
<body>\r
\r
\r
<div class="layout">\r
\r
\r
    <!-- ================= SIDEBAR ================= -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <div class="menu">\r
\r
            <a href="{{ url('/') }}">\r
                <span class="icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}" class="active">\r
                <span class="icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}">\r
                <span class="icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}">\r
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}">\r
                <span class="icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}">\r
                <span class="icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </div>\r
\r
    </aside>\r
\r
\r
    <!-- ================= MAIN ================= -->\r
\r
    <main class="main">\r
\r
        <div class="content">\r
\r
\r
            <!-- HEADER -->\r
\r
            <div class="header">\r
\r
                <div>\r
\r
                    <h1 class="title">\r
                        Products & Inventory\r
                    </h1>\r
\r
                    <p class="subtitle">\r
                        Manage products, prices, availability and stock\r
                    </p>\r
\r
                </div>\r
\r
                <button\r
                    class="add-btn"\r
                    onclick="openAddModal()"\r
                >\r
                    + Add Product\r
                </button>\r
\r
            </div>\r
\r
\r
            <!-- ================= INVENTORY SUMMARY ================= -->\r
\r
            <div class="inventory-summary">\r
\r
                <div class="summary-card">\r
\r
                    <div class="summary-title">\r
                        Total Products\r
                    </div>\r
\r
                    <div\r
                        class="summary-number summary-green"\r
                        id="totalProducts"\r
                    >\r
                        0\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="summary-card">\r
\r
                    <div class="summary-title">\r
                        In Stock\r
                    </div>\r
\r
                    <div\r
                        class="summary-number summary-green"\r
                        id="inStockCount"\r
                    >\r
                        0\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="summary-card">\r
\r
                    <div class="summary-title">\r
                        Low Stock\r
                    </div>\r
\r
                    <div\r
                        class="summary-number summary-yellow"\r
                        id="lowStockCount"\r
                    >\r
                        0\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="summary-card">\r
\r
                    <div class="summary-title">\r
                        Out of Stock\r
                    </div>\r
\r
                    <div\r
                        class="summary-number summary-red"\r
                        id="outStockCount"\r
                    >\r
                        0\r
                    </div>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- ================= SEARCH ================= -->\r
\r
            <div class="search-area">\r
\r
                <div class="search-box">\r
\r
                    <span class="search-icon">\r
                        ⌕\r
                    </span>\r
\r
                    <input\r
                        type="text"\r
                        id="searchInput"\r
                        placeholder="Search products..."\r
                        oninput="filterProducts()"\r
                    >\r
\r
                </div>\r
\r
\r
                <div class="filter-area">\r
\r
                    <select\r
                        id="categoryFilter"\r
                        onchange="filterProducts()"\r
                    >\r
\r
                        <option value="all">\r
                            All Categories\r
                        </option>\r
\r
                        <option value="Building Materials">\r
                            Building Materials\r
                        </option>\r
\r
                        <option value="Tools">\r
                            Tools\r
                        </option>\r
\r
                        <option value="Electrical">\r
                            Electrical\r
                        </option>\r
\r
                        <option value="Plumbing">\r
                            Plumbing\r
                        </option>\r
\r
                    </select>\r
\r
\r
                    <select\r
                        id="statusFilter"\r
                        onchange="filterProducts()"\r
                    >\r
\r
                        <option value="all">\r
                            All Status\r
                        </option>\r
\r
                        <option value="In Stock">\r
                            In Stock\r
                        </option>\r
\r
                        <option value="Low Stock">\r
                            Low Stock\r
                        </option>\r
\r
                        <option value="Out of Stock">\r
                            Out of Stock\r
                        </option>\r
\r
                        <option value="Unavailable">\r
                            Unavailable\r
                        </option>\r
\r
                    </select>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- ================= PRODUCT TABLE ================= -->\r
\r
            <div class="product-table">\r
\r
                <div class="product-header">\r
\r
                    <div>Image</div>\r
                    <div>Product Name</div>\r
                    <div>Category</div>\r
                    <div>Price</div>\r
                    <div>Stock</div>\r
                    <div>Unit</div>\r
                    <div>Status</div>\r
                    <div>Actions</div>\r
\r
                </div>\r
\r
\r
                <div id="productList"></div>\r
\r
\r
                <div\r
                    id="noResults"\r
                    class="no-results"\r
                >\r
                    No products found.\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- ================= AUTOMATIC STOCK NOTICE ================= -->\r
\r
            <div class="stock-notice">\r
\r
                <span>\r
                    📦\r
                </span>\r
\r
                <span>\r
                    <strong>Automatic Stock Update:</strong>\r
                    Stock is automatically deducted when an order is confirmed.\r
                    Staff can use the <strong>+</strong> button to add new stock\r
                    when supplies arrive.\r
                </span>\r
\r
            </div>\r
\r
\r
            <!-- ================= PAGINATION ================= -->\r
\r
            <div class="bottom">\r
\r
                <div\r
                    class="showing-text"\r
                    id="showingText"\r
                >\r
                    Showing 0 to 0 of 0 products\r
                </div>\r
\r
                <div\r
                    class="pagination"\r
                    id="pagination"\r
                ></div>\r
\r
            </div>\r
\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
<!-- ================================================= -->\r
<!-- ADD / EDIT PRODUCT MODAL -->\r
<!-- ================================================= -->\r
\r
<div\r
    class="modal"\r
    id="productModal"\r
>\r
\r
    <div class="modal-box">\r
\r
        <h2 id="modalTitle">\r
            Add Product\r
        </h2>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Product Image\r
            </label>\r
\r
            <div class="image-upload-area">\r
\r
                <img\r
                    id="imagePreview"\r
                    class="image-preview"\r
                    alt="Image Preview"\r
                >\r
\r
                <input\r
                    type="file"\r
                    id="productImage"\r
                    accept="image/*"\r
                    onchange="previewImage(event)"\r
                >\r
\r
                <div class="upload-text">\r
                    Choose a product picture\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Product Name\r
            </label>\r
\r
            <input\r
                type="text"\r
                id="productName"\r
                placeholder="Enter product name"\r
            >\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Category\r
            </label>\r
\r
            <select id="productCategory">\r
\r
                <option value="">\r
                    Select category\r
                </option>\r
\r
                <option value="Building Materials">\r
                    Building Materials\r
                </option>\r
\r
                <option value="Tools">\r
                    Tools\r
                </option>\r
\r
                <option value="Electrical">\r
                    Electrical\r
                </option>\r
\r
                <option value="Plumbing">\r
                    Plumbing\r
                </option>\r
\r
            </select>\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Price\r
            </label>\r
\r
            <input\r
                type="number"\r
                id="productPrice"\r
                min="0"\r
                step="0.01"\r
                placeholder="Enter price"\r
            >\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Unit\r
            </label>\r
\r
            <select id="productUnit">\r
\r
                <option value="">\r
                    Select unit\r
                </option>\r
\r
                <option value="piece">\r
                    Piece\r
                </option>\r
\r
                <option value="set">\r
                    Set\r
                </option>\r
\r
                <option value="box">\r
                    Box\r
                </option>\r
\r
                <option value="meter">\r
                    Meter\r
                </option>\r
\r
                <option value="kg">\r
                    Kilogram\r
                </option>\r
\r
                <option value="liter">\r
                    Liter\r
                </option>\r
\r
            </select>\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Stock Quantity\r
            </label>\r
\r
            <input\r
                type="number"\r
                id="productStock"\r
                min="0"\r
                placeholder="Enter stock quantity"\r
            >\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Availability\r
            </label>\r
\r
            <div class="availability-box">\r
\r
                <input\r
                    type="checkbox"\r
                    id="productAvailability"\r
                    checked\r
                >\r
\r
                <span>\r
                    Product is available for ordering\r
                </span>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="modal-buttons">\r
\r
            <button\r
                class="cancel-btn"\r
                onclick="closeModal()"\r
            >\r
                Cancel\r
            </button>\r
\r
            <button\r
                class="save-btn"\r
                onclick="saveProduct()"\r
                id="saveButton"\r
            >\r
                Add Product\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
<!-- ================================================= -->\r
<!-- ADD STOCK MODAL -->\r
<!-- ================================================= -->\r
\r
<div\r
    class="modal"\r
    id="stockModal"\r
>\r
\r
    <div class="modal-box">\r
\r
        <h2>\r
            Add New Stock\r
        </h2>\r
\r
\r
        <p\r
            id="stockProductName"\r
            style="\r
                font-size:13px;\r
                color:#777;\r
                margin-bottom:18px;\r
            "\r
        >\r
            Product\r
        </p>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Current Stock\r
            </label>\r
\r
            <input\r
                type="number"\r
                id="currentStock"\r
                readonly\r
            >\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Quantity to Add\r
            </label>\r
\r
            <input\r
                type="number"\r
                id="stockToAdd"\r
                min="1"\r
                placeholder="Enter quantity"\r
            >\r
\r
        </div>\r
\r
\r
        <div\r
            style="\r
                background:#f4faf5;\r
                border:1px solid #d6eadb;\r
                padding:12px;\r
                border-radius:7px;\r
                font-size:12px;\r
                color:#397049;\r
            "\r
        >\r
            New stock will be added to the existing quantity.\r
        </div>\r
\r
\r
        <div class="modal-buttons">\r
\r
            <button\r
                class="cancel-btn"\r
                onclick="closeStockModal()"\r
            >\r
                Cancel\r
            </button>\r
\r
            <button\r
                class="save-btn"\r
                onclick="addStock()"\r
            >\r
                Add Stock\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
</body>\r
\r
</html>`,Qn=`<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Queue - ELEE Hardware</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: Arial, Helvetica, sans-serif; }
        body { background: #f5f7f6; color: #17211b; }
        .sidebar { position: fixed; inset: 0 auto 0 0; width: 235px; background: #00551f; color: white; padding: 28px 16px; z-index: 10; }
        .logo { font-size: 36px; font-weight: 900; margin-left: 12px; letter-spacing: -2px; }
        .logo span { color: #ffbd00; }
        .hardware { color: #ffbd00; font-size: 14px; font-weight: bold; margin: 3px 0 25px 13px; }
        .menu { display: flex; flex-direction: column; gap: 7px; }
        .menu a { color: white; text-decoration: none; padding: 13px 14px; border-radius: 7px; font-size: 14px; display: flex; align-items: center; gap: 12px; }
        .menu a:hover, .menu a.active { background: #08732e; }
        .main { margin-left: 235px; padding: 42px; min-height: 100vh; }
        .section-header { display: flex; justify-content: space-between; align-items: center; gap: 20px; margin-bottom: 25px; }
        .section-title { color: #147a36; font-size: 27px; font-weight: 700; }
        .section-description { color: #748078; font-size: 14px; margin-top: 6px; }
        .orders-link { display: inline-flex; padding: 11px 16px; border-radius: 8px; background: #08752f; color: #fff; font-size: 14px; text-decoration: none; font-weight: 600; white-space: nowrap; }
        .summary { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; margin-bottom: 22px; }
        .summary-card { background: #fff; border: 1px solid #e7ece8; border-radius: 12px; padding: 18px 20px; box-shadow: 0 2px 8px #12301508; }
        .summary-label { color: #78827b; font-size: 13px; margin-bottom: 10px; }
        .summary-value { color: #075b27; font-size: 27px; font-weight: 700; }
        .queue-panel { background: #fff; border: 1px solid #e7ece8; border-radius: 12px; overflow: hidden; }
        .queue-toolbar { display: flex; justify-content: space-between; align-items: center; gap: 14px; padding: 18px 20px; border-bottom: 1px solid #edf0ed; }
        .queue-toolbar h2 { font-size: 17px; }
        .controls { display: flex; gap: 10px; }
        .controls input, .controls select { height: 40px; border: 1px solid #dce3dd; border-radius: 7px; padding: 0 11px; background: white; color: #26352b; font-size: 13px; }
        .controls input { width: 235px; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; min-width: 740px; border-collapse: collapse; text-align: left; }
        th { color: #718077; background: #fafcfb; font-size: 12px; font-weight: 600; padding: 14px 16px; white-space: nowrap; }
        td { padding: 16px; border-top: 1px solid #eff2ef; font-size: 13px; }
        .position { width: 52px; color: #13813c; font-size: 16px; font-weight: 700; }
        .order-id { color: #147a36; font-weight: 700; white-space: nowrap; }
        .customer-name { font-weight: 600; }
        .order-time { color: #718077; white-space: nowrap; }
        .status { display: inline-block; border-radius: 20px; padding: 6px 10px; background: #fff2cd; color: #896400; font-size: 11px; font-weight: 700; white-space: nowrap; }
        .status.processing { background: #e7efff; color: #345ca0; }
        .status.ready { background: #e2f5e8; color: #167338; }
        .status.completed { background: #e9eeee; color: #56625b; }
        .status.cancelled { background: #ffebeb; color: #af3838; }
        .total { font-weight: 700; white-space: nowrap; }
        .empty { display: none; padding: 48px 20px; color: #77827a; text-align: center; font-size: 14px; }
        .empty strong { display: block; color: #36463b; font-size: 16px; margin-bottom: 7px; }
        .queue-footer { padding: 14px 20px; border-top: 1px solid #edf0ed; color: #748078; font-size: 12px; }
        @media(max-width: 1050px) { .sidebar { width: 195px; } .main { margin-left: 195px; padding: 30px 24px; } .queue-toolbar { align-items: flex-start; flex-direction: column; } .controls { width: 100%; } .controls input { flex: 1; } }
        @media(max-width: 700px) { .sidebar { position: static; width: 100%; height: auto; } .menu { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); } .main { margin: 0; padding: 24px 16px; } .section-header { align-items: flex-start; flex-direction: column; } .summary { grid-template-columns: 1fr; gap: 10px; } .summary-card { padding: 15px 17px; } .summary-value { font-size: 23px; } .controls { flex-direction: column; } .controls input { width: 100%; flex: initial; } }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="logo"><span style="color:white">E</span><span>LEE</span></div>
        <div class="hardware">HARDWARE</div>
        <nav class="menu">
            <a href="/"><span class="icon">☼</span><span>Dashboard</span></a>
            <a href="/orders"><span class="icon">▣</span><span>Orders</span></a>
            <a href="/products"><span class="icon">◇</span><span>Products</span></a>
            <a href="/ai-recommendations"><span class="icon">↗</span><span>AI Recommendations</span></a>
            <a href="/payments"><span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span><span>Payments</span></a>
            <a href="/customers"><span class="icon">♙</span><span>Customers</span></a>
            <a href="/queuing" class="active"><span class="icon">☷</span><span>Queuing</span></a>
            <a href="/receipt-records"><span class="icon">▤</span><span>Receipt Records</span></a>
            <a href="/settings"><span class="icon">⚙</span><span>Settings</span></a>
        </nav>
    </aside>

    <main class="main">
        <header class="section-header">
            <div>
                <h1 class="section-title">Order Queue</h1>
                <p class="section-description">Orders are lined up by the time they were placed. Oldest orders are served first.</p>
            </div>
            <a class="orders-link" href="/orders">Manage orders</a>
        </header>

        <section class="summary" aria-label="Queue summary">
            <div class="summary-card"><div class="summary-label">Active orders in queue</div><div class="summary-value" id="activeCount">0</div></div>
            <div class="summary-card"><div class="summary-label">Waiting for processing</div><div class="summary-value" id="pendingCount">0</div></div>
            <div class="summary-card"><div class="summary-label">Next order</div><div class="summary-value" id="nextOrder" style="font-size:18px">—</div></div>
        </section>

        <section class="queue-panel">
            <div class="queue-toolbar">
                <h2>Customer order sequence</h2>
                <div class="controls">
                    <input id="queueSearch" type="search" placeholder="Search order or customer" oninput="renderQueue()" aria-label="Search queue">
                    <select id="statusFilter" onchange="renderQueue()" aria-label="Filter by order status">
                        <option value="active">Active orders</option>
                        <option value="all">All orders</option>
                        <option value="Pending">Pending</option>
                        <option value="Processing">Processing</option>
                        <option value="Ready for Delivery">Ready for Delivery</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                    <select id="sortBy" onchange="renderQueue()" aria-label="Sort queue">
                        <option value="oldest">Oldest order first (FIFO)</option>
                        <option value="newest">Newest order first</option>
                        <option value="customer">Customer A–Z</option>
                        <option value="amount">Highest amount</option>
                    </select>
                </div>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Queue</th><th>Order</th><th>Customer</th><th>Placed</th><th>Status</th><th>Total</th></tr></thead>
                    <tbody id="queueRows"></tbody>
                </table>
            </div>
            <div class="empty" id="queueEmpty"><strong>No orders in this view</strong>New customer orders will appear here in the order they are received.</div>
            <div class="queue-footer" id="queueFooter">Showing 0 orders</div>
        </section>
    </main>

    
</body>
</html>
`,Kn=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
    <title>Receipt Records - ELEE Hardware</title>\r
\r
    <style>\r
        * {\r
            box-sizing: border-box;\r
            margin: 0;\r
            padding: 0;\r
            font-family: Arial, sans-serif;\r
        }\r
\r
        body {\r
            background: #f5f5f5;\r
            color: #222;\r
        }\r
\r
        .layout {\r
            display: flex;\r
            min-height: 100vh;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            z-index: 100;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= MAIN ================= */\r
\r
        .main {\r
            flex: 1;\r
            background: white;\r
            padding: 40px 50px;\r
            min-width: 0;\r
            margin-left: 235px;\r
        }\r
\r
        .page-title {\r
            color: #075b21;\r
            font-size: 30px;\r
            font-weight: bold;\r
        }\r
\r
        .subtitle {\r
            color: #888;\r
            margin-top: 5px;\r
            margin-bottom: 28px;\r
        }\r
\r
        /* ================= SUMMARY ================= */\r
\r
        .summary {\r
            display: grid;\r
            grid-template-columns: repeat(4, 1fr);\r
            gap: 16px;\r
            margin-bottom: 28px;\r
        }\r
\r
        .summary-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 10px;\r
            padding: 18px;\r
            background: white;\r
        }\r
\r
        .summary-card .label {\r
            color: #777;\r
            font-size: 13px;\r
            margin-bottom: 8px;\r
        }\r
\r
        .summary-card .number {\r
            font-size: 25px;\r
            font-weight: bold;\r
            color: #075b21;\r
        }\r
\r
        .summary-card.paid .number {\r
            color: #16853b;\r
        }\r
\r
        .summary-card.unpaid .number {\r
            color: #d88a00;\r
        }\r
\r
        /* ================= TOOLBAR ================= */\r
\r
        .toolbar {\r
            display: flex;\r
            gap: 15px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .search-box {\r
            flex: 1;\r
            height: 50px;\r
            border: 1px solid #ddd;\r
            border-radius: 9px;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 16px;\r
        }\r
\r
        .search-box span {\r
            font-size: 24px;\r
            color: #666;\r
            margin-right: 12px;\r
        }\r
\r
        .search-box input {\r
            border: none;\r
            outline: none;\r
            width: 100%;\r
            font-size: 14px;\r
        }\r
\r
        .filter-box {\r
            height: 50px;\r
            min-width: 190px;\r
            border: 1px solid #ddd;\r
            border-radius: 9px;\r
            padding: 0 14px;\r
            outline: none;\r
            background: white;\r
            cursor: pointer;\r
            color: #444;\r
        }\r
\r
        /* ================= TABLE ================= */\r
\r
        .table-wrapper {\r
            width: 100%;\r
            overflow-x: auto;\r
        }\r
\r
        table {\r
            width: 100%;\r
            border-collapse: collapse;\r
            min-width: 800px;\r
        }\r
\r
        th {\r
            text-align: left;\r
            padding: 15px 12px;\r
            font-size: 13px;\r
            color: #333;\r
            background: #fafafa;\r
            border-bottom: 1px solid #ddd;\r
        }\r
\r
        td {\r
            padding: 16px 12px;\r
            border-bottom: 1px solid #eee;\r
            font-size: 13px;\r
        }\r
\r
        .order-id {\r
            color: #075b21;\r
            font-weight: bold;\r
        }\r
\r
        .amount {\r
            font-weight: bold;\r
        }\r
\r
        /* ================= STATUS ================= */\r
\r
        .status {\r
            display: inline-flex;\r
            align-items: center;\r
            gap: 6px;\r
            padding: 5px 10px;\r
            border-radius: 20px;\r
            font-size: 11px;\r
            font-weight: bold;\r
        }\r
\r
        .status.paid {\r
            background: #e5f7ea;\r
            color: #16853b;\r
        }\r
\r
        .status.unpaid {\r
            background: #fff3d6;\r
            color: #b87500;\r
        }\r
\r
        .status-dot {\r
            width: 6px;\r
            height: 6px;\r
            border-radius: 50%;\r
            background: currentColor;\r
        }\r
\r
        .payment-method {\r
            color: #555;\r
            font-size: 12px;\r
        }\r
\r
        /* ================= BUTTON ================= */\r
\r
        .view-btn {\r
            border: 1px solid #16a34a;\r
            color: #12813b;\r
            background: white;\r
            padding: 7px 17px;\r
            border-radius: 5px;\r
            cursor: pointer;\r
            font-size: 12px;\r
            transition: .2s;\r
        }\r
\r
        .view-btn:hover {\r
            background: #12813b;\r
            color: white;\r
        }\r
\r
        /* ================= EMPTY ================= */\r
\r
        .empty {\r
            text-align: center;\r
            padding: 50px;\r
            color: #999;\r
        }\r
\r
        /* ================= BOTTOM ================= */\r
\r
        .bottom {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            margin-top: 25px;\r
            color: #777;\r
            font-size: 13px;\r
        }\r
\r
        .pagination {\r
            display: flex;\r
            gap: 6px;\r
            align-items: center;\r
        }\r
\r
        .page {\r
            padding: 7px 11px;\r
            cursor: pointer;\r
            border-radius: 5px;\r
        }\r
\r
        .page:hover {\r
            background: #e8f5eb;\r
        }\r
\r
        .page.active {\r
            background: #239447;\r
            color: white;\r
        }\r
\r
        /* ================= MODAL ================= */\r
\r
        .modal-overlay {\r
            display: none;\r
            position: fixed;\r
            z-index: 999;\r
            inset: 0;\r
            background: rgba(0,0,0,.55);\r
            align-items: center;\r
            justify-content: center;\r
            padding: 20px;\r
        }\r
\r
        .modal-overlay.show {\r
            display: flex;\r
        }\r
\r
        .receipt-modal {\r
            background: white;\r
            width: 680px;\r
            max-width: 100%;\r
            max-height: 92vh;\r
            overflow-y: auto;\r
            border-radius: 10px;\r
            padding: 28px;\r
            box-shadow: 0 10px 40px rgba(0,0,0,.25);\r
        }\r
\r
        .modal-title {\r
            display: flex;\r
            align-items: center;\r
            gap: 10px;\r
            margin-bottom: 20px;\r
        }\r
\r
        .receipt-icon {\r
            width: 34px;\r
            height: 34px;\r
            background: #1c9142;\r
            color: white;\r
            display: flex;\r
            justify-content: center;\r
            align-items: center;\r
            border-radius: 6px;\r
        }\r
\r
        .modal-title h2 {\r
            font-size: 18px;\r
        }\r
\r
        .modal-title p {\r
            font-size: 11px;\r
            color: #999;\r
            margin-top: 3px;\r
        }\r
\r
        /* ================= RECEIPT PAPER ================= */\r
\r
        .receipt-paper {\r
            border: 1px solid #ddd;\r
            padding: 25px;\r
        }\r
\r
        .receipt-header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: flex-start;\r
            padding-bottom: 18px;\r
            border-bottom: 1px solid #ddd;\r
        }\r
\r
        .receipt-logo {\r
            font-size: 32px;\r
            font-weight: 900;\r
            color: #00a52a;\r
        }\r
\r
        .receipt-logo span {\r
            color: #ffb000;\r
        }\r
\r
        .receipt-hardware {\r
            color: #ffb000;\r
            font-size: 9px;\r
            font-weight: bold;\r
        }\r
\r
        .receipt-type {\r
            text-align: right;\r
        }\r
\r
        .receipt-type strong {\r
            display: block;\r
            color: #168537;\r
            font-size: 12px;\r
        }\r
\r
        .receipt-type span {\r
            font-size: 10px;\r
            color: #888;\r
        }\r
\r
        /* ================= RECEIPT INFO ================= */\r
\r
        .receipt-info {\r
            display: grid;\r
            grid-template-columns: 1fr 1fr;\r
            margin-top: 16px;\r
            border-bottom: 1px solid #ddd;\r
            padding-bottom: 15px;\r
        }\r
\r
        .info-box {\r
            padding: 8px 10px;\r
            font-size: 11px;\r
        }\r
\r
        .info-box:nth-child(odd) {\r
            border-right: 1px solid #ddd;\r
        }\r
\r
        .info-label {\r
            color: #777;\r
            margin-bottom: 5px;\r
        }\r
\r
        .info-value {\r
            font-weight: bold;\r
        }\r
\r
        /* ================= CUSTOMER ================= */\r
\r
        .customer-section {\r
            margin-top: 15px;\r
            padding-bottom: 15px;\r
            border-bottom: 1px solid #ddd;\r
        }\r
\r
        .customer-title {\r
            font-size: 11px;\r
            color: #777;\r
            margin-bottom: 5px;\r
        }\r
\r
        .customer-name {\r
            font-size: 13px;\r
            font-weight: bold;\r
        }\r
\r
        .customer-phone {\r
            font-size: 10px;\r
            color: #666;\r
            margin-top: 3px;\r
        }\r
\r
        /* ================= ITEMS ================= */\r
\r
        .items-title {\r
            margin-top: 18px;\r
            background: #e8f6e9;\r
            padding: 9px;\r
            font-size: 11px;\r
            font-weight: bold;\r
        }\r
\r
        .items-table {\r
            width: 100%;\r
            min-width: 0;\r
            border-collapse: collapse;\r
        }\r
\r
        .items-table th {\r
            background: #f3faf4;\r
            font-size: 10px;\r
            padding: 9px;\r
        }\r
\r
        .items-table td {\r
            font-size: 10px;\r
            padding: 9px;\r
            border-bottom: 1px solid #eee;\r
        }\r
\r
        /* ================= TOTAL ================= */\r
\r
        .totals {\r
            margin-top: 15px;\r
            margin-left: auto;\r
            width: 260px;\r
        }\r
\r
        .total-row {\r
            display: flex;\r
            justify-content: space-between;\r
            padding: 5px 0;\r
            font-size: 11px;\r
        }\r
\r
        .total-row.final {\r
            border-top: 1px solid #bbb;\r
            margin-top: 5px;\r
            padding-top: 10px;\r
            font-weight: bold;\r
            font-size: 14px;\r
            color: #075b21;\r
        }\r
\r
        /* ================= MODAL ACTIONS ================= */\r
\r
        .modal-actions {\r
            display: flex;\r
            justify-content: flex-end;\r
            gap: 10px;\r
            margin-top: 16px;\r
        }\r
\r
        .close-btn {\r
            background: white;\r
            border: 1px solid #ddd;\r
            padding: 9px 18px;\r
            border-radius: 5px;\r
            cursor: pointer;\r
        }\r
\r
        .print-btn {\r
            background: #238f45;\r
            border: none;\r
            color: white;\r
            padding: 9px 18px;\r
            border-radius: 5px;\r
            cursor: pointer;\r
        }\r
\r
        .print-btn:hover {\r
            background: #176d32;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media(max-width: 1000px) {\r
\r
            .sidebar {\r
                width: 200px;\r
            }\r
\r
            .main {\r
                margin-left: 200px;\r
                padding: 30px;\r
            }\r
\r
            .summary {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
        }\r
\r
        @media(max-width: 700px) {\r
\r
            .layout {\r
                display: block;\r
            }\r
\r
            .sidebar {\r
                position: relative;\r
                width: 100%;\r
                height: auto;\r
                min-height: auto;\r
                padding: 20px;\r
            }\r
\r
            .menu {\r
                display: grid;\r
                grid-template-columns: repeat(2, 1fr);\r
                gap: 7px;\r
            }\r
\r
            .menu a {\r
                margin: 0;\r
            }\r
\r
            .main {\r
                margin-left: 0;\r
                padding: 25px 18px;\r
            }\r
\r
            .summary {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .toolbar {\r
                flex-direction: column;\r
            }\r
\r
            .filter-box {\r
                width: 100%;\r
            }\r
\r
            .bottom {\r
                flex-direction: column;\r
                gap: 15px;\r
                align-items: flex-start;\r
            }\r
\r
            .receipt-paper {\r
                padding: 15px;\r
            }\r
\r
        }\r
\r
        /* ================= PRINT ================= */\r
\r
        @media print {\r
\r
            body * {\r
                visibility: hidden;\r
            }\r
\r
            .receipt-modal,\r
            .receipt-modal * {\r
                visibility: visible;\r
            }\r
\r
            .receipt-modal {\r
                position: absolute;\r
                left: 0;\r
                top: 0;\r
                width: 100%;\r
                max-width: none;\r
                max-height: none;\r
                box-shadow: none;\r
                border-radius: 0;\r
            }\r
\r
            .modal-actions {\r
                display: none;\r
            }\r
\r
        }\r
    </style>\r
</head>\r
\r
<body>\r
\r
<div class="layout">\r
\r
    <!-- ================= SIDEBAR ================= -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <div class="menu">\r
\r
            <a href="{{ url('/') }}">\r
                <span class="icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}">\r
                <span class="icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}">\r
                <span class="icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}">\r
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}">\r
                <span class="icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}" class="active">\r
                <span class="icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </div>\r
\r
    </aside>\r
\r
\r
    <!-- ================= MAIN ================= -->\r
\r
    <main class="main">\r
\r
        <h1 class="page-title">Receipt Records</h1>\r
\r
        <p class="subtitle">\r
            View and manage order receipts, totals, payment methods, and payment status.\r
        </p>\r
\r
\r
        <!-- ================= SUMMARY ================= -->\r
\r
        <div class="summary">\r
\r
            <div class="summary-card">\r
                <div class="label">Total Orders</div>\r
                <div class="number" id="totalOrders">0</div>\r
            </div>\r
\r
            <div class="summary-card">\r
                <div class="label">Total Amount</div>\r
                <div class="number" id="totalAmount">₱0.00</div>\r
            </div>\r
\r
            <div class="summary-card paid">\r
                <div class="label">Paid Orders</div>\r
                <div class="number" id="paidOrders">0</div>\r
            </div>\r
\r
            <div class="summary-card unpaid">\r
                <div class="label">Unpaid Orders</div>\r
                <div class="number" id="unpaidOrders">0</div>\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= TOOLBAR ================= -->\r
\r
        <div class="toolbar">\r
\r
            <div class="search-box">\r
                <span>⌕</span>\r
\r
                <input\r
                    type="text"\r
                    id="searchInput"\r
                    placeholder="Search receipt, order, or customer..."\r
                    oninput="renderReceipts()"\r
                >\r
            </div>\r
\r
            <select\r
                class="filter-box"\r
                id="statusFilter"\r
                onchange="renderReceipts()"\r
            >\r
                <option value="all">All Payment Status</option>\r
                <option value="Paid">Paid</option>\r
                <option value="Unpaid">Unpaid</option>\r
            </select>\r
\r
        </div>\r
\r
\r
        <!-- ================= TABLE ================= -->\r
\r
        <div class="table-wrapper">\r
\r
            <table>\r
\r
                <thead>\r
                    <tr>\r
                        <th>Receipt No.</th>\r
                        <th>Order ID</th>\r
                        <th>Customer</th>\r
                        <th>Order Total</th>\r
                        <th>Payment Method</th>\r
                        <th>Payment Status</th>\r
                        <th>Date</th>\r
                        <th>Action</th>\r
                    </tr>\r
                </thead>\r
\r
                <tbody id="receiptTableBody"></tbody>\r
\r
            </table>\r
\r
        </div>\r
\r
\r
        <!-- ================= BOTTOM ================= -->\r
\r
        <div class="bottom">\r
\r
            <div id="showingText">\r
                Showing 0 orders\r
            </div>\r
\r
            <div class="pagination">\r
\r
                <span class="page active">\r
                    1\r
                </span>\r
\r
            </div>\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
<!-- ================= RECEIPT MODAL ================= -->\r
\r
<div\r
    class="modal-overlay"\r
    id="receiptModal"\r
    onclick="closeOutside(event)"\r
>\r
\r
    <div class="receipt-modal">\r
\r
        <div class="modal-title">\r
\r
            <div class="receipt-icon">\r
                ▣\r
            </div>\r
\r
            <div>\r
                <h2>View Receipt</h2>\r
\r
                <p>\r
                    Order and payment details\r
                </p>\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="receipt-paper">\r
\r
            <div class="receipt-header">\r
\r
                <div>\r
\r
                    <div class="receipt-logo">\r
                        EL<span>EE</span>\r
                    </div>\r
\r
                    <div class="receipt-hardware">\r
                        HARDWARE\r
                    </div>\r
\r
                </div>\r
\r
                <div class="receipt-type">\r
\r
                    <strong>ORDER RECEIPT</strong>\r
\r
                    <span>\r
                        Thank you for your purchase\r
                    </span>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="receipt-info">\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Receipt No.\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalReceiptNo">\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Order ID\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalOrderId">\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Date\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalDate">\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Payment Method\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalPaymentMethod">\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Payment Status\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalPaymentStatus">\r
                    </div>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="customer-section">\r
\r
                <div class="customer-title">\r
                    Customer\r
                </div>\r
\r
                <div\r
                    class="customer-name"\r
                    id="modalCustomer">\r
                </div>\r
\r
                <div\r
                    class="customer-phone"\r
                    id="modalPhone">\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="items-title">\r
                Items Ordered\r
            </div>\r
\r
            <table class="items-table">\r
\r
                <thead>\r
\r
                    <tr>\r
                        <th>Product</th>\r
                        <th>Qty</th>\r
                        <th>Unit Price</th>\r
                        <th>Subtotal</th>\r
                    </tr>\r
\r
                </thead>\r
\r
                <tbody id="modalItems"></tbody>\r
\r
            </table>\r
\r
\r
            <div class="totals">\r
\r
                <div class="total-row">\r
\r
                    <span>\r
                        Subtotal\r
                    </span>\r
\r
                    <span id="modalSubtotal">\r
                        ₱0.00\r
                    </span>\r
\r
                </div>\r
\r
\r
                <div class="total-row">\r
\r
                    <span>\r
                        Delivery Fee\r
                    </span>\r
\r
                    <span id="modalDeliveryFee">\r
                        ₱0.00\r
                    </span>\r
\r
                </div>\r
\r
\r
                <div class="total-row final">\r
\r
                    <span>\r
                        Order Total\r
                    </span>\r
\r
                    <span id="modalTotal">\r
                        ₱0.00\r
                    </span>\r
\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="modal-actions">\r
\r
            <button\r
                class="close-btn"\r
                onclick="closeReceipt()"\r
            >\r
                Close\r
            </button>\r
\r
            <button\r
                class="print-btn"\r
                onclick="printReceipt()"\r
            >\r
                🖨 Print Receipt\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
</body>\r
</html>`,Jn=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
    <title>Settings - ELEE Hardware</title>\r
\r
    <style>\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
        }\r
\r
        body {\r
            font-family: Arial, sans-serif;\r
            background: #f5f7f5;\r
            color: #333;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= MAIN ================= */\r
\r
        .main {\r
            margin-left: 235px;\r
            padding: 38px 45px;\r
            min-height: 100vh;\r
        }\r
\r
        .page-title {\r
            font-size: 30px;\r
            font-weight: bold;\r
            color: #075b21;\r
            margin-bottom: 6px;\r
        }\r
\r
        .page-subtitle {\r
            color: #777;\r
            margin-bottom: 28px;\r
        }\r
\r
        /* ================= TABS ================= */\r
\r
        .setting-tabs {\r
            display: flex;\r
            gap: 9px;\r
            flex-wrap: wrap;\r
            margin-bottom: 22px;\r
        }\r
\r
        .setting-tab {\r
            border: 1px solid #e0e0e0;\r
            background: white;\r
            color: #555;\r
            padding: 11px 17px;\r
            border-radius: 8px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            transition: .2s;\r
        }\r
\r
        .setting-tab:hover {\r
            background: #e9f7ec;\r
            color: #087f23;\r
        }\r
\r
        .setting-tab.active {\r
            background: #087f23;\r
            border-color: #087f23;\r
            color: white;\r
        }\r
\r
        /* ================= CONTENT ================= */\r
\r
        .tab-content {\r
            display: none;\r
            background: white;\r
            padding: 28px;\r
            border-radius: 12px;\r
            box-shadow: 0 2px 8px rgba(0,0,0,.07);\r
            max-width: 900px;\r
        }\r
\r
        .tab-content.active {\r
            display: block;\r
        }\r
\r
        .section-header {\r
            margin-bottom: 24px;\r
            padding-bottom: 16px;\r
            border-bottom: 1px solid #eee;\r
        }\r
\r
        .section-title {\r
            font-size: 21px;\r
            font-weight: bold;\r
            color: #222;\r
            margin-bottom: 5px;\r
        }\r
\r
        .section-description {\r
            color: #888;\r
            font-size: 13px;\r
        }\r
\r
        /* ================= FORM ================= */\r
\r
        .form-grid {\r
            display: grid;\r
            grid-template-columns: 1fr 1fr;\r
            gap: 18px;\r
        }\r
\r
        .full-width {\r
            grid-column: 1 / -1;\r
        }\r
\r
        .form-group {\r
            margin-bottom: 4px;\r
        }\r
\r
        .form-group label {\r
            display: block;\r
            margin-bottom: 7px;\r
            font-size: 13px;\r
            font-weight: bold;\r
            color: #444;\r
        }\r
\r
        .form-group input,\r
        .form-group select,\r
        .form-group textarea {\r
            width: 100%;\r
            padding: 11px 12px;\r
            border: 1px solid #d5d5d5;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            outline: none;\r
            background: white;\r
            transition: .2s;\r
        }\r
\r
        .form-group input:focus,\r
        .form-group select:focus,\r
        .form-group textarea:focus {\r
            border-color: #087f23;\r
            box-shadow: 0 0 0 2px rgba(8,127,35,.08);\r
        }\r
\r
        .form-group textarea {\r
            min-height: 95px;\r
            resize: vertical;\r
        }\r
\r
        .hint {\r
            font-size: 11px;\r
            color: #888;\r
            margin-top: 5px;\r
        }\r
\r
        /* ================= INFO BOX ================= */\r
\r
        .info-box {\r
            padding: 15px 17px;\r
            background: #f1f8f2;\r
            border-left: 4px solid #087f23;\r
            border-radius: 6px;\r
            margin-bottom: 22px;\r
            color: #4d4d4d;\r
            font-size: 13px;\r
            line-height: 1.5;\r
        }\r
\r
        /* ================= PAYMENT CARDS ================= */\r
\r
        .option-list {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 12px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .option-card {\r
            display: flex;\r
            align-items: center;\r
            gap: 14px;\r
            border: 1px solid #ddd;\r
            border-radius: 9px;\r
            padding: 16px;\r
            cursor: pointer;\r
            transition: .2s;\r
        }\r
\r
        .option-card:hover {\r
            border-color: #087f23;\r
            background: #f8fcf8;\r
        }\r
\r
        .option-card input {\r
            width: 18px;\r
            height: 18px;\r
            accent-color: #087f23;\r
            cursor: pointer;\r
        }\r
\r
        .option-icon {\r
            width: 40px;\r
            height: 40px;\r
            background: #eaf6ed;\r
            color: #087f23;\r
            border-radius: 8px;\r
            display: flex;\r
            justify-content: center;\r
            align-items: center;\r
            font-size: 20px;\r
        }\r
\r
        .option-info {\r
            flex: 1;\r
        }\r
\r
        .option-title {\r
            font-weight: bold;\r
            font-size: 14px;\r
            margin-bottom: 3px;\r
        }\r
\r
        .option-description {\r
            color: #888;\r
            font-size: 11px;\r
        }\r
\r
        /* ================= NOTIFICATIONS ================= */\r
\r
        .notification-list {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 12px;\r
            margin-bottom: 24px;\r
        }\r
\r
        .notification-item {\r
            display: flex;\r
            align-items: center;\r
            justify-content: space-between;\r
            gap: 15px;\r
            padding: 16px;\r
            border: 1px solid #e2e2e2;\r
            border-radius: 9px;\r
        }\r
\r
        .notification-left {\r
            display: flex;\r
            align-items: center;\r
            gap: 13px;\r
        }\r
\r
        .notification-icon {\r
            width: 40px;\r
            height: 40px;\r
            background: #eaf6ed;\r
            color: #087f23;\r
            border-radius: 8px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-size: 18px;\r
        }\r
\r
        .notification-name {\r
            font-size: 14px;\r
            font-weight: bold;\r
        }\r
\r
        .notification-description {\r
            color: #888;\r
            font-size: 11px;\r
            margin-top: 3px;\r
        }\r
\r
        /* ================= SWITCH ================= */\r
\r
        .switch {\r
            position: relative;\r
            width: 45px;\r
            height: 24px;\r
            flex-shrink: 0;\r
        }\r
\r
        .switch input {\r
            opacity: 0;\r
            width: 0;\r
            height: 0;\r
        }\r
\r
        .slider {\r
            position: absolute;\r
            inset: 0;\r
            background: #ccc;\r
            border-radius: 30px;\r
            cursor: pointer;\r
            transition: .2s;\r
        }\r
\r
        .slider:before {\r
            content: "";\r
            position: absolute;\r
            width: 18px;\r
            height: 18px;\r
            left: 3px;\r
            top: 3px;\r
            background: white;\r
            border-radius: 50%;\r
            transition: .2s;\r
            box-shadow: 0 1px 3px rgba(0,0,0,.2);\r
        }\r
\r
        .switch input:checked + .slider {\r
            background: #087f23;\r
        }\r
\r
        .switch input:checked + .slider:before {\r
            transform: translateX(21px);\r
        }\r
\r
        /* ================= ACCOUNT ================= */\r
\r
        .account-card {\r
            display: flex;\r
            align-items: center;\r
            gap: 15px;\r
            padding: 18px;\r
            background: #f8faf8;\r
            border: 1px solid #e5e5e5;\r
            border-radius: 9px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .account-avatar {\r
            width: 55px;\r
            height: 55px;\r
            background: #087f23;\r
            color: white;\r
            border-radius: 50%;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-size: 23px;\r
            font-weight: bold;\r
        }\r
\r
        .account-name {\r
            font-weight: bold;\r
            font-size: 15px;\r
        }\r
\r
        .account-role {\r
            color: #888;\r
            font-size: 12px;\r
            margin-top: 3px;\r
        }\r
\r
        /* ================= BUTTON ================= */\r
\r
        .save-btn {\r
            background: #087f23;\r
            color: white;\r
            border: none;\r
            padding: 11px 23px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            font-weight: bold;\r
            transition: .2s;\r
        }\r
\r
        .save-btn:hover {\r
            background: #06691c;\r
        }\r
\r
        .secondary-btn {\r
            background: white;\r
            color: #087f23;\r
            border: 1px solid #087f23;\r
            padding: 10px 20px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 13px;\r
        }\r
\r
        .secondary-btn:hover {\r
            background: #eaf6ed;\r
        }\r
\r
        .button-row {\r
            display: flex;\r
            gap: 10px;\r
            margin-top: 22px;\r
        }\r
\r
        /* ================= TOAST ================= */\r
\r
        .toast {\r
            position: fixed;\r
            right: 25px;\r
            bottom: 25px;\r
            background: #087f23;\r
            color: white;\r
            padding: 14px 20px;\r
            border-radius: 8px;\r
            box-shadow: 0 5px 20px rgba(0,0,0,.2);\r
            font-size: 13px;\r
            display: flex;\r
            align-items: center;\r
            gap: 10px;\r
            transform: translateY(100px);\r
            opacity: 0;\r
            pointer-events: none;\r
            transition: .3s;\r
            z-index: 2000;\r
        }\r
\r
        .toast.show {\r
            transform: translateY(0);\r
            opacity: 1;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media(max-width: 900px) {\r
\r
            .sidebar {\r
                width: 210px;\r
            }\r
\r
            .main {\r
                margin-left: 210px;\r
                padding: 25px;\r
            }\r
\r
            .form-grid {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .full-width {\r
                grid-column: auto;\r
            }\r
        }\r
\r
        @media(max-width: 650px) {\r
\r
            .sidebar {\r
                position: relative;\r
                width: 100%;\r
                height: auto;\r
                padding: 20px;\r
            }\r
\r
            .menu {\r
                display: grid;\r
                grid-template-columns: 1fr 1fr;\r
            }\r
\r
            .menu a {\r
                padding: 11px 15px;\r
            }\r
\r
            .main {\r
                margin-left: 0;\r
                padding: 20px 15px;\r
            }\r
\r
            .page-title {\r
                font-size: 25px;\r
            }\r
\r
            .tab-content {\r
                padding: 20px;\r
            }\r
\r
            .setting-tabs {\r
                display: grid;\r
                grid-template-columns: 1fr 1fr;\r
            }\r
\r
            .setting-tab {\r
                width: 100%;\r
            }\r
\r
            .notification-item {\r
                align-items: flex-start;\r
            }\r
        }\r
    </style>\r
</head>\r
\r
<body>\r
\r
<!-- ================= SIDEBAR ================= -->\r
\r
<div class="sidebar">\r
\r
    <div class="logo">\r
        <span style="color:white;">E</span><span>LEE</span>\r
    </div>\r
\r
    <div class="hardware">\r
        HARDWARE\r
    </div>\r
\r
    <div class="menu">\r
\r
        <a href="{{ url('/') }}">\r
            <span class="icon">☼</span>\r
            Dashboard\r
        </a>\r
\r
        <a href="{{ url('/orders') }}">\r
            <span class="icon">▣</span>\r
            Orders\r
        </a>\r
\r
        <a href="{{ url('/products') }}">\r
            <span class="icon">◇</span>\r
            Products\r
        </a>\r
\r
        <a href="{{ url('/ai-recommendations') }}">\r
            <span class="icon">↗</span>\r
            AI Recommendations\r
        </a>\r
\r
        <a href="{{ url('/payments') }}">\r
            <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
            Payments\r
        </a>\r
\r
        <a href="{{ url('/customers') }}">\r
            <span class="icon">♙</span>\r
            Customers\r
        </a>\r
\r
        <a href="{{ url('/queuing') }}">\r
            <span class="icon">▱</span>\r
            Queuing\r
        </a>\r
\r
        <a href="{{ url('/receipt-records') }}">\r
            <span class="icon">▤</span>\r
            Receipt Records\r
        </a>\r
\r
        <a href="{{ url('/settings') }}" class="active">\r
            <span class="icon">⚙</span>\r
            Settings\r
        </a>\r
\r
    </div>\r
</div>\r
\r
\r
<!-- ================= MAIN ================= -->\r
\r
<main class="main settings-page">\r
\r
    <h1 class="page-title">\r
        Settings\r
    </h1>\r
\r
    <p class="page-subtitle">\r
        Manage your store information, payment options, notifications, and admin account.\r
    </p>\r
\r
\r
    <!-- ================= TABS ================= -->\r
\r
    <div class="setting-tabs">\r
\r
        <button\r
            type="button"\r
            class="setting-tab active"\r
            onclick="openTab('general', this)"\r
        >\r
            ⚙️ General\r
        </button>\r
\r
        <button\r
            type="button"\r
            class="setting-tab"\r
            onclick="openTab('store', this)"\r
        >\r
            🏪 Store Information\r
        </button>\r
\r
        <button\r
            type="button"\r
            class="setting-tab"\r
            onclick="openTab('payment', this)"\r
        >\r
            💳 Payment Methods\r
        </button>\r
\r
        <button\r
            type="button"\r
            class="setting-tab"\r
            onclick="openTab('notification', this)"\r
        >\r
            🔔 Notifications\r
        </button>\r
\r
        <button\r
            type="button"\r
            class="setting-tab"\r
            onclick="openTab('account', this)"\r
        >\r
            👤 Admin Account\r
        </button>\r
\r
    </div>\r
\r
\r
    <!-- GENERAL SETTINGS -->\r
\r
    <section id="general" class="tab-content active">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                General Settings\r
            </h2>\r
\r
            <p class="section-description">\r
                Manage the basic settings of the ELEE Hardware system.\r
            </p>\r
\r
        </div>\r
\r
        <div class="info-box">\r
            These settings control the basic information displayed\r
            throughout the store management system.\r
        </div>\r
\r
        <div class="form-grid">\r
\r
            <div class="form-group">\r
                <label>System Name</label>\r
                <input\r
                    type="text"\r
                    id="systemName"\r
                    value="ELEE Hardware"\r
                >\r
            </div>\r
\r
            <div class="form-group">\r
                <label>Language</label>\r
\r
                <!-- ENGLISH ONLY -->\r
                <select id="language">\r
                    <option value="English">English</option>\r
                </select>\r
\r
            </div>\r
\r
        </div>\r
\r
        <div class="button-row">\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="saveGeneralSettings()"\r
            >\r
                Save Settings\r
            </button>\r
        </div>\r
\r
    </section>\r
\r
\r
    <!-- STORE INFORMATION -->\r
\r
    <section id="store" class="tab-content">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                Store Information\r
            </h2>\r
\r
            <p class="section-description">\r
                Update the basic information of your hardware store.\r
            </p>\r
\r
        </div>\r
\r
        <div class="form-grid">\r
\r
            <div class="form-group">\r
                <label>Store Name</label>\r
                <input\r
                    type="text"\r
                    id="storeName"\r
                    value="ELEE Hardware"\r
                >\r
            </div>\r
\r
            <div class="form-group">\r
                <label>Contact Number</label>\r
                <input\r
                    type="text"\r
                    id="storeContact"\r
                    placeholder="Enter contact number"\r
                >\r
            </div>\r
\r
            <div class="form-group full-width">\r
                <label>Store Address</label>\r
                <textarea\r
                    id="storeAddress"\r
                    placeholder="Enter store address"\r
                ></textarea>\r
            </div>\r
\r
            <div class="form-group">\r
                <label>Email Address</label>\r
                <input\r
                    type="email"\r
                    id="storeEmail"\r
                    placeholder="Enter store email"\r
                >\r
            </div>\r
\r
            <div class="form-group">\r
                <label>Store Status</label>\r
                <select id="storeStatus">\r
                    <option value="Open">Open</option>\r
                    <option value="Closed">Closed</option>\r
                </select>\r
            </div>\r
\r
        </div>\r
\r
        <div class="button-row">\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="saveStoreSettings()"\r
            >\r
                Save Store Information\r
            </button>\r
        </div>\r
\r
    </section>\r
\r
\r
    <!-- PAYMENT METHODS -->\r
\r
    <section id="payment" class="tab-content">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                Payment Methods\r
            </h2>\r
\r
            <p class="section-description">\r
                Select the payment methods available to customers.\r
            </p>\r
\r
        </div>\r
\r
        <div class="info-box">\r
            The system currently supports cash payments for\r
            Cash at Store and Cash on Delivery orders.\r
        </div>\r
\r
        <div class="option-list">\r
\r
            <label class="option-card">\r
\r
                <input\r
                    type="checkbox"\r
                    id="cashStore"\r
                    checked\r
                >\r
\r
                <div class="option-icon">\r
                    🏪\r
                </div>\r
\r
                <div class="option-info">\r
\r
                    <div class="option-title">\r
                        Cash at Store\r
                    </div>\r
\r
                    <div class="option-description">\r
                        Customer pays the order at the physical store.\r
                    </div>\r
\r
                </div>\r
\r
            </label>\r
\r
\r
            <label class="option-card">\r
\r
                <input\r
                    type="checkbox"\r
                    id="cashDelivery"\r
                    checked\r
                >\r
\r
                <div class="option-icon">\r
                    🚚\r
                </div>\r
\r
                <div class="option-info">\r
\r
                    <div class="option-title">\r
                        Cash on Delivery\r
                    </div>\r
\r
                    <div class="option-description">\r
                        Customer pays cash when the order is delivered.\r
                    </div>\r
\r
                </div>\r
\r
            </label>\r
\r
        </div>\r
\r
        <div class="button-row">\r
\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="savePaymentSettings()"\r
            >\r
                Save Payment Settings\r
            </button>\r
\r
        </div>\r
\r
    </section>\r
\r
\r
    <!-- NOTIFICATIONS -->\r
\r
    <section id="notification" class="tab-content">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                Notifications\r
            </h2>\r
\r
            <p class="section-description">\r
                Choose which alerts should be shown to staff.\r
            </p>\r
\r
        </div>\r
\r
        <div class="info-box">\r
            Notifications help staff monitor new orders, changes,\r
            cancellations, and products that are running low in stock.\r
        </div>\r
\r
        <div class="notification-list">\r
\r
            <div class="notification-item">\r
\r
                <div class="notification-left">\r
\r
                    <div class="notification-icon">\r
                        🛒\r
                    </div>\r
\r
                    <div>\r
\r
                        <div class="notification-name">\r
                            New Orders\r
                        </div>\r
\r
                        <div class="notification-description">\r
                            Alert staff when a new order is received.\r
                        </div>\r
\r
                    </div>\r
\r
                </div>\r
\r
                <label class="switch">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="notifyNewOrders"\r
                        checked\r
                    >\r
\r
                    <span class="slider"></span>\r
\r
                </label>\r
\r
            </div>\r
\r
\r
            <div class="notification-item">\r
\r
                <div class="notification-left">\r
\r
                    <div class="notification-icon">\r
                        ✏️\r
                    </div>\r
\r
                    <div>\r
\r
                        <div class="notification-name">\r
                            Order Changes\r
                        </div>\r
\r
                        <div class="notification-description">\r
                            Alert staff when an existing order is changed.\r
                        </div>\r
\r
                    </div>\r
\r
                </div>\r
\r
                <label class="switch">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="notifyOrderChanges"\r
                        checked\r
                    >\r
\r
                    <span class="slider"></span>\r
\r
                </label>\r
\r
            </div>\r
\r
\r
            <div class="notification-item">\r
\r
                <div class="notification-left">\r
\r
                    <div class="notification-icon">\r
                        ❌\r
                    </div>\r
\r
                    <div>\r
\r
                        <div class="notification-name">\r
                            Order Cancellations\r
                        </div>\r
\r
                        <div class="notification-description">\r
                            Alert staff when an order is cancelled.\r
                        </div>\r
\r
                    </div>\r
\r
                </div>\r
\r
                <label class="switch">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="notifyCancellations"\r
                        checked\r
                    >\r
\r
                    <span class="slider"></span>\r
\r
                </label>\r
\r
            </div>\r
\r
\r
            <div class="notification-item">\r
\r
                <div class="notification-left">\r
\r
                    <div class="notification-icon">\r
                        ⚠️\r
                    </div>\r
\r
                    <div>\r
\r
                        <div class="notification-name">\r
                            Low-Stock Products\r
                        </div>\r
\r
                        <div class="notification-description">\r
                            Alert staff when product inventory reaches a low level.\r
                        </div>\r
\r
                    </div>\r
\r
                </div>\r
\r
                <label class="switch">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="notifyLowStock"\r
                        checked\r
                    >\r
\r
                    <span class="slider"></span>\r
\r
                </label>\r
\r
            </div>\r
\r
        </div>\r
\r
        <div class="button-row">\r
\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="saveNotificationSettings()"\r
            >\r
                Save Notification Settings\r
            </button>\r
\r
        </div>\r
\r
    </section>\r
\r
\r
    <!-- ADMIN ACCOUNT -->\r
\r
    <section id="account" class="tab-content">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                Admin Account\r
            </h2>\r
\r
            <p class="section-description">\r
                Manage the administrator account information.\r
            </p>\r
\r
        </div>\r
\r
        <div class="account-card">\r
\r
            <div class="account-avatar">\r
                A\r
            </div>\r
\r
            <div>\r
\r
                <div\r
                    class="account-name"\r
                    id="accountDisplayName"\r
                >\r
                    Administrator\r
                </div>\r
\r
                <div class="account-role">\r
                    Store Administrator\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
        <div class="form-grid">\r
\r
            <div class="form-group">\r
\r
                <label>Admin Name</label>\r
\r
                <input\r
                    type="text"\r
                    id="adminName"\r
                    value="Administrator"\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>Username</label>\r
\r
                <input\r
                    type="text"\r
                    id="adminUsername"\r
                    value="admin"\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>Email Address</label>\r
\r
                <input\r
                    type="email"\r
                    id="adminEmail"\r
                    placeholder="admin@example.com"\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>Role</label>\r
\r
                <select id="adminRole">\r
\r
                    <option value="Administrator">\r
                        Administrator\r
                    </option>\r
\r
                    <option value="Staff">\r
                        Staff\r
                    </option>\r
\r
                </select>\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>New Password</label>\r
\r
                <input\r
                    type="password"\r
                    id="adminPassword"\r
                    placeholder="Enter new password"\r
                >\r
\r
                <div class="hint">\r
                    Leave blank if you do not want to change the password.\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>Confirm Password</label>\r
\r
                <input\r
                    type="password"\r
                    id="confirmPassword"\r
                    placeholder="Confirm new password"\r
                >\r
\r
            </div>\r
\r
        </div>\r
\r
        <div class="button-row">\r
\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="saveAccountSettings()"\r
            >\r
                Save Account Settings\r
            </button>\r
\r
        </div>\r
\r
    </section>\r
\r
</main>\r
\r
\r
<!-- ================= TOAST ================= -->\r
\r
<div class="toast" id="toast">\r
\r
    <span>✓</span>\r
\r
    <span id="toastMessage">\r
        Settings saved successfully!\r
    </span>\r
\r
</div>\r
\r
\r
\r
\r
</body>\r
</html>\r
`,Zn=".legacy-screen{--admin-sidebar-width: 244px;--admin-page-gutter: 36px;--admin-text: #202a24;--admin-muted: #6e7b73;min-height:100vh;background:#f7f9f7;color:var(--admin-text);line-height:1.5}.legacy-screen .sidebar{position:fixed;inset:0 auto 0 0;width:var(--admin-sidebar-width);height:100vh;min-height:0;padding:24px 14px;overflow-y:auto}.legacy-screen .logo{margin-left:12px;font-size:33px;line-height:1.1;letter-spacing:-1.5px}.legacy-screen .hardware{margin:4px 0 22px 13px;font-size:12px;letter-spacing:.06em}.legacy-screen .menu{gap:4px}.legacy-screen .menu a{min-height:44px;padding:9px 12px;gap:10px;border-radius:8px;font-size:13px;line-height:1.3}.legacy-screen .menu-icon,.legacy-screen .menu .icon{display:inline-flex;flex:0 0 22px;width:22px;height:22px;align-items:center;justify-content:center;font-size:17px;line-height:1}.legacy-screen .menu-icon svg,.legacy-screen .menu .icon svg,.legacy-screen .menu a>svg{display:block;width:18px;height:18px;flex:0 0 18px}.legacy-screen .main{box-sizing:border-box;flex:1 1 0%;width:auto;min-width:0;margin-left:var(--admin-sidebar-width);padding:32px var(--admin-page-gutter)}.legacy-screen .main:has(>.content){padding:0}.legacy-screen .content{box-sizing:border-box;flex:1 1 0%;width:auto;min-width:0;padding:32px var(--admin-page-gutter)}.legacy-screen .dashboard>.content{margin-left:var(--admin-sidebar-width)}.legacy-screen .dashboard>.main{margin-left:var(--admin-sidebar-width)}.legacy-screen .section-header,.legacy-screen .page-header,.legacy-screen .header{align-items:flex-start;gap:18px;margin-bottom:24px}.legacy-screen .section-title,.legacy-screen .page-title,.legacy-screen .page-header h1,.legacy-screen .header h1,.legacy-screen .title{color:#137a37;font-family:Arial,Helvetica,sans-serif;font-size:27px;line-height:1.25;letter-spacing:-.02em}.legacy-screen .page-header h1{background:transparent}.legacy-screen .header h1{font-size:27px;font-weight:700}.legacy-screen .customer-page{width:auto;min-width:0;margin-left:var(--admin-sidebar-width);margin-right:0;padding:32px var(--admin-page-gutter)}.legacy-screen .settings-page .tab-content{width:100%;max-width:none}.legacy-screen .section-description,.legacy-screen .page-subtitle,.legacy-screen .subtitle,.legacy-screen .header p{color:var(--admin-muted);font-size:14px;line-height:1.5}.legacy-screen .summary-grid,.legacy-screen .summary-cards,.legacy-screen .summary{gap:16px}.legacy-screen .search-container,.legacy-screen .search-box,.legacy-screen input:not([type=checkbox]):not([type=radio]),.legacy-screen select{min-width:0}.legacy-screen input:not([type=checkbox]):not([type=radio]),.legacy-screen select,.legacy-screen textarea{border-radius:8px}.legacy-screen button{border-radius:8px}.legacy-screen .table-container,.legacy-screen .table-wrapper,.legacy-screen .orders-table,.legacy-screen .table-wrap{max-width:100%;overflow-x:auto}.legacy-screen table th,.legacy-screen table td{padding:12px 16px;vertical-align:middle}.legacy-screen .table-header,.legacy-screen .order-row{min-height:64px;align-items:center}.legacy-screen .status{line-height:1.25}.legacy-screen .status.pending,.legacy-screen .badge-pending{background:#fff3d6;color:#ffb300}.legacy-screen .status.processing{background:#e8f2ff;color:#307fd9}.legacy-screen .status.ready,.legacy-screen .badge-ready{background:#efd7ff;color:#7800a8}.legacy-screen .status.completed,.legacy-screen .badge-completed{background:#e7f8e8;color:#13ae16}.legacy-screen .status.cancelled{background:#fde8e8;color:#ea1e1e}.legacy-screen .status-dot.pending{background:#ffb300}.legacy-screen .status-dot.processing{background:#307fd9}.legacy-screen .status-dot.ready{background:#8e00c7}.legacy-screen .status-dot.completed{background:#13ae16}.legacy-screen .badge-cancelled{background:#fde8e8;color:#ea1e1e}@media(max-width:1000px){.legacy-screen{--admin-sidebar-width: 220px;--admin-page-gutter: 26px}}@media(max-width:760px){.legacy-screen .dashboard,.legacy-screen .layout{display:block}.legacy-screen .sidebar{position:relative;inset:auto;width:100%;height:auto;min-height:0;padding:18px 16px}.legacy-screen .menu{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}.legacy-screen .menu a{min-height:40px;padding:8px;gap:7px;font-size:12px}.legacy-screen .menu-icon,.legacy-screen .menu .icon{flex-basis:20px;width:20px}.legacy-screen .main,.legacy-screen .content,.legacy-screen .dashboard>.main,.legacy-screen .dashboard>.content{width:100%;margin-left:0;padding:24px 18px}.legacy-screen .main:has(>.content){padding:0}.legacy-screen .section-header,.legacy-screen .page-header,.legacy-screen .header{flex-wrap:wrap}.legacy-screen .summary-grid,.legacy-screen .summary-cards,.legacy-screen .summary{grid-template-columns:repeat(2,minmax(0,1fr))}.legacy-screen .tabs{display:flex;max-width:100%;overflow-x:auto;gap:8px}.legacy-screen .tabs .tab{flex:0 0 auto}}@media(max-width:520px){.legacy-screen{--admin-page-gutter: 18px}.legacy-screen .menu{grid-template-columns:repeat(2,minmax(0,1fr))}.legacy-screen .section-title,.legacy-screen .page-title,.legacy-screen .page-header h1,.legacy-screen .header h1,.legacy-screen .title{font-size:23px}.legacy-screen .summary-grid,.legacy-screen .summary-cards,.legacy-screen .summary{grid-template-columns:1fr}}";function Xn({product:e,products:a,save:o,busy:g}){const[c,u]=l.useState(e.recommended_product_ids||[]),[m,x]=l.useState("");return n.jsxs("form",{className:"recommendation-editor",onSubmit:async t=>{t.preventDefault(),x(""),await o(e.id,c)&&x("Recommendations saved. Customers will see these products in their cart.")},children:[n.jsxs("h3",{children:["Related products for ",e.name]}),n.jsx("p",{children:"Choose up to 20 products. Hidden and out-of-stock products are excluded from customer suggestions."}),n.jsx("div",{className:"recommendation-options",children:a.filter(t=>t.id!==e.id).map(t=>n.jsxs("label",{children:[n.jsx("input",{type:"checkbox",checked:c.includes(t.id),disabled:g||!c.includes(t.id)&&c.length>=20,onChange:s=>u(h=>s.target.checked?[...h,t.id]:h.filter(A=>A!==t.id))}),n.jsxs("span",{children:[n.jsx("strong",{children:t.name}),n.jsxs("small",{children:[t.category," · ₱",t.price.toFixed(2)," · ",t.is_active?`${t.stock} in stock`:"Hidden"]})]})]},t.id))}),n.jsx("button",{disabled:g,type:"submit",children:g?"Saving…":"Save recommendations"}),m&&n.jsx("p",{role:"status",children:m})]})}const nr=Object.assign({"../legacy/admin-login.html":Fn,"../legacy/ai-recommendations.html":Hn,"../legacy/customers.html":$n,"../legacy/dashboard.html":Yn,"../legacy/orders.html":Wn,"../legacy/payments.html":Vn,"../legacy/products.html":Gn,"../legacy/queuing.html":Qn,"../legacy/receipt-records.html":Kn,"../legacy/settings.html":Jn}),R=e=>new Intl.NumberFormat("en-PH",{style:"currency",currency:"PHP"}).format(e),an=e=>new Intl.DateTimeFormat("en-PH",{dateStyle:"medium",timeStyle:"short",timeZone:"Asia/Manila"}).format(new Date(e)),zn=e=>["Completed","Cancelled"].includes(e.order_status);function Rn(e){var u,m,x;const a=nr[`../legacy/${e}.html`].replace(/\{\{\s*url\('([^']+)'\)\s*\}\}/g,"$1").replace(/@if\s*\(session\('error'\)\)[\s\S]*?@endif/g,"").replace(/@csrf/g,""),o=new DOMParser().parseFromString(a,"text/html"),g=[...o.querySelectorAll("style")].map(t=>t.textContent).join(`
`);o.querySelectorAll('script, style, .modal-overlay, .modal-bg, [id$="Modal"], #productForm, .toast').forEach(t=>t.remove()),o.querySelectorAll("*").forEach(t=>{[...t.attributes].filter(s=>s.name.startsWith("on")).forEach(s=>{s.name==="onclick"&&(t.dataset.originalAction=s.value),t.removeAttribute(s.name)})}),o.querySelectorAll("tbody").forEach(t=>t.replaceChildren()),o.querySelectorAll(".card-number, .card-change, .payment-value, .donut-number, .status-item strong").forEach(t=>{t.textContent="—"}),o.querySelectorAll(".sidebar a").forEach(t=>{const s=t.getAttribute("href");if(s!=null&&s.includes("logout")){t.href="#sign-out";return}const h=s==="/"?"dashboard":s==null?void 0:s.replace(/^\//,"");t.href=`/admin/${h}`,t.classList.toggle("active",h===e)});const c=new Set(["dashboard","orders","products","queuing","customers","payments","receipt-records","settings","ai-recommendations"]);if(o.querySelectorAll("a[href]").forEach(t=>{const s=t.getAttribute("href"),h=s==="/"?"dashboard":s==null?void 0:s.replace(/^\//,"");c.has(h)&&(t.href=`/admin/${h}`)}),e==="queuing"){const t=o.createElement("option");t.value="Ready for Pickup",t.textContent="Ready for Pickup",(u=o.querySelector("#statusFilter"))==null||u.append(t)}if(e==="orders"){const t=o.querySelector(".main > .section-divider");if(t){for(;t.nextElementSibling;)t.nextElementSibling.remove();t.remove()}const s=o.querySelector(".tabs"),h=o.createElement("button");h.className="tab",h.dataset.status="Ready for Pickup",h.textContent="Ready for Pickup",s==null||s.append(h)}if(e==="ai-recommendations"){(m=o.querySelector(".add-btn"))==null||m.remove();const t=o.querySelector(".page-title");t&&(t.textContent="Product Recommendations");const s=o.querySelector(".page-subtitle");s&&(s.textContent="Manage related products shown in the customer cart"),o.querySelectorAll("*").forEach(h=>{h.children.length===0&&h.textContent.includes("AI recommendations help")&&(h.textContent="Related products selected here appear in the customer cart.")})}if(e!=="admin-login"&&!o.querySelector('.sidebar a[href="#sign-out"]')){const t=o.createElement("a");t.href="#sign-out",t.className="logout",t.textContent="↪ Logout",(x=o.querySelector(".sidebar .menu"))==null||x.append(t)}if(e==="settings"){const t=o.querySelector("#general");t&&t.replaceChildren(),o.querySelectorAll(".tab-content:not(#general), .tabs, .setting-tabs").forEach(s=>s.remove())}return{html:o.body.innerHTML,css:g}}function rr({children:e}){const a=l.useMemo(()=>Rn("admin-login"),[]),o=l.useRef(null),[g,c]=l.useState(null);return l.useLayoutEffect(()=>{const u=o.current.querySelector("form"),m=document.createElement("div");u.replaceWith(m),c(m)},[]),n.jsxs("div",{className:"legacy-screen original-login",children:[n.jsx("style",{children:a.css}),n.jsx("div",{ref:o,dangerouslySetInnerHTML:{__html:a.html}}),g&&nn.createPortal(e,g)]})}function er({page:e,data:a,loading:o,busy:g,error:c,navigate:u,logout:m,refresh:x,actions:t,editProduct:s,details:h,settings:A,saveRecommendations:M}){var wn,kn,Sn,En,jn;const Y=l.useMemo(()=>Rn(e),[e]),L=l.useRef(null),[E,V]=l.useState({}),[v,w]=l.useState(null),[j,N]=l.useState(""),[T,H]=l.useState(e==="queuing"?"active":"all"),[W,un]=l.useState("oldest"),[q,mn]=l.useState("All Categories"),[K,gn]=l.useState("All Status"),[sn,B]=l.useState(1),[d,y]=l.useState(null),[I,rn]=l.useState(""),[dn,Nn]=l.useState("");l.useLayoutEffect(()=>{var f,z;const r=L.current,i={};r.querySelectorAll("[id], canvas, .card-number, .card-change, .payment-value, .donut-number, .status-item strong, .chart-container, .donut-wrapper").forEach((b,X)=>{b.id&&(i[b.id]=b)}),e==="dashboard"&&(i.dashboardRows=r.querySelector("tbody"),i.dashboardCards=[...r.querySelectorAll(".card-number")],i.dashboardChanges=[...r.querySelectorAll(".card-change")],i.dashboardPayments=[...r.querySelectorAll(".payment-value")],i.dashboardStatuses=[...r.querySelectorAll(".status-item strong")],i.salesChart=(f=r.querySelector("#salesChart"))==null?void 0:f.parentElement,i.orderChart=(z=r.querySelector("#orderChart"))==null?void 0:z.parentElement,i.lowStock=r.querySelector(".stock-list"),i.topProducts=r.querySelector(".product-list"));const O=r.querySelector("main, .main, .content"),F=document.createElement("div");F.className="api-notices",O.prepend(F),i.notices=F,i.allBodies=[...r.querySelectorAll("tbody")],Object.values(i).flat().filter(b=>b instanceof HTMLElement&&b!==i.refresh).forEach(b=>{(b.tagName==="TBODY"||["ordersList","productsList","productList","triggerList","productGrid","general"].includes(b.id))&&b.replaceChildren()}),i.salesChart&&i.salesChart.replaceChildren(),i.orderChart&&i.orderChart.replaceChildren(),i.lowStock&&i.lowStock.replaceChildren(),i.topProducts&&i.topProducts.replaceChildren(),r.querySelectorAll(".summary-value, .summary-number, .summary-card .number, .summary-card strong, .card-number, .card-change, .payment-value, .status-item strong, #paginationInfo, #showingText, #orderCount, #queueFooter, #customerCount, #pagination, #categoryFilter, #recommendationText, #currentTrigger").forEach(b=>b.replaceChildren()),V(i);const Z=b=>{var An;const X=b.target.closest("a");if(X){const _=X.getAttribute("href");_!=null&&_.startsWith("/admin/")?(b.preventDefault(),u(_.split("/").at(-1))):_==="#sign-out"&&(b.preventDefault(),m())}const Q=b.target.closest("button");if(!Q)return;const pn=Q.dataset.originalAction||"";if(pn.includes("toggleFilter")){const _=r.querySelector("#filterDropdown");_&&(_.style.display=_.style.display==="block"?"none":"block")}else if(pn.includes("filterPayments")){const _=((An=pn.match(/'([^']+)'/))==null?void 0:An[1])||"all";H(_),B(1);const Cn=r.querySelector("#filterDropdown");Cn&&(Cn.style.display="none")}else if(Q.id==="clearSearch"){const _=r.querySelector("#customerSearch");_.value="",N("")}else Q.dataset.status?(H(Q.dataset.status==="All Orders"?"all":Q.dataset.status),B(1)):(/open.*(?:add|product).*modal|openModal\(|openAdd|addProduct/i.test(pn)||Q.id==="addProductButton")&&s({})},p=b=>{if(["customerSearch","searchInput","queueSearch"].includes(b.target.id)&&(N(b.target.value),B(1)),b.target.id==="productSearch"&&Nn(b.target.value),b.target.id==="dateFilter"&&(rn(b.target.value),B(1)),b.target.id==="statusFilter"){const X=b.target.value;H(X),gn(X),B(1)}b.target.id==="categoryFilter"&&(mn(b.target.value),B(1)),b.target.id==="sortBy"&&un(b.target.value)};return r.addEventListener("click",Z),r.addEventListener("input",p),r.addEventListener("change",p),()=>{r.removeEventListener("click",Z),r.removeEventListener("input",p),r.removeEventListener("change",p)}},[e]);const S=(a==null?void 0:a.orders)||[],C=(a==null?void 0:a.products)||[],U=S.filter(r=>r.payment_status==="Paid"),ln=S.filter(r=>!zn(r)),hn=j.trim().toLowerCase();let D=S.filter(r=>`${r.order_number} ${r.customer_name}`.toLowerCase().includes(hn));(e==="queuing"||e==="orders")&&(D=D.filter(r=>["all","All","All Orders",""].includes(T)||(T==="active"?!zn(r):r.order_status===T))),(e==="payments"||e==="receipt-records")&&(D=D.filter(r=>["all","All","All Status",""].includes(T)||r.payment_status.toLowerCase()===T.toLowerCase()||T==="cancelled"&&r.order_status==="Cancelled")),I&&(D=D.filter(r=>{const i=new Intl.DateTimeFormat("en",{year:"numeric",month:"2-digit",day:"2-digit",timeZone:"Asia/Manila"}).formatToParts(new Date(r.paid_at||r.created_at)),O=F=>i.find(Z=>Z.type===F).value;return`${O("year")}-${O("month")}-${O("day")}`===I})),W==="newest"&&(D=[...D].reverse()),W==="customer"&&D.sort((r,i)=>r.customer_name.localeCompare(i.customer_name)),W==="amount"&&D.sort((r,i)=>i.total-r.total);const cn=new Map;S.forEach(r=>{const i=cn.get(r.mobile_number)||{name:r.customer_name,mobile:r.mobile_number,address:"",orders:[],spent:0};i.name=r.customer_name,i.address=r.address||i.address,i.orders.push(r),r.payment_status==="Paid"&&(i.spent+=r.total),cn.set(r.mobile_number,i)});const _n=[...cn.values()].filter(r=>`${r.name} ${r.mobile} ${r.address}`.toLowerCase().includes(hn)),xn=r=>r.is_active?r.stock===0?"Out of Stock":r.stock<=10?"Low Stock":"In Stock":"Unavailable",Mn=C.filter(r=>`${r.name} ${r.sku}`.toLowerCase().includes(hn)&&(["All Categories","All","all",""].includes(q)||r.category===q)&&(["All Status","All","all",""].includes(K)||xn(r)===K)),en=10,G=e==="customers"?_n:e==="products"?Mn:D,fn=Math.max(1,Math.ceil(G.length/en)),$=Math.min(sn,fn),bn=G.slice(($-1)*en,$*en),In=e==="customers"?bn:[],vn=["orders","queuing","payments","receipt-records"].includes(e)?bn:[],J=[],k=(r,i)=>{E[r]&&J.push(nn.createPortal(i,E[r],r))},tn=r=>n.jsx("span",{className:`status status-badge ${r==="Processing"?"processing":r.startsWith("Ready")?"ready":r.toLowerCase()}`,children:r});k("notices",n.jsxs(n.Fragment,{children:[c&&n.jsxs("div",{className:"error",role:"alert",children:[c," ",n.jsx("button",{onClick:x,disabled:o||g,children:"Retry"})]}),o&&n.jsx("p",{role:"status",children:"Loading store data…"})]}));const Dn={totalCustomers:cn.size,totalOrders:S.length,totalSales:R(U.reduce((r,i)=>r+i.total,0)),activeCustomers:new Set(ln.map(r=>r.mobile_number)).size,activeCount:ln.length,pendingCount:S.filter(r=>r.order_status==="Pending").length,nextOrder:((wn=ln[0])==null?void 0:wn.order_number)||"—",totalProducts:C.length,inStockCount:C.filter(r=>r.stock>10&&r.is_active).length,lowStockCount:C.filter(r=>r.stock>0&&r.stock<=10&&r.is_active).length,outStockCount:C.filter(r=>r.stock===0&&r.is_active).length,totalPayments:S.length,paidCount:U.length,unpaidCount:S.filter(r=>r.payment_status==="Unpaid"&&r.order_status!=="Cancelled").length,cancelledCount:S.filter(r=>r.order_status==="Cancelled").length,totalAmount:R(S.reduce((r,i)=>r+i.total,0)),paidOrders:U.length,unpaidOrders:S.length-U.length,triggerCount:C.filter(r=>{var i;return(i=r.recommended_product_ids)==null?void 0:i.length}).length,recommendationCount:new Set(C.flatMap(r=>r.recommended_product_ids||[])).size,linkCount:C.reduce((r,i)=>{var O;return r+(((O=i.recommended_product_ids)==null?void 0:O.length)||0)},0)};Object.entries(Dn).forEach(([r,i])=>k(r,i)),k("categoryFilter",n.jsxs(n.Fragment,{children:[n.jsx("option",{children:"All Categories"}),[...new Set(C.map(r=>r.category))].sort().map(r=>n.jsx("option",{children:r},r))]})),k("customerTable",In.map(r=>n.jsxs("tr",{children:[n.jsx("td",{className:"customer-name",children:r.name}),n.jsx("td",{children:r.mobile}),n.jsx("td",{children:r.address||"Store pickup"}),n.jsx("td",{children:r.orders.length}),n.jsx("td",{children:R(r.spent)}),n.jsx("td",{children:an(r.orders.at(-1).created_at)}),n.jsx("td",{children:n.jsx("button",{className:"history-btn",onClick:()=>y(r),children:"View History"})})]},r.mobile))),k("queueRows",vn.map(r=>n.jsxs("tr",{children:[n.jsx("td",{className:"position",children:r.queue_position?`#${r.queue_position}`:"—"}),n.jsx("td",{className:"order-id",children:r.order_number}),n.jsx("td",{className:"customer-name",children:r.customer_name}),n.jsx("td",{className:"order-time",children:an(r.created_at)}),n.jsx("td",{children:tn(r.order_status)}),n.jsx("td",{className:"total",children:R(r.total)})]},r.order_number))),k("ordersList",vn.map(r=>n.jsxs("div",{className:"order-row",children:[n.jsx("div",{className:"order-id",children:r.order_number}),n.jsx("div",{children:r.customer_name}),n.jsx("div",{children:tn(r.order_status)}),n.jsx("div",{children:R(r.total)}),n.jsx("div",{children:an(r.created_at)}),n.jsx("div",{children:t(r)})]},r.order_number))),k("productList",(r=>r.map(i=>n.jsxs("div",{className:"product-row",children:[n.jsx("div",{className:"product-image",children:i.image_url?n.jsx("img",{src:i.image_url,alt:i.name}):n.jsx("span",{className:"api-product-icon",children:"◇"})}),n.jsx("div",{className:"product-name",children:i.name}),n.jsx("div",{children:i.category}),n.jsx("div",{children:R(i.price)}),n.jsx("div",{children:i.stock}),n.jsx("div",{children:i.unit}),n.jsx("div",{children:tn(xn(i))}),n.jsx("div",{children:n.jsx("button",{className:"edit-btn",onClick:()=>s(i),children:"Edit"})})]},i.id)))(e==="products"?bn:[])),k("productsList",C.filter(r=>`${r.name} ${r.sku}`.toLowerCase().includes(dn.trim().toLowerCase())).map(r=>n.jsxs("div",{className:"product-row",children:[n.jsx("div",{className:"product-name",children:r.name}),n.jsx("div",{children:R(r.price)}),n.jsx("div",{children:r.unit}),n.jsx("div",{children:r.category}),n.jsx("div",{children:r.stock}),n.jsx("div",{children:xn(r)}),n.jsx("div",{children:n.jsx("button",{onClick:()=>s(r),children:"Edit"})})]},r.id))),["paymentBody","receiptTableBody"].forEach(r=>k(r,vn.map(i=>n.jsxs("tr",{children:[n.jsx("td",{children:i.order_number}),n.jsx("td",{children:i.order_number}),n.jsx("td",{children:i.customer_name}),n.jsx("td",{children:R(i.total)}),n.jsx("td",{children:i.payment_method==="cash_at_store"?"Cash at Store":"Cash on Delivery"}),n.jsx("td",{children:tn(i.payment_status)}),n.jsx("td",{children:an(i.paid_at||i.created_at)}),n.jsx("td",{children:t(i)})]},i.order_number))));const Ln=`Showing ${G.length?($-1)*en+1:0} to ${Math.min($*en,G.length)} of ${G.length}`;if(["paginationInfo","showingText","orderCount","queueFooter","customerCount"].forEach(r=>k(r,Ln)),k("pagination",n.jsxs(n.Fragment,{children:[n.jsx("button",{disabled:$<=1,onClick:()=>B($-1),children:"‹"}),n.jsxs("span",{className:"api-page-number",children:[$," / ",fn]}),n.jsx("button",{disabled:$>=fn,onClick:()=>B($+1),children:"›"})]})),k("general",A),e==="dashboard"){[S.length,S.filter(p=>p.order_status==="Pending").length,R(U.reduce((p,f)=>p+f.total,0)),C.filter(p=>p.is_active&&p.stock<=10).length].forEach((p,f)=>{var z;(z=E.dashboardCards)!=null&&z[f]&&J.push(nn.createPortal(p,E.dashboardCards[f],`metric-${f}`))}),(kn=E.dashboardChanges)==null||kn.forEach((p,f)=>J.push(nn.createPortal(f===1?`${S.length?Math.round(ln.length/S.length*100):0}% active orders`:"From recorded orders",p,`change-${f}`))),(Sn=E.dashboardStatuses)==null||Sn.forEach((p,f)=>J.push(nn.createPortal(S.filter(z=>f===3?z.order_status.startsWith("Ready"):z.order_status===["Completed","Pending","Processing"][f]).length,p,`status-${f}`))),(En=E.dashboardPayments)==null||En.forEach((p,f)=>J.push(nn.createPortal(f===0?`${U.length} Orders`:f===1?`${S.length-U.length} Orders`:R((f===2?U:S.filter(z=>z.payment_status!=="Paid")).reduce((z,b)=>z+b.total,0)),p,`payment-${f}`))),k("dashboardRows",S.slice(-10).reverse().map(p=>n.jsxs("tr",{children:[n.jsx("td",{children:n.jsx("button",{className:"text-button",onClick:()=>h(p),children:p.order_number})}),n.jsx("td",{children:p.customer_name}),n.jsx("td",{children:an(p.created_at)}),n.jsx("td",{children:tn(p.order_status)}),n.jsx("td",{children:R(p.total)})]},p.order_number)));const r=new Map;U.forEach(p=>{const f=(p.paid_at||p.created_at).slice(0,7);r.set(f,(r.get(f)||0)+p.total)});const i=Math.max(1,...r.values());k("salesChart",n.jsx("div",{className:"api-chart",children:r.size?[...r].sort().map(([p,f])=>n.jsxs("div",{className:"api-bar",children:[n.jsx("span",{children:R(f)}),n.jsx("div",{style:{height:`${Math.max(3,f/i*120)}px`}}),n.jsx("small",{children:p})]},p)):n.jsx("p",{children:"No recorded sales yet."})})),k("orderChart",n.jsxs("div",{className:"api-donut",children:[n.jsx("strong",{children:S.length}),n.jsx("span",{children:"Total Orders"})]}));const O=C.filter(p=>p.is_active&&p.stock<=10);k("lowStock",O.length?O.map(p=>n.jsxs("div",{className:"stock-item",children:[n.jsx("div",{className:"stock-image",children:"◇"}),n.jsxs("div",{className:"stock-info",children:[n.jsx("div",{className:"stock-name",children:p.name}),n.jsx("div",{className:"stock-description",children:p.category})]}),n.jsxs("div",{className:"stock-number",children:[n.jsx("div",{className:"stock-quantity",children:p.stock}),n.jsxs("div",{className:"stock-label",children:[p.unit," left"]})]})]},p.id)):n.jsx("p",{children:"No products need restocking."}));const F=new Map,Z=Date.now()-10080*60*1e3;U.filter(p=>new Date(p.paid_at||p.created_at).getTime()>=Z).forEach(p=>p.items.forEach(f=>{const z=F.get(f.product_id)||{...f,quantity:0};z.quantity+=f.quantity,F.set(f.product_id,z)})),k("topProducts",F.size?[...F.values()].sort((p,f)=>f.quantity-p.quantity).slice(0,5).map(p=>n.jsxs("div",{className:"product",children:[n.jsx("div",{className:"product-image",children:"◇"}),n.jsxs("div",{className:"product-info",children:[n.jsx("div",{className:"product-name",children:p.name}),n.jsxs("div",{className:"product-price",children:[R(p.price)," / ",p.unit]})]}),n.jsxs("div",{className:"product-sales",children:[n.jsx("div",{className:"sales-number",children:p.quantity}),n.jsx("div",{className:"sold",children:"sold"})]})]},p.product_id)):n.jsx("p",{children:"No paid sales this week."}))}if(e==="ai-recommendations"){const r=C.find(i=>i.id===v);k("triggerList",C.filter(i=>i.name.toLowerCase().includes(j.toLowerCase())).map(i=>{var O;return n.jsxs("button",{className:`trigger-item ${v===i.id?"active":""}`,onClick:()=>w(i.id),children:[i.name," ",n.jsxs("small",{children:["(",((O=i.recommended_product_ids)==null?void 0:O.length)||0,")"]})]},i.id)})),k("productGrid",r?n.jsx(Xn,{product:r,products:C,save:M,busy:g},r.id+JSON.stringify(r.recommended_product_ids)):n.jsx("p",{children:"Select a trigger product to choose its related products."})),k("recommendationText","Choose related products to display when this item is in the customer cart."),k("currentTrigger",(r==null?void 0:r.name)||"No trigger selected")}return l.useLayoutEffect(()=>{L.current&&(L.current.querySelectorAll("#emptyState, #queueEmpty, #noResults").forEach(r=>{r.style.display=G.length?"none":"block"}),L.current.querySelectorAll(".tab[data-status]").forEach(r=>{r.classList.toggle("active",r.dataset.status===T||r.dataset.status==="All Orders"&&T==="all")}),L.current.querySelectorAll('a[href="/admin/settings"]').forEach(r=>{var i;r.style.display=((i=a==null?void 0:a.account)==null?void 0:i.is_admin)===!1?"none":""}))},[G.length,T,o,g,E,(jn=a==null?void 0:a.account)==null?void 0:jn.is_admin]),n.jsxs("div",{className:`legacy-screen restored-page page-${e}`,children:[n.jsx("style",{children:Y.css}),n.jsx("style",{children:Zn}),n.jsx("div",{ref:L,dangerouslySetInnerHTML:{__html:Y.html}}),J,d&&n.jsx("div",{className:"api-history-backdrop",children:n.jsxs("section",{className:"api-history-dialog",role:"dialog","aria-modal":"true",children:[n.jsx("h2",{children:"Customer Details"}),n.jsxs("p",{children:[d.name," · ",d.mobile]}),n.jsx("p",{children:d.address||"Store pickup"}),n.jsxs("table",{children:[n.jsx("thead",{children:n.jsxs("tr",{children:[n.jsx("th",{children:"Order"}),n.jsx("th",{children:"Status"}),n.jsx("th",{children:"Total"})]})}),n.jsx("tbody",{children:d.orders.map(r=>n.jsxs("tr",{children:[n.jsx("td",{children:r.order_number}),n.jsx("td",{children:r.order_status}),n.jsx("td",{children:R(r.total)})]},r.order_number))})]}),n.jsx("button",{onClick:()=>y(null),children:"Close"})]})})]})}const Pn=[["store","Store Information"],["orders","Order Settings"],["notifications","Notifications"],["account","Admin Account"]],Tn=[["notify_new_orders","New Orders"],["notify_order_changes","Order Changes"],["notify_cancellations","Cancellations"],["notify_low_stock","Low Stock"]];function tr({api:e}){const[a,o]=l.useState(null),[g,c]=l.useState("store"),[u,m]=l.useState(!1),[x,t]=l.useState(""),[s,h]=l.useState(""),[A,M]=l.useState(0);async function Y(){try{const[v,w]=await Promise.all([e.request("staff/me"),e.request("staff/settings")]);o({account:v,store:w})}catch(v){t(v.message)}}l.useEffect(()=>{Y()},[]);async function L(v){v.preventDefault();const w=new FormData(v.currentTarget);let j=Object.fromEntries(w);g==="orders"&&(j={delivery_fee_centavos:Math.round(Number(w.get("fee"))*100),pickup_enabled:w.has("pickup_enabled"),delivery_enabled:w.has("delivery_enabled")}),g==="notifications"&&(j={...Object.fromEntries(Tn.map(([N])=>[N,w.has(N)])),low_stock_threshold:Number(w.get("low_stock_threshold"))}),g==="account"&&!j.password&&(delete j.password,delete j.password_confirmation),m(!0),t(""),h("");try{await e.request(g==="account"?"staff/account":"staff/settings",{method:"PATCH",body:j}),await Y(),M(N=>N+1),h("Changes saved.")}catch(N){t(N.message)}finally{m(!1)}}const E=(v,w,j={})=>n.jsxs("label",{children:[w,n.jsx("input",{name:v,defaultValue:a.store[v]??"",...j})]}),V=(v,w,j)=>n.jsxs("label",{className:"settings-toggle",children:[n.jsxs("span",{children:[n.jsx("strong",{children:w}),n.jsx("small",{children:j})]}),n.jsx("input",{name:v,type:"checkbox",defaultChecked:a.store[v]})]});return n.jsxs("div",{className:"connected-settings",children:[n.jsx("nav",{className:"settings-tabs","aria-label":"Settings sections",children:Pn.map(([v,w])=>n.jsx("button",{type:"button",className:g===v?"active":"","aria-pressed":g===v,disabled:u,onClick:()=>{c(v),t(""),h("")},children:w},v))}),n.jsxs("section",{className:"settings-card",children:[x&&n.jsx("p",{className:"error",role:"alert",children:x}),s&&n.jsx("p",{className:"settings-success",role:"status",children:s}),a?n.jsxs("form",{onSubmit:L,children:[n.jsx("h2",{children:Pn.find(([v])=>v===g)[1]}),g==="store"&&n.jsxs(n.Fragment,{children:[n.jsx("p",{className:"settings-help",children:"Contact details and pickup information."}),n.jsxs("div",{className:"settings-grid",children:[E("store_name","Store name",{required:!0,maxLength:255}),E("store_phone","Contact number",{type:"tel",maxLength:50})]}),E("store_address","Store address",{maxLength:2e3}),E("store_hours","Store hours",{maxLength:500,placeholder:"Monday–Saturday, 8 AM–5 PM"})]}),g==="orders"&&n.jsxs(n.Fragment,{children:[n.jsx("p",{className:"settings-help",children:"Applies to new orders. Existing orders retain their original fees."}),V("pickup_enabled","Store Pickup","Accept orders for collection at the store."),V("delivery_enabled","Delivery","Accept delivery orders."),n.jsxs("label",{children:["Delivery fee (PHP)",n.jsx("input",{name:"fee",type:"number",min:"0",max:"1000000",step:"0.01",defaultValue:a.store.delivery_fee_centavos/100,required:!0})]})]}),g==="notifications"&&n.jsxs(n.Fragment,{children:[n.jsx("p",{className:"settings-help",children:"Show alerts while the admin website is open."}),Tn.map(([v,w])=>n.jsx(qn.Fragment,{children:V(v,w,"Show this alert in the admin website.")},v)),E("low_stock_threshold","Low stock threshold",{type:"number",min:0,max:1e6,required:!0})]}),g==="account"&&n.jsxs(n.Fragment,{children:[n.jsx("p",{className:"settings-help",children:"Enter your current password to save changes."}),n.jsxs("div",{className:"settings-grid",children:[n.jsxs("label",{children:["Name",n.jsx("input",{name:"name",defaultValue:a.account.name,maxLength:255,required:!0})]}),n.jsxs("label",{children:["Email",n.jsx("input",{name:"email",type:"email",defaultValue:a.account.email,required:!0})]})]}),n.jsxs("label",{children:["Current password",n.jsx("input",{name:"current_password",type:"password",autoComplete:"current-password",required:!0})]}),n.jsxs("div",{className:"settings-grid",children:[n.jsxs("label",{children:["New password (optional)",n.jsx("input",{name:"password",type:"password",autoComplete:"new-password",minLength:12})]}),n.jsxs("label",{children:["Confirm new password",n.jsx("input",{name:"password_confirmation",type:"password",autoComplete:"new-password",minLength:12})]})]}),n.jsx("p",{className:"settings-help",children:"At least 12 characters. Leave blank to keep your password."})]}),n.jsx("div",{className:"settings-footer",children:n.jsx("button",{disabled:u,children:u?"Saving…":"Save changes"})})]},g+A+JSON.stringify(a)):n.jsx("p",{children:x?n.jsx("button",{onClick:Y,children:"Retry"}):"Loading settings…"})]})]})}function ir({api:e,data:a}){const[o,g]=l.useState(null),[c,u]=l.useState([]),m=l.useRef(null);if(l.useEffect(()=>{let t=!0;const s=()=>e.request("staff/settings").then(A=>{t&&g(A)}).catch(()=>{});s();const h=setInterval(s,1e4);return()=>{t=!1,clearInterval(h)}},[]),l.useEffect(()=>{if(!a||!o)return;const t=m.current,s=[];t&&a.orders.forEach(h=>{const A=t.get(h.order_number);!A&&o.notify_new_orders?s.push(`New order: ${h.order_number}`):A&&A!==h.order_status&&(h.order_status==="Cancelled"?o.notify_cancellations:o.notify_order_changes)&&s.push(`${h.order_number}: ${h.order_status}`)}),m.current=new Map(a.orders.map(h=>[h.order_number,h.order_status])),s.length&&u(s)},[a,o]),!o)return null;const x=o.notify_low_stock?a.products.filter(t=>t.is_active&&t.stock<=o.low_stock_threshold):[];return c.length||x.length?n.jsxs("aside",{className:"store-alerts","aria-live":"polite",children:[c.map(t=>n.jsx("p",{children:t},t)),c.length>0&&n.jsx("button",{onClick:()=>u([]),children:"Dismiss"}),x.length>0&&n.jsxs("p",{children:["Low stock: ",x.map(t=>`${t.name} (${t.stock})`).join(", ")]})]}):null}function ar({api:e}){const[a,o]=l.useState(null),[g,c]=l.useState(!1),[u,m]=l.useState("");async function x(){try{o(await e.request("staff/recommendation-model"))}catch(t){m(t.message)}}return l.useEffect(()=>{x()},[]),n.jsxs("section",{className:"model-training",children:[n.jsx("h2",{children:"AI Recommendation Model"}),n.jsx("p",{children:"Item-item collaborative filtering learns product relationships from paid, completed orders."}),u&&n.jsx("p",{role:"alert",className:"error",children:u}),a&&n.jsxs(n.Fragment,{children:[n.jsx("p",{children:n.jsx("strong",{children:a.trained?"Trained model available":"Not trained — manual fallback"})}),n.jsxs("p",{children:["Training orders: ",a.training_orders," · Products: ",a.training_products," · Available completed orders: ",a.available_orders," · New orders: ",a.new_orders]}),a.trained_at&&n.jsxs("p",{children:["Last training: ",new Date(a.trained_at).toLocaleString()]})]}),n.jsx("button",{disabled:g,onClick:async()=>{c(!0),m("");try{o(await e.request("staff/recommendation-model/train",{method:"POST"}))}catch(t){m(t.message)}finally{c(!1)}},children:g?"Training…":"Train / Retrain model"}),n.jsx("p",{children:"Requires at least 3 completed orders and a product pair bought together twice. Manual selections below are used when no learned suggestions are available."})]})}const P=Un(),yn=e=>new Intl.NumberFormat("en-PH",{style:"currency",currency:"PHP"}).format(e),On=[["dashboard","Dashboard"],["orders","Orders"],["products","Products"],["queuing","Order Queue"],["payments","Payments"],["customers","Customers"],["receipt-records","Receipt Records"],["ai-recommendations","Recommendations"],["settings","Settings"]],on=e=>e.queue_position!==null;function or({onLogin:e}){const[a,o]=l.useState(""),[g,c]=l.useState(!1),[u,m]=l.useState(!1);async function x(t){t.preventDefault();const s=new FormData(t.currentTarget);c(!0),o("");try{await P.login(s.get("email"),s.get("password")),e()}catch(h){o(h.message)}finally{c(!1)}}return n.jsx(rr,{children:n.jsxs("form",{onSubmit:x,children:[a&&n.jsx("p",{className:"error",role:"alert",children:a}),n.jsx("div",{className:"form-group",children:n.jsxs("label",{children:["Email",n.jsx("input",{name:"email",type:"email",autoComplete:"username",required:!0})]})}),n.jsx("div",{className:"form-group",children:n.jsxs("label",{children:["Password",n.jsx("input",{name:"password",type:u?"text":"password",autoComplete:"current-password",required:!0})]})}),n.jsxs("label",{className:"check",children:[n.jsx("input",{type:"checkbox",checked:u,onChange:t=>m(t.target.checked)})," Show password"]}),n.jsx("button",{className:"login-btn",disabled:g,children:g?"Signing in…":"Sign in"})]})})}function sr(){const[e,a]=l.useState(""),[o,g]=l.useState(!1),[c,u]=l.useState(!1),[m,x]=l.useState(!1);async function t(s){s.preventDefault();const h=new FormData(s.currentTarget),A=new URLSearchParams(location.search);g(!0),a("");try{await P.request("admin/reset-password",{method:"POST",token:null,body:{email:A.get("email"),token:A.get("token"),password:h.get("password"),password_confirmation:h.get("password_confirmation")}}),P.forget(),u(!0),history.replaceState(null,"","/admin/reset-password")}catch(M){a(M.message)}finally{g(!1)}}return n.jsx("main",{className:"login-page",children:n.jsxs("section",{className:"login-card",children:[n.jsxs("div",{className:"brand",children:["ELEE",n.jsx("span",{children:"HARDWARE"})]}),n.jsx("h1",{children:"Set admin password"}),e&&n.jsx("p",{className:"error",role:"alert",children:e}),c?n.jsxs(n.Fragment,{children:[n.jsx("p",{children:"Password updated."}),n.jsx("a",{href:"/admin/login",children:"Go to sign in"})]}):n.jsxs("form",{onSubmit:t,children:[n.jsxs("label",{children:["New password",n.jsx("input",{name:"password",type:m?"text":"password",minLength:12,maxLength:255,autoComplete:"new-password",required:!0})]}),n.jsxs("label",{children:["Confirm password",n.jsx("input",{name:"password_confirmation",type:m?"text":"password",minLength:12,maxLength:255,autoComplete:"new-password",required:!0})]}),n.jsxs("label",{className:"check",children:[n.jsx("input",{type:"checkbox",checked:m,onChange:s=>x(s.target.checked)})," Show password"]}),n.jsx("button",{disabled:o,children:o?"Saving…":"Save password"})]})]})})}function dr({product:e,onSave:a,onClose:o,busy:g,error:c}){return n.jsx("div",{className:"modal-backdrop api-dialog-backdrop",children:n.jsxs("section",{className:"api-dialog",role:"dialog","aria-modal":"true","aria-labelledby":"product-title",children:[n.jsx("h2",{id:"product-title",children:e!=null&&e.id?"Edit product":"Add product"}),c&&n.jsx("p",{className:"error",role:"alert",children:c}),n.jsxs("form",{onSubmit:u=>{u.preventDefault();const m=new FormData(u.currentTarget);a(e==null?void 0:e.id,{sku:m.get("sku"),name:m.get("name"),category:m.get("category"),unit:m.get("unit"),price_centavos:Math.round(Number(m.get("price"))*100),stock:Number(m.get("stock")),description:m.get("description")||null,image_url:m.get("image_url")||null,is_active:m.get("is_active")==="on"})},children:[n.jsxs("div",{className:"form-grid",children:[n.jsxs("label",{children:["SKU",n.jsx("input",{name:"sku",defaultValue:(e==null?void 0:e.sku)||"",maxLength:100,required:!0})]}),n.jsxs("label",{children:["Name",n.jsx("input",{name:"name",defaultValue:(e==null?void 0:e.name)||"",maxLength:255,required:!0})]}),n.jsxs("label",{children:["Category",n.jsx("input",{name:"category",defaultValue:(e==null?void 0:e.category)||"",maxLength:100,required:!0})]}),n.jsxs("label",{children:["Unit",n.jsx("input",{name:"unit",defaultValue:(e==null?void 0:e.unit)||"",maxLength:50,required:!0})]}),n.jsxs("label",{children:["Price (PHP)",n.jsx("input",{name:"price",type:"number",min:"0.01",max:"1000000",step:"0.01",defaultValue:(e==null?void 0:e.price)??"",required:!0})]}),n.jsxs("label",{children:["Available stock",n.jsx("input",{name:"stock",type:"number",min:"0",max:"1000000",step:"1",defaultValue:(e==null?void 0:e.stock)??"",required:!0})]})]}),n.jsxs("label",{children:["Description",n.jsx("textarea",{name:"description",defaultValue:(e==null?void 0:e.description)||"",maxLength:5e3})]}),n.jsxs("label",{children:["Image URL",n.jsx("input",{name:"image_url",type:"url",defaultValue:(e==null?void 0:e.image_url)||""})]}),n.jsxs("label",{className:"check",children:[n.jsx("input",{name:"is_active",type:"checkbox",defaultChecked:(e==null?void 0:e.is_active)??!0})," Visible to customers"]}),n.jsxs("div",{className:"actions",children:[n.jsx("button",{disabled:g,children:g?"Saving…":"Save product"}),n.jsx("button",{className:"secondary",type:"button",onClick:o,disabled:g,children:"Cancel"})]})]})]})})}function lr({order:e,onClose:a}){return n.jsx("div",{className:"modal-backdrop api-dialog-backdrop",children:n.jsxs("section",{className:"api-dialog",role:"dialog","aria-modal":"true","aria-labelledby":"order-title",children:[n.jsx("h2",{id:"order-title",children:e.order_number}),n.jsxs("p",{children:[e.customer_name," · ",e.mobile_number]}),n.jsx("p",{children:e.fulfillment_method==="store_pickup"?"Store pickup":`Delivery: ${e.address}`}),n.jsxs("p",{children:[e.order_status," · Payment: ",e.payment_status]}),n.jsx("div",{className:"table-wrap",children:n.jsxs("table",{children:[n.jsx("thead",{children:n.jsxs("tr",{children:[n.jsx("th",{children:"Item"}),n.jsx("th",{children:"Quantity"}),n.jsx("th",{children:"Amount"})]})}),n.jsx("tbody",{children:e.items.map(o=>n.jsxs("tr",{children:[n.jsx("td",{children:o.name}),n.jsxs("td",{children:[o.quantity," ",o.unit]}),n.jsx("td",{children:yn(o.line_total)})]},o.product_id))})]})}),n.jsxs("p",{children:["Delivery fee: ",yn(e.delivery_fee)]}),n.jsxs("strong",{children:["Total: ",yn(e.total)]}),n.jsx("div",{className:"actions",children:n.jsx("button",{onClick:a,children:"Close"})})]})})}function cr(){const e=location.pathname.split("/").filter(Boolean).at(-1),[a,o]=l.useState(On.some(([d])=>d===e)?e:"dashboard"),[g,c]=l.useState(P.hasToken()),[u,m]=l.useState(null),[x,t]=l.useState(!1),[s,h]=l.useState(!1),[A,M]=l.useState(""),[Y,L]=l.useState(""),[E,V]=l.useState(e==="queuing"?"active":"all"),[v,w]=l.useState(null),[j,N]=l.useState(null),T=l.useRef(!1),H=l.useRef(0);async function W({background:d=!1}={}){if(d&&T.current)return;const y=++H.current;T.current=!0,d||t(!0),M("");try{const[I,rn,dn]=await Promise.all([P.all("staff/orders"),P.all("staff/products"),P.request("staff/me")]);y===H.current&&(m({orders:I,products:rn,account:dn}),!dn.is_admin&&a==="settings"&&o("dashboard"))}catch(I){if(y!==H.current)return;M(I.message),[401,403].includes(I.status)&&(P.forget(),c(!1),m(null))}finally{y===H.current&&(T.current=!1,d||t(!1))}}l.useEffect(()=>{g&&W()},[g]),l.useEffect(()=>{if(!g||s||v||j||["settings","ai-recommendations"].includes(a))return;const d=()=>{document.visibilityState==="visible"&&W({background:!0})},y=window.setInterval(d,1e4);return window.addEventListener("focus",d),()=>{window.clearInterval(y),window.removeEventListener("focus",d)}},[g,s,v,j,a]),l.useEffect(()=>{const d=()=>{const y=location.pathname.split("/").filter(Boolean).at(-1);o(On.some(([I])=>I===y)?y:"dashboard")};return window.addEventListener("popstate",d),()=>window.removeEventListener("popstate",d)},[]);function un(d){o(d),L(""),V(d==="queuing"?"active":"all"),history.pushState(null,"",`/admin/${d}`)}async function q(d,y,I="PATCH"){h(!0),M("");try{return await P.request(d,{method:I,body:y}),await W(),!0}catch(rn){return M(rn.message),!1}finally{h(!1)}}async function mn(){H.current++,T.current=!1,h(!0);try{await P.request("staff/logout",{method:"POST"}),P.forget(),m(null),c(!1),history.replaceState(null,"","/admin/login")}catch(d){d.status===401?(P.forget(),m(null),c(!1)):M(d.message)}finally{h(!1)}}if(!g)return n.jsx(or,{onLogin:()=>{c(!0),history.replaceState(null,"",`/admin/${a}`)}});const K=(u==null?void 0:u.orders)||[];u!=null&&u.products,K.filter(on);const gn=Y.trim().toLowerCase();K.filter(d=>(E==="all"||(E==="active"?on(d):d.order_status===E))&&`${d.order_number} ${d.customer_name}`.toLowerCase().includes(gn));const sn=new Map;K.forEach(d=>{const y=sn.get(d.mobile_number)||{name:d.customer_name,mobile:d.mobile_number,count:0,total:0};y.count++,y.total+=d.total,sn.set(d.mobile_number,y)});function B(d){const y=`staff/orders/${encodeURIComponent(d.order_number)}`;return n.jsxs("div",{className:"row-actions",children:[n.jsx("button",{className:"secondary",onClick:()=>N(d),children:"Details"}),d.order_status==="Pending"&&n.jsx("button",{disabled:s||x,onClick:()=>q(`${y}/status`,{status:"Processing"}),children:"Start processing"}),d.order_status==="Processing"&&n.jsx("button",{disabled:s||x,onClick:()=>q(`${y}/status`,{status:d.fulfillment_method==="store_pickup"?"Ready for Pickup":"Ready for Delivery"}),children:"Mark ready"}),on(d)&&d.payment_status!=="Paid"&&n.jsx("button",{className:"secondary",disabled:s||x,onClick:()=>{confirm(d.payment_method==="cash_on_delivery"?"Confirm this order was delivered and cash was received? This completes the order.":"Confirm cash was received at the store?")&&q(`${y}/paid`)},children:d.payment_method==="cash_on_delivery"?"Confirm delivered & paid":"Record cash received"}),on(d)&&d.payment_status==="Paid"&&n.jsx("button",{disabled:s||x,onClick:()=>{confirm("Confirm this order was handed to the customer?")&&q(`${y}/complete`)},children:"Complete order"}),on(d)&&d.payment_status!=="Paid"&&n.jsx("button",{className:"danger",disabled:s||x,onClick:()=>{confirm("Cancel this order and return its stock?")&&q(`${y}/status`,{status:"Cancelled"})},children:"Cancel"})]})}return n.jsxs(n.Fragment,{children:[a==="ai-recommendations"&&n.jsx(ar,{api:P}),u&&a!=="settings"&&n.jsx(ir,{api:P,data:u}),n.jsx(er,{page:a,data:u,loading:x,busy:s,error:A,navigate:un,logout:mn,refresh:W,actions:B,editProduct:d=>{M(""),w(d)},details:N,settings:n.jsx(tr,{api:P}),saveRecommendations:(d,y)=>q(`staff/products/${d}/recommendations`,{recommended_product_ids:y})},a),v&&n.jsx(dr,{product:v,busy:s,error:A,onClose:()=>w(null),onSave:async(d,y)=>{await q(d?`staff/products/${d}`:"staff/products",y,d?"PATCH":"POST")&&w(null)}}),j&&n.jsx(lr,{order:j,onClose:()=>N(null)})]})}Bn.createRoot(document.getElementById("root")).render(location.pathname==="/admin/reset-password"?n.jsx(sr,{}):n.jsx(cr,{}));

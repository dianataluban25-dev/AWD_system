import{r as u,j as n,a as an,R as Wn,c as Vn}from"./vendor-Ch-GEUUF.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const g of document.querySelectorAll('link[rel="modulepreload"]'))p(g);new MutationObserver(g=>{for(const d of g)if(d.type==="childList")for(const m of d.addedNodes)m.tagName==="LINK"&&m.rel==="modulepreload"&&p(m)}).observe(document,{childList:!0,subtree:!0});function s(g){const d={};return g.integrity&&(d.integrity=g.integrity),g.referrerPolicy&&(d.referrerPolicy=g.referrerPolicy),g.crossOrigin==="use-credentials"?d.credentials="include":g.crossOrigin==="anonymous"?d.credentials="omit":d.credentials="same-origin",d}function p(g){if(g.ep)return;g.ep=!0;const d=s(g);fetch(g.href,d)}})();function Gn({fetcher:e=fetch,storage:t=sessionStorage}={}){const s="elee.staff.token";async function p(g,{method:d="GET",body:m,token:v=t.getItem(s)}={}){const o=await e(`/api/${g}`,{method:d,headers:{Accept:"application/json",...m?{"Content-Type":"application/json"}:{},...v?{Authorization:`Bearer ${v}`}:{}},...m?{body:JSON.stringify(m)}:{},signal:AbortSignal.timeout(15e3)}),i=o.status===204?null:await o.json();if(!o.ok){const h=new Error(Object.values((i==null?void 0:i.errors)||{}).flat()[0]||(i==null?void 0:i.message)||"Request failed. Please retry.");throw h.status=o.status,h}return i}return{request:p,hasToken:()=>!!t.getItem(s),forget:()=>t.removeItem(s),async login(g,d){const m=await p("staff/login",{method:"POST",token:null,body:{email:g,password:d}});return t.setItem(s,m.token),m.user},async all(g){var m;const d=[];for(let v=1;;v++){const o=await p(`${g}${g.includes("?")?"&":"?"}page=${v}`);if(d.push(...o.data),!((m=o.links)!=null&&m.next))return d}}}}const Qn=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
\r
    <title>EleeSiWeb - Admin Login</title>\r
\r
    <style>\r
\r
        * {\r
            box-sizing: border-box;\r
            margin: 0;\r
            padding: 0;\r
        }\r
\r
        body {\r
            font-family: Arial, Helvetica, sans-serif;\r
            background: #f4f7f5;\r
            min-height: 100vh;\r
\r
            display: flex;\r
            justify-content: center;\r
            align-items: center;\r
        }\r
\r
        .login-container {\r
            width: 420px;\r
            max-width: 90%;\r
        }\r
\r
        .login-card {\r
            background: white;\r
            border-radius: 14px;\r
            padding: 40px;\r
            box-shadow: 0 8px 30px rgba(0,0,0,0.10);\r
        }\r
\r
        /* ================= LOGO ================= */\r
\r
        .logo {\r
            text-align: center;\r
            font-size: 42px;\r
            font-weight: 900;\r
            letter-spacing: -3px;\r
            color: #ffbd00;\r
            margin-bottom: 3px;\r
        }\r
\r
        .logo span {\r
            color: #00551f;\r
        }\r
\r
        .hardware {\r
            text-align: center;\r
            color: #ffbd00;\r
            font-size: 13px;\r
            font-weight: bold;\r
            letter-spacing: 1px;\r
            margin-bottom: 30px;\r
        }\r
\r
        /* ================= TITLE ================= */\r
\r
        .login-title {\r
            text-align: center;\r
            color: #147a36;\r
            font-size: 27px;\r
            font-weight: 600;\r
            margin-bottom: 7px;\r
        }\r
\r
        .login-subtitle {\r
            text-align: center;\r
            color: #777;\r
            font-size: 14px;\r
            margin-bottom: 28px;\r
        }\r
\r
        /* ================= FORM ================= */\r
\r
        .form-group {\r
            margin-bottom: 18px;\r
        }\r
\r
        .form-group label {\r
            display: block;\r
            font-size: 14px;\r
            font-weight: 600;\r
            color: #333;\r
            margin-bottom: 7px;\r
        }\r
\r
        .form-group input {\r
            width: 100%;\r
            height: 48px;\r
            border: 1px solid #d8d8d8;\r
            border-radius: 8px;\r
            padding: 0 14px;\r
            font-size: 15px;\r
            outline: none;\r
        }\r
\r
        .form-group input:focus {\r
            border-color: #299b4d;\r
            box-shadow: 0 0 0 3px rgba(41,155,77,0.10);\r
        }\r
\r
        /* ================= PASSWORD ================= */\r
\r
        .password-wrapper {\r
            position: relative;\r
        }\r
\r
        .password-wrapper input {\r
            padding-right: 50px;\r
        }\r
\r
        .show-password {\r
            position: absolute;\r
            right: 14px;\r
            top: 50%;\r
            transform: translateY(-50%);\r
\r
            border: none;\r
            background: transparent;\r
            cursor: pointer;\r
\r
            font-size: 18px;\r
            color: #777;\r
        }\r
\r
        /* ================= REMEMBER ================= */\r
\r
        .remember {\r
            display: flex;\r
            align-items: center;\r
            gap: 8px;\r
            margin-bottom: 22px;\r
            font-size: 13px;\r
            color: #555;\r
        }\r
\r
        .remember input {\r
            width: 15px;\r
            height: 15px;\r
            accent-color: #08752f;\r
        }\r
\r
        /* ================= LOGIN BUTTON ================= */\r
\r
        .login-btn {\r
            width: 100%;\r
            height: 48px;\r
\r
            background: #08752f;\r
            color: white;\r
\r
            border: none;\r
            border-radius: 8px;\r
\r
            font-size: 15px;\r
            font-weight: 600;\r
\r
            cursor: pointer;\r
            transition: 0.2s;\r
        }\r
\r
        .login-btn:hover {\r
            background: #065b25;\r
        }\r
\r
        /* ================= ERROR ================= */\r
\r
        .error-message {\r
            background: #ffe3e3;\r
            color: #c62828;\r
            border: 1px solid #ffc7c7;\r
\r
            padding: 10px 12px;\r
            border-radius: 7px;\r
\r
            font-size: 13px;\r
            margin-bottom: 18px;\r
        }\r
\r
        /* ================= FOOTER ================= */\r
\r
        .footer {\r
            text-align: center;\r
            margin-top: 22px;\r
            color: #999;\r
            font-size: 12px;\r
        }\r
\r
        @media(max-width: 500px) {\r
\r
            .login-card {\r
                padding: 30px 25px;\r
            }\r
\r
            .logo {\r
                font-size: 36px;\r
            }\r
\r
            .login-title {\r
                font-size: 24px;\r
            }\r
        }\r
\r
    </style>\r
</head>\r
\r
<body>\r
\r
    <div class="login-container">\r
\r
        <div class="login-card">\r
\r
            <!-- LOGO -->\r
\r
            <div class="logo">\r
                <span>E</span>LEE\r
            </div>\r
\r
            <div class="hardware">\r
                HARDWARE\r
            </div>\r
\r
\r
            <!-- TITLE -->\r
\r
            <div class="login-title">\r
                Admin Login\r
            </div>\r
\r
            <div class="login-subtitle">\r
                Sign in to access the EleeSiWeb admin system\r
            </div>\r
\r
\r
            <!-- ERROR MESSAGE -->\r
\r
            @if(session('error'))\r
\r
                <div class="error-message">\r
                    {{ session('error') }}\r
                </div>\r
\r
            @endif\r
\r
\r
            <!-- LOGIN FORM -->\r
\r
            <form action="{{ url('/admin/login') }}" method="POST">\r
\r
                @csrf\r
\r
\r
                <!-- USERNAME -->\r
\r
                <div class="form-group">\r
\r
                    <label for="username">\r
                        Username\r
                    </label>\r
\r
                    <input\r
                        type="text"\r
                        id="username"\r
                        name="username"\r
                        placeholder="Enter admin username"\r
                        required\r
                    >\r
\r
                </div>\r
\r
\r
                <!-- PASSWORD -->\r
\r
                <div class="form-group">\r
\r
                    <label for="password">\r
                        Password\r
                    </label>\r
\r
                    <div class="password-wrapper">\r
\r
                        <input\r
                            type="password"\r
                            id="password"\r
                            name="password"\r
                            placeholder="Enter admin password"\r
                            required\r
                        >\r
\r
                        <button\r
                            type="button"\r
                            class="show-password"\r
                            onclick="togglePassword()">\r
                            👁\r
                        </button>\r
\r
                    </div>\r
\r
                </div>\r
\r
\r
                <!-- REMEMBER -->\r
\r
                <div class="remember">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="remember"\r
                        name="remember"\r
                    >\r
\r
                    <label for="remember">\r
                        Remember me\r
                    </label>\r
\r
                </div>\r
\r
\r
                <!-- LOGIN -->\r
\r
                <button\r
                    type="submit"\r
                    class="login-btn">\r
\r
                    Login \r
\r
                </button>\r
\r
            </form>\r
\r
\r
            <div class="footer">\r
                EleeSiWeb Admin System\r
            </div>\r
\r
        </div>\r
\r
    </div>\r
\r
\r
    \r
\r
</body>\r
</html>`,Kn=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
    <title>AI Recommendations - ELEE Hardware</title>\r
\r
    <style>\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
            font-family: Arial, Helvetica, sans-serif;\r
        }\r
\r
        body {\r
            background: #f5f7f6;\r
            min-height: 100vh;\r
        }\r
\r
        .dashboard {\r
            display: flex;\r
            width: 100%;\r
            min-height: 100vh;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            flex-shrink: 0;\r
            z-index: 1000;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .menu-icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= CONTENT ================= */\r
\r
        .content {\r
            background: #f8faf9;\r
            flex: 1;\r
            min-height: 100vh;\r
            margin-left: 235px;\r
            padding: 35px 40px;\r
            overflow-x: hidden;\r
        }\r
\r
        .page-header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: flex-start;\r
            gap: 20px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .page-title {\r
            color: #19803c;\r
            font-size: 28px;\r
            font-weight: 700;\r
            margin-bottom: 5px;\r
        }\r
\r
        .page-subtitle {\r
            color: #888;\r
            font-size: 14px;\r
        }\r
\r
        .add-btn {\r
            background: #069b45;\r
            border: none;\r
            color: white;\r
            padding: 12px 18px;\r
            border-radius: 8px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            font-weight: 600;\r
            transition: 0.2s;\r
        }\r
\r
        .add-btn:hover {\r
            background: #057c37;\r
        }\r
\r
        /* ================= SUMMARY ================= */\r
\r
        .summary {\r
            display: grid;\r
            grid-template-columns: repeat(3, 1fr);\r
            gap: 15px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .summary-card {\r
            background: white;\r
            border: 1px solid #e5e8e6;\r
            border-radius: 12px;\r
            padding: 18px;\r
            display: flex;\r
            align-items: center;\r
            gap: 14px;\r
        }\r
\r
        .summary-icon {\r
            width: 45px;\r
            height: 45px;\r
            border-radius: 10px;\r
            background: #e7f8ec;\r
            color: #08752a;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-size: 21px;\r
        }\r
\r
        .summary-info small {\r
            display: block;\r
            color: #999;\r
            font-size: 12px;\r
            margin-bottom: 4px;\r
        }\r
\r
        .summary-info strong {\r
            color: #222;\r
            font-size: 20px;\r
        }\r
\r
        /* ================= SEARCH ================= */\r
\r
        .search-section {\r
            background: white;\r
            border: 1px solid #e5e8e6;\r
            border-radius: 12px;\r
            padding: 15px;\r
            margin-bottom: 20px;\r
        }\r
\r
        .search-box {\r
            position: relative;\r
        }\r
\r
        .search-box input {\r
            width: 100%;\r
            height: 42px;\r
            border: 1px solid #ddd;\r
            border-radius: 8px;\r
            padding: 0 15px 0 40px;\r
            outline: none;\r
            font-size: 13px;\r
        }\r
\r
        .search-box input:focus {\r
            border-color: #19803c;\r
        }\r
\r
        .search-icon {\r
            position: absolute;\r
            left: 14px;\r
            top: 12px;\r
            color: #999;\r
        }\r
\r
        /* ================= MAIN RECOMMENDATION ================= */\r
\r
        .recommendation-wrapper {\r
            display: flex;\r
            gap: 18px;\r
            align-items: stretch;\r
        }\r
\r
        /* ================= TRIGGER PRODUCT ================= */\r
\r
        .trigger-box {\r
            width: 220px;\r
            border: 1px solid #e2e6e3;\r
            border-radius: 13px;\r
            overflow: hidden;\r
            background: white;\r
            flex-shrink: 0;\r
        }\r
\r
        .trigger-title {\r
            height: 60px;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 20px;\r
            color: #444;\r
            font-size: 15px;\r
            font-weight: 700;\r
            border-bottom: 1px solid #eeeeee;\r
        }\r
\r
        .trigger-subtitle {\r
            padding: 12px 20px;\r
            color: #999;\r
            font-size: 11px;\r
            border-bottom: 1px solid #f1f1f1;\r
        }\r
\r
        .trigger-list {\r
            display: flex;\r
            flex-direction: column;\r
            max-height: 480px;\r
            overflow-y: auto;\r
        }\r
\r
        .trigger-item {\r
            width: 100%;\r
            border: none;\r
            background: white;\r
            text-align: left;\r
            padding: 14px 16px;\r
            min-height: 55px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: space-between;\r
            font-size: 13px;\r
            color: #222;\r
            border-bottom: 1px solid #f1f1f1;\r
            cursor: pointer;\r
            transition: 0.2s;\r
        }\r
\r
        .trigger-item:hover {\r
            background: #f1faee;\r
        }\r
\r
        .trigger-item.active {\r
            background: #d9f5ce;\r
            color: #08752a;\r
            font-weight: 700;\r
            border-left: 4px solid #069b45;\r
        }\r
\r
        .trigger-count {\r
            background: #e9e9e9;\r
            color: #777;\r
            border-radius: 20px;\r
            padding: 3px 8px;\r
            font-size: 10px;\r
        }\r
\r
        .trigger-item.active .trigger-count {\r
            background: #b9e9aa;\r
            color: #08752a;\r
        }\r
\r
        /* ================= RECOMMENDED ================= */\r
\r
        .recommended-box {\r
            flex: 1;\r
            border: 1px solid #e2e6e3;\r
            border-radius: 13px;\r
            padding: 22px;\r
            background: white;\r
            min-height: 500px;\r
        }\r
\r
        .recommended-header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: flex-start;\r
            gap: 15px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .recommended-title {\r
            font-size: 20px;\r
            font-weight: 700;\r
            color: #111;\r
        }\r
\r
        .recommended-subtitle {\r
            color: #999;\r
            font-size: 13px;\r
            margin-top: 5px;\r
        }\r
\r
        .current-trigger {\r
            background: #e8f7ec;\r
            color: #19803c;\r
            border-radius: 20px;\r
            padding: 7px 12px;\r
            font-size: 11px;\r
            font-weight: 600;\r
            white-space: nowrap;\r
        }\r
\r
        .product-grid {\r
            display: grid;\r
            grid-template-columns: repeat(3, 1fr);\r
            gap: 16px;\r
        }\r
\r
        /* ================= PRODUCT CARD ================= */\r
\r
        .product-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 12px;\r
            overflow: hidden;\r
            background: #fff;\r
            min-height: 300px;\r
            display: flex;\r
            flex-direction: column;\r
            transition: 0.2s;\r
        }\r
\r
        .product-card:hover {\r
            transform: translateY(-3px);\r
            box-shadow: 0 6px 18px rgba(0,0,0,0.09);\r
            border-color: #2c984d;\r
        }\r
\r
        .product-image-wrapper {\r
            position: relative;\r
            height: 145px;\r
            background: #f2f2f2;\r
            overflow: hidden;\r
        }\r
\r
        .product-image {\r
            width: 100%;\r
            height: 100%;\r
            object-fit: cover;\r
            display: block;\r
        }\r
\r
        .recommend-badge {\r
            position: absolute;\r
            top: 9px;\r
            left: 9px;\r
            background: #19803c;\r
            color: white;\r
            padding: 5px 8px;\r
            border-radius: 6px;\r
            font-size: 9px;\r
            font-weight: bold;\r
        }\r
\r
        .product-info {\r
            padding: 12px;\r
            flex: 1;\r
            display: flex;\r
            flex-direction: column;\r
        }\r
\r
        .product-name {\r
            font-size: 14px;\r
            font-weight: 700;\r
            color: #111;\r
            line-height: 1.3;\r
            margin-bottom: 6px;\r
        }\r
\r
        .product-category {\r
            font-size: 11px;\r
            color: #999;\r
            margin-bottom: 8px;\r
        }\r
\r
        .product-price {\r
            font-size: 15px;\r
            font-weight: 700;\r
            color: #19803c;\r
            margin-top: auto;\r
        }\r
\r
        .card-actions {\r
            display: flex;\r
            gap: 6px;\r
            margin-top: 10px;\r
        }\r
\r
        .card-btn {\r
            flex: 1;\r
            border: none;\r
            border-radius: 6px;\r
            padding: 8px 5px;\r
            cursor: pointer;\r
            font-size: 11px;\r
            font-weight: 600;\r
        }\r
\r
        .view-btn {\r
            background: #eef7f0;\r
            color: #19803c;\r
        }\r
\r
        .edit-btn {\r
            background: #fff5d8;\r
            color: #9a7100;\r
        }\r
\r
        .delete-btn {\r
            background: #ffe9e9;\r
            color: #c62828;\r
        }\r
\r
        .card-btn:hover {\r
            opacity: 0.8;\r
        }\r
\r
        /* ================= EMPTY ================= */\r
\r
        .empty-state {\r
            display: none;\r
            text-align: center;\r
            padding: 60px 20px;\r
            color: #999;\r
        }\r
\r
        .empty-state .empty-icon {\r
            font-size: 45px;\r
            margin-bottom: 12px;\r
        }\r
\r
        .empty-state h3 {\r
            color: #555;\r
            margin-bottom: 5px;\r
        }\r
\r
        /* ================= INFO ================= */\r
\r
        .info-box {\r
            margin-top: 22px;\r
            background: #c9f0d5;\r
            border-radius: 13px;\r
            min-height: 70px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            text-align: center;\r
            padding: 15px 20px;\r
        }\r
\r
        .info-box p {\r
            color: #258642;\r
            font-size: 13px;\r
            font-weight: 600;\r
        }\r
\r
        /* ================= MODAL ================= */\r
\r
        .modal {\r
            display: none;\r
            position: fixed;\r
            inset: 0;\r
            background: rgba(0,0,0,0.55);\r
            justify-content: center;\r
            align-items: center;\r
            z-index: 9999;\r
            padding: 20px;\r
        }\r
\r
        .modal.show {\r
            display: flex;\r
        }\r
\r
        .modal-content {\r
            width: 470px;\r
            max-width: 100%;\r
            max-height: 90vh;\r
            overflow-y: auto;\r
            background: white;\r
            border-radius: 15px;\r
            padding: 25px;\r
            position: relative;\r
        }\r
\r
        .modal-header {\r
            margin-bottom: 20px;\r
        }\r
\r
        .modal-header h2 {\r
            color: #19803c;\r
            font-size: 21px;\r
            margin-bottom: 5px;\r
        }\r
\r
        .modal-header p {\r
            color: #999;\r
            font-size: 12px;\r
        }\r
\r
        .close-modal {\r
            position: absolute;\r
            top: 12px;\r
            right: 15px;\r
            border: none;\r
            background: transparent;\r
            font-size: 25px;\r
            cursor: pointer;\r
            color: #555;\r
        }\r
\r
        .form-group {\r
            margin-bottom: 14px;\r
        }\r
\r
        .form-group label {\r
            display: block;\r
            color: #444;\r
            font-size: 12px;\r
            font-weight: 600;\r
            margin-bottom: 6px;\r
        }\r
\r
        .form-group input,\r
        .form-group select {\r
            width: 100%;\r
            height: 40px;\r
            border: 1px solid #ddd;\r
            border-radius: 7px;\r
            padding: 0 11px;\r
            outline: none;\r
            font-size: 13px;\r
        }\r
\r
        .form-group input:focus,\r
        .form-group select:focus {\r
            border-color: #19803c;\r
        }\r
\r
        .image-preview {\r
            width: 100%;\r
            height: 150px;\r
            border: 1px dashed #ccc;\r
            border-radius: 9px;\r
            margin-top: 8px;\r
            overflow: hidden;\r
            background: #f5f5f5;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            color: #999;\r
            font-size: 12px;\r
        }\r
\r
        .image-preview img {\r
            width: 100%;\r
            height: 100%;\r
            object-fit: cover;\r
        }\r
\r
        .modal-actions {\r
            display: flex;\r
            gap: 10px;\r
            margin-top: 20px;\r
        }\r
\r
        .save-btn,\r
        .cancel-btn {\r
            flex: 1;\r
            height: 42px;\r
            border: none;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            font-weight: 600;\r
        }\r
\r
        .save-btn {\r
            background: #069b45;\r
            color: white;\r
        }\r
\r
        .cancel-btn {\r
            background: #eeeeee;\r
            color: #555;\r
        }\r
\r
        /* ================= PRODUCT DETAILS MODAL ================= */\r
\r
        .details-modal-content {\r
            width: 420px;\r
            text-align: center;\r
        }\r
\r
        .details-modal-content img {\r
            width: 100%;\r
            height: 230px;\r
            object-fit: cover;\r
            border-radius: 10px;\r
            margin-bottom: 15px;\r
        }\r
\r
        .details-modal-content h2 {\r
            color: #111;\r
            margin-bottom: 7px;\r
        }\r
\r
        .details-modal-content p {\r
            color: #777;\r
            margin-bottom: 8px;\r
            font-size: 13px;\r
        }\r
\r
        .modal-price {\r
            font-size: 21px;\r
            font-weight: bold;\r
            color: #19803c;\r
            margin-bottom: 15px;\r
        }\r
\r
        .relation-label {\r
            display: inline-block;\r
            background: #e7f8ec;\r
            color: #19803c;\r
            padding: 6px 10px;\r
            border-radius: 20px;\r
            font-size: 11px;\r
            font-weight: 600;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media (max-width: 1100px) {\r
            .product-grid {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
            .summary {\r
                grid-template-columns: repeat(3, 1fr);\r
            }\r
        }\r
\r
        @media (max-width: 850px) {\r
            .sidebar {\r
                width: 190px;\r
            }\r
\r
            .content {\r
                margin-left: 190px;\r
                padding: 30px 20px;\r
            }\r
\r
            .recommendation-wrapper {\r
                flex-direction: column;\r
            }\r
\r
            .trigger-box {\r
                width: 100%;\r
            }\r
\r
            .trigger-list {\r
                max-height: 250px;\r
            }\r
\r
            .trigger-item {\r
                min-height: 48px;\r
            }\r
        }\r
\r
        @media (max-width: 650px) {\r
            .dashboard {\r
                flex-direction: column;\r
            }\r
\r
            .sidebar {\r
                display: none;\r
            }\r
\r
            .content {\r
                margin-left: 0;\r
            }\r
\r
            .page-header {\r
                flex-direction: column;\r
            }\r
\r
            .add-btn {\r
                width: 100%;\r
            }\r
\r
            .summary {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .product-grid {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .recommended-header {\r
                flex-direction: column;\r
            }\r
        }\r
    </style>\r
</head>\r
\r
<body>\r
\r
<div class="dashboard">\r
\r
    <!-- ================= SIDEBAR ================= -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <nav class="menu">\r
\r
            <a href="{{ url('/dashboard') }}">\r
                <span class="menu-icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="menu-icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}">\r
                <span class="menu-icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}" class="active">\r
                <span class="menu-icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}">\r
                <span class="menu-icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}">\r
                <span class="menu-icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="menu-icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}">\r
                <span class="menu-icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="menu-icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </nav>\r
    </aside>\r
\r
\r
    <!-- ================= MAIN CONTENT ================= -->\r
\r
    <main class="content">\r
\r
        <div class="page-header">\r
\r
            <div>\r
                <h1 class="page-title">\r
                    AI Recommendations\r
                </h1>\r
\r
                <p class="page-subtitle">\r
                    Manage related products used for AI-assisted product recommendations\r
                </p>\r
            </div>\r
\r
            <button class="add-btn" onclick="openAddModal()">\r
                + Add Recommendation\r
            </button>\r
\r
        </div>\r
\r
\r
        <!-- ================= SUMMARY ================= -->\r
\r
        <div class="summary">\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ♧\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Trigger Products</small>\r
                    <strong id="triggerCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ◈\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Recommended Products</small>\r
                    <strong id="recommendationCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ✓\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Recommendation Links</small>\r
                    <strong id="linkCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= SEARCH ================= -->\r
\r
        <div class="search-section">\r
\r
            <div class="search-box">\r
\r
                <span class="search-icon">⌕</span>\r
\r
                <input\r
                    type="text"\r
                    id="searchInput"\r
                    placeholder="Search trigger or recommended product..."\r
                    oninput="searchRecommendations()"\r
                >\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= RECOMMENDATION AREA ================= -->\r
\r
        <div class="recommendation-wrapper">\r
\r
            <div class="trigger-box">\r
\r
                <div class="trigger-title">\r
                    Trigger Products\r
                </div>\r
\r
                <div class="trigger-subtitle">\r
                    Select a product to see its related recommendations.\r
                </div>\r
\r
                <div class="trigger-list" id="triggerList">\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="recommended-box">\r
\r
                <div class="recommended-header">\r
\r
                    <div>\r
\r
                        <h2 class="recommended-title">\r
                            Recommended Products\r
                        </h2>\r
\r
                        <p class="recommended-subtitle" id="recommendationText">\r
                            Products that will be suggested when the selected item is added to cart.\r
                        </p>\r
\r
                    </div>\r
\r
                    <div class="current-trigger" id="currentTrigger">\r
                        No trigger selected\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="product-grid" id="productGrid">\r
                </div>\r
\r
\r
                <div class="empty-state" id="emptyState">\r
\r
                    <div class="empty-icon">\r
                        ♧\r
                    </div>\r
\r
                    <h3>\r
                        No Recommendations Yet\r
                    </h3>\r
\r
                    <p>\r
                        Add related products for this trigger product.\r
                    </p>\r
\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= INFO ================= -->\r
\r
        <div class="info-box">\r
\r
            <p>\r
                AI recommendations help customers discover related products based on the item they are viewing or adding to their cart.\r
            </p>\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
\r
<!-- ================= ADD / EDIT MODAL ================= -->\r
\r
<div class="modal" id="recommendationModal">\r
\r
    <div class="modal-content">\r
\r
        <button class="close-modal" onclick="closeRecommendationModal()">\r
            ×\r
        </button>\r
\r
        <div class="modal-header">\r
\r
            <h2 id="formTitle">\r
                Add Recommendation\r
            </h2>\r
\r
            <p>\r
                Add a related product that can be suggested to customers.\r
            </p>\r
\r
        </div>\r
\r
\r
        <form id="recommendationForm">\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Trigger Product\r
                </label>\r
\r
                <select id="triggerProduct" required>\r
                </select>\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Recommended Product Name\r
                </label>\r
\r
                <input\r
                    type="text"\r
                    id="recommendedName"\r
                    placeholder="Example: Sand (1 cu.ft)"\r
                    required\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Category\r
                </label>\r
\r
                <input\r
                    type="text"\r
                    id="recommendedCategory"\r
                    placeholder="Example: Construction Materials"\r
                    required\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Price\r
                </label>\r
\r
                <input\r
                    type="number"\r
                    id="recommendedPrice"\r
                    placeholder="0.00"\r
                    min="0"\r
                    step="0.01"\r
                    required\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>\r
                    Product Image\r
                </label>\r
\r
                <input\r
                    type="file"\r
                    id="recommendedImage"\r
                    accept="image/*"\r
                    onchange="previewImage(event)"\r
                >\r
\r
                <div class="image-preview" id="imagePreview">\r
                    No image selected\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="modal-actions">\r
\r
                <button\r
                    type="button"\r
                    class="cancel-btn"\r
                    onclick="closeRecommendationModal()"\r
                >\r
                    Cancel\r
                </button>\r
\r
                <button\r
                    type="submit"\r
                    class="save-btn"\r
                >\r
                    Save Recommendation\r
                </button>\r
\r
            </div>\r
\r
        </form>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
<!-- ================= PRODUCT DETAILS MODAL ================= -->\r
\r
<div class="modal" id="productModal">\r
\r
    <div class="modal-content details-modal-content">\r
\r
        <button class="close-modal" onclick="closeProductModal()">\r
            ×\r
        </button>\r
\r
        <img id="modalImage" src="" alt="Product">\r
\r
        <h2 id="modalName">\r
            Product\r
        </h2>\r
\r
        <p id="modalCategory">\r
            Category\r
        </p>\r
\r
        <div class="modal-price" id="modalPrice">\r
            ₱0.00\r
        </div>\r
\r
        <span class="relation-label">\r
            AI Recommended Product\r
        </span>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
\r
</body>\r
</html>`,Zn=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
    <title>Customers - ELEE Hardware</title>\r
\r
    <style>\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
            font-family: Arial, Helvetica, sans-serif;\r
        }\r
\r
        body {\r
            background: #ffffff;\r
            color: #111;\r
        }\r
\r
        .layout {\r
            display: flex;\r
            min-height: 100vh;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            z-index: 100;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= MAIN ================= */\r
\r
        .main {\r
            margin-left: 235px;\r
            width: calc(100% - 235px);\r
            min-height: 100vh;\r
            padding: 30px 40px;\r
        }\r
\r
        .page-header {\r
            margin-bottom: 25px;\r
        }\r
\r
        .page-header h1 {\r
            font-size: 28px;\r
            font-weight: 700;\r
            margin-bottom: 6px;\r
        }\r
\r
        .page-header p {\r
            color: #8c8c8c;\r
            font-size: 14px;\r
        }\r
\r
        /* ================= SUMMARY CARDS ================= */\r
\r
        .summary-grid {\r
            display: grid;\r
            grid-template-columns: repeat(4, 1fr);\r
            gap: 15px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .summary-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 12px;\r
            padding: 18px;\r
            background: white;\r
        }\r
\r
        .summary-label {\r
            color: #777;\r
            font-size: 12px;\r
            margin-bottom: 8px;\r
        }\r
\r
        .summary-value {\r
            font-size: 24px;\r
            font-weight: 700;\r
            color: #00551b;\r
        }\r
\r
        /* ================= TOOLBAR ================= */\r
\r
        .toolbar {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            gap: 15px;\r
            margin-bottom: 25px;\r
            flex-wrap: wrap;\r
        }\r
\r
        .search-container {\r
            width: 350px;\r
            height: 43px;\r
            border: 1px solid #dddddd;\r
            border-radius: 10px;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 13px;\r
            background: white;\r
        }\r
\r
        .search-icon {\r
            font-size: 22px;\r
            color: #999;\r
            margin-right: 10px;\r
        }\r
\r
        .search-container input {\r
            border: none;\r
            outline: none;\r
            width: 100%;\r
            font-size: 13px;\r
        }\r
\r
        .search-container input::placeholder {\r
            color: #999;\r
        }\r
\r
        .clear-search {\r
            border: none;\r
            background: none;\r
            cursor: pointer;\r
            color: #999;\r
            font-size: 17px;\r
            display: none;\r
        }\r
\r
        .clear-search:hover {\r
            color: #00551b;\r
        }\r
\r
        .customer-count {\r
            color: #777;\r
            font-size: 13px;\r
        }\r
\r
        /* ================= TABLE CARD ================= */\r
\r
        .table-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 12px;\r
            overflow: hidden;\r
            background: white;\r
        }\r
\r
        .table-wrapper {\r
            width: 100%;\r
            overflow-x: auto;\r
        }\r
\r
        .customer-table {\r
            width: 100%;\r
            border-collapse: collapse;\r
            min-width: 1000px;\r
        }\r
\r
        .customer-table thead {\r
            background: #f8f9f8;\r
        }\r
\r
        .customer-table th {\r
            text-align: left;\r
            font-size: 12px;\r
            font-weight: 700;\r
            color: #555;\r
            padding: 16px 18px;\r
            border-bottom: 1px solid #e5e5e5;\r
            white-space: nowrap;\r
        }\r
\r
        .customer-table td {\r
            padding: 17px 18px;\r
            font-size: 13px;\r
            border-bottom: 1px solid #eeeeee;\r
            vertical-align: middle;\r
        }\r
\r
        .customer-table tbody tr:hover {\r
            background: #fafafa;\r
        }\r
\r
        .customer-table tbody tr:last-child td {\r
            border-bottom: none;\r
        }\r
\r
        .customer-name {\r
            font-weight: 700;\r
            color: #222;\r
        }\r
\r
        .mobile-number {\r
            color: #444;\r
        }\r
\r
        .address {\r
            color: #666;\r
            max-width: 260px;\r
            white-space: normal !important;\r
            line-height: 1.4;\r
        }\r
\r
        .orders-count {\r
            font-weight: 600;\r
            color: #00551b;\r
        }\r
\r
        .amount {\r
            font-weight: 600;\r
        }\r
\r
        .last-order {\r
            color: #555;\r
        }\r
\r
        /* ================= VIEW HISTORY BUTTON ================= */\r
\r
        .history-btn {\r
            border: 1px solid #00551b;\r
            background: white;\r
            color: #00551b;\r
            padding: 8px 12px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 12px;\r
            font-weight: 600;\r
            transition: 0.2s;\r
        }\r
\r
        .history-btn:hover {\r
            background: #00551b;\r
            color: white;\r
        }\r
\r
        /* ================= EMPTY STATE ================= */\r
\r
        .empty-state {\r
            display: none;\r
            text-align: center;\r
            padding: 55px 20px;\r
        }\r
\r
        .empty-icon {\r
            font-size: 40px;\r
            color: #bbb;\r
            margin-bottom: 12px;\r
        }\r
\r
        .empty-state h3 {\r
            font-size: 17px;\r
            margin-bottom: 6px;\r
        }\r
\r
        .empty-state p {\r
            color: #888;\r
            font-size: 13px;\r
        }\r
\r
        /* ================= PAGINATION ================= */\r
\r
        .pagination-area {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            padding: 18px 20px;\r
            border-top: 1px solid #eeeeee;\r
        }\r
\r
        .pagination-info {\r
            color: #777;\r
            font-size: 12px;\r
        }\r
\r
        .pagination {\r
            display: flex;\r
            align-items: center;\r
            gap: 5px;\r
        }\r
\r
        .page-btn {\r
            min-width: 30px;\r
            height: 30px;\r
            border: 1px solid #dddddd;\r
            background: white;\r
            border-radius: 6px;\r
            cursor: pointer;\r
            font-size: 12px;\r
            color: #555;\r
        }\r
\r
        .page-btn:hover {\r
            background: #f0f0f0;\r
        }\r
\r
        .page-btn.active {\r
            background: #299447;\r
            border-color: #299447;\r
            color: white;\r
            font-weight: bold;\r
        }\r
\r
        .page-btn:disabled {\r
            opacity: 0.4;\r
            cursor: not-allowed;\r
        }\r
\r
        /* ================= MODAL ================= */\r
\r
        .modal-overlay {\r
            display: none;\r
            position: fixed;\r
            inset: 0;\r
            background: rgba(0, 0, 0, 0.45);\r
            z-index: 500;\r
            align-items: center;\r
            justify-content: center;\r
            padding: 20px;\r
        }\r
\r
        .modal-overlay.show {\r
            display: flex;\r
        }\r
\r
        .modal {\r
            width: 100%;\r
            max-width: 750px;\r
            max-height: 90vh;\r
            overflow-y: auto;\r
            background: white;\r
            border-radius: 14px;\r
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.2);\r
        }\r
\r
        .modal-header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            padding: 20px 24px;\r
            border-bottom: 1px solid #eeeeee;\r
            position: sticky;\r
            top: 0;\r
            background: white;\r
            z-index: 2;\r
        }\r
\r
        .modal-header h2 {\r
            font-size: 19px;\r
            color: #222;\r
        }\r
\r
        .close-btn {\r
            border: none;\r
            background: #f1f1f1;\r
            width: 32px;\r
            height: 32px;\r
            border-radius: 50%;\r
            cursor: pointer;\r
            font-size: 18px;\r
            color: #555;\r
        }\r
\r
        .close-btn:hover {\r
            background: #e5e5e5;\r
        }\r
\r
        .modal-body {\r
            padding: 24px;\r
        }\r
\r
        /* ================= CUSTOMER INFO ================= */\r
\r
        .customer-info {\r
            display: grid;\r
            grid-template-columns: repeat(2, 1fr);\r
            gap: 15px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .info-box {\r
            background: #f8faf8;\r
            border-radius: 9px;\r
            padding: 14px;\r
        }\r
\r
        .info-box.full {\r
            grid-column: 1 / -1;\r
        }\r
\r
        .info-label {\r
            font-size: 11px;\r
            color: #888;\r
            margin-bottom: 5px;\r
        }\r
\r
        .info-value {\r
            font-size: 13px;\r
            font-weight: 600;\r
            color: #222;\r
        }\r
\r
        /* ================= ORDER HISTORY ================= */\r
\r
        .history-title {\r
            font-size: 16px;\r
            margin-bottom: 12px;\r
            color: #222;\r
        }\r
\r
        .history-table-wrapper {\r
            overflow-x: auto;\r
            border: 1px solid #e5e5e5;\r
            border-radius: 9px;\r
        }\r
\r
        .history-table {\r
            width: 100%;\r
            border-collapse: collapse;\r
            min-width: 600px;\r
        }\r
\r
        .history-table th {\r
            background: #f7f8f7;\r
            text-align: left;\r
            padding: 12px;\r
            font-size: 11px;\r
            color: #666;\r
            white-space: nowrap;\r
        }\r
\r
        .history-table td {\r
            padding: 12px;\r
            border-top: 1px solid #eeeeee;\r
            font-size: 12px;\r
            white-space: nowrap;\r
        }\r
\r
        .status {\r
            display: inline-block;\r
            padding: 5px 9px;\r
            border-radius: 20px;\r
            font-size: 10px;\r
            font-weight: 700;\r
        }\r
\r
        .status.paid {\r
            background: #e4f6e9;\r
            color: #168139;\r
        }\r
\r
        .status.unpaid {\r
            background: #fff4d6;\r
            color: #9a7000;\r
        }\r
\r
        .status.cancelled {\r
            background: #fce8e8;\r
            color: #b52a2a;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media (max-width: 1100px) {\r
            .summary-grid {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
        }\r
\r
        @media (max-width: 900px) {\r
\r
            .sidebar {\r
                width: 190px;\r
            }\r
\r
            .main {\r
                margin-left: 190px;\r
                width: calc(100% - 190px);\r
                padding: 25px;\r
            }\r
\r
            .customer-table {\r
                min-width: 1050px;\r
            }\r
\r
            .toolbar {\r
                align-items: flex-start;\r
            }\r
        }\r
\r
        @media (max-width: 650px) {\r
\r
            .sidebar {\r
                width: 70px;\r
                padding: 20px 8px;\r
            }\r
\r
            .logo {\r
                margin-left: 5px;\r
            }\r
\r
            .logo-name {\r
                font-size: 20px;\r
                letter-spacing: -1px;\r
            }\r
\r
            .hardware {\r
                display: none;\r
            }\r
\r
            .menu a {\r
                justify-content: center;\r
                padding: 12px 5px;\r
            }\r
\r
            .menu a span:not(.icon) {\r
                display: none;\r
            }\r
\r
            .main {\r
                margin-left: 70px;\r
                width: calc(100% - 70px);\r
                padding: 20px;\r
            }\r
\r
            .summary-grid {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .search-container {\r
                width: 100%;\r
            }\r
\r
            .toolbar {\r
                display: block;\r
            }\r
\r
            .customer-count {\r
                display: block;\r
                margin-top: 10px;\r
            }\r
\r
            .pagination-area {\r
                display: block;\r
            }\r
\r
            .pagination {\r
                margin-top: 12px;\r
                justify-content: center;\r
            }\r
\r
            .customer-info {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .info-box.full {\r
                grid-column: auto;\r
            }\r
        }\r
    </style>\r
</head>\r
\r
<body>\r
\r
<div class="layout">\r
\r
    <!-- ================= SIDEBAR ================= -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <nav class="menu">\r
\r
            <a href="{{ url('/dashboard') }}">\r
                <span class="icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}">\r
                <span class="icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}">\r
                <span class="icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}">\r
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}" class="active">\r
                <span class="icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}">\r
                <span class="icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </nav>\r
\r
    </aside>\r
\r
\r
    <!-- ================= MAIN ================= -->\r
\r
    <main class="main customer-page">\r
\r
        <div class="page-header">\r
            <h1>Customer Records</h1>\r
            <p>View customer information and order history</p>\r
        </div>\r
\r
\r
        <!-- ================= SUMMARY ================= -->\r
\r
        <div class="summary-grid">\r
\r
            <div class="summary-card">\r
                <div class="summary-label">Total Customers</div>\r
                <div class="summary-value" id="totalCustomers">0</div>\r
            </div>\r
\r
            <div class="summary-card">\r
                <div class="summary-label">Total Orders</div>\r
                <div class="summary-value" id="totalOrders">0</div>\r
            </div>\r
\r
            <div class="summary-card">\r
                <div class="summary-label">Total Sales</div>\r
                <div class="summary-value" id="totalSales">₱ 0.00</div>\r
            </div>\r
\r
            <div class="summary-card">\r
                <div class="summary-label">Active Customers</div>\r
                <div class="summary-value" id="activeCustomers">0</div>\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= SEARCH ================= -->\r
\r
        <div class="toolbar">\r
\r
            <div class="search-container">\r
\r
                <span class="search-icon">⌕</span>\r
\r
                <input\r
                    type="text"\r
                    id="customerSearch"\r
                    placeholder="Search customer, mobile number, or address..."\r
                    oninput="searchCustomer()"\r
                >\r
\r
                <button\r
                    type="button"\r
                    class="clear-search"\r
                    id="clearSearch"\r
                    onclick="clearSearch()"\r
                >\r
                    ×\r
                </button>\r
\r
            </div>\r
\r
            <div class="customer-count" id="customerCount">\r
                Showing 0 customers\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= CUSTOMER TABLE ================= -->\r
\r
        <div class="table-card">\r
\r
            <div class="table-wrapper">\r
\r
                <table class="customer-table">\r
\r
                    <thead>\r
                        <tr>\r
                            <th>Customer Name</th>\r
                            <th>Mobile Number</th>\r
                            <th>Delivery Address</th>\r
                            <th>Total Orders</th>\r
                            <th>Total Spent</th>\r
                            <th>Last Order</th>\r
                            <th>Order History</th>\r
                        </tr>\r
                    </thead>\r
\r
                    <tbody id="customerTable"></tbody>\r
\r
                </table>\r
\r
            </div>\r
\r
\r
            <!-- EMPTY STATE -->\r
\r
            <div class="empty-state" id="emptyState">\r
\r
                <div class="empty-icon">⌕</div>\r
\r
                <h3>No customer found</h3>\r
\r
                <p>\r
                    Try searching using a different customer name,\r
                    mobile number, or address.\r
                </p>\r
\r
            </div>\r
\r
\r
            <!-- PAGINATION -->\r
\r
            <div class="pagination-area">\r
\r
                <div class="pagination-info" id="paginationInfo">\r
                    Showing 0 to 0 of 0 customers\r
                </div>\r
\r
                <div class="pagination" id="pagination">\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
<!-- ================= ORDER HISTORY MODAL ================= -->\r
\r
<div class="modal-overlay" id="historyModal">\r
\r
    <div class="modal">\r
\r
        <div class="modal-header">\r
\r
            <h2>Customer Details</h2>\r
\r
            <button\r
                class="close-btn"\r
                onclick="closeHistory()"\r
            >\r
                ×\r
            </button>\r
\r
        </div>\r
\r
\r
        <div class="modal-body">\r
\r
            <!-- CUSTOMER INFORMATION -->\r
\r
            <div class="customer-info">\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Customer Name\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalCustomerName"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Mobile Number\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalMobile"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box full">\r
\r
                    <div class="info-label">\r
                        Delivery Address\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalAddress"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Total Orders\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalTotalOrders"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Total Spent\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalTotalSpent"\r
                    >\r
                    </div>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- ORDER HISTORY -->\r
\r
            <h3 class="history-title">\r
                Order History\r
            </h3>\r
\r
            <div class="history-table-wrapper">\r
\r
                <table class="history-table">\r
\r
                    <thead>\r
                        <tr>\r
                            <th>Order ID</th>\r
                            <th>Date</th>\r
                            <th>Items</th>\r
                            <th>Amount</th>\r
                            <th>Payment</th>\r
                            <th>Status</th>\r
                        </tr>\r
                    </thead>\r
\r
                    <tbody id="historyTable"></tbody>\r
\r
                </table>\r
\r
            </div>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
</body>\r
</html>\r
`,Jn=`<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>EleeSiWeb - Dashboard</title>

    

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        body {
            background: #ffffff;
            color: #151515;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }


        /* ================= SIDEBAR ================= */

        .sidebar {
            width: 235px;
            min-height: 100vh;
            background: #00551f;
            color: white;
            padding: 28px 16px;
            flex-shrink: 0;
        }

        .logo {
            font-size: 36px;
            font-weight: 900;
            margin-left: 12px;
            letter-spacing: -2px;
        }

        .logo span {
            color: #ffbd00;
        }

        .hardware {
            color: #ffbd00;
            font-size: 14px;
            font-weight: bold;
            margin-left: 13px;
            margin-top: 3px;
            margin-bottom: 25px;
        }

        .menu {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .menu a {
            text-decoration: none;
            color: white;
            padding: 13px 14px;
            border-radius: 7px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: 0.2s;
        }

        .menu a:hover {
            background: #08732e;
        }

        .menu a.active {
            background: #08732e;
        }

        .icon {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        /* ================= LOGOUT ================= */

        .menu a.logout {
            margin-top: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            padding-top: 16px;
        }

        .menu a.logout:hover {
            background: #8b1e1e;
        }


        /* ================= MAIN ================= */

        .main {
            flex: 1;
            min-width: 0;
            background: #ffffff;
        }

        .content {
            padding: 30px 28px 35px;
        }

        .header {
            margin-bottom: 22px;
        }

        .header h1 {
            font-size: 31px;
            margin-bottom: 4px;
        }

        .header p {
            color: #8b8b8b;
            font-size: 15px;
        }


        /* ================= SUMMARY CARDS ================= */

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 20px;
        }

        .card {
            background: #ffffff;
            border: 1px solid #e5e7e5;
            border-radius: 13px;
            padding: 18px;
            min-height: 135px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        }

        .card-top {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .card-icon {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .green-icon {
            background: #d9f8e5;
            color: #08752a;
        }

        .yellow-icon {
            background: #fff0c8;
            color: #e49a00;
        }

        .purple-icon {
            background: #efd8ff;
            color: #8b00c9;
        }

        .red-icon {
            background: #ffe0e0;
            color: #d63031;
        }

        .card-title {
            font-size: 14px;
            font-weight: 600;
        }

        .card-number {
            font-size: 27px;
            font-weight: 700;
            margin-top: 8px;
            margin-left: 54px;
        }

        .card-change {
            color: #16a34a;
            font-size: 11px;
            margin-left: 54px;
            margin-top: 6px;
        }

        .card-warning {
            color: #d63031;
            font-size: 11px;
            margin-left: 54px;
            margin-top: 6px;
        }


        /* ================= CHART ROW ================= */

        .chart-row {
            display: grid;
            grid-template-columns: 1.65fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .box {
            background: white;
            border: 1px solid #e4e7e4;
            border-radius: 13px;
            padding: 18px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        }

        .box-title {
            font-size: 16px;
            font-weight: 700;
        }

        .box-subtitle {
            color: #999;
            font-size: 12px;
            margin-top: 4px;
        }

        .chart-container {
            height: 250px;
            margin-top: 10px;
        }


        /* ================= PAYMENT OVERVIEW ================= */

        .payment-overview {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 20px;
        }

        .payment-card {
            border: 1px solid #e5e7e5;
            border-radius: 10px;
            padding: 15px;
        }

        .payment-label {
            color: #777;
            font-size: 12px;
            margin-bottom: 7px;
        }

        .payment-value {
            font-size: 21px;
            font-weight: bold;
        }

        .paid-value {
            color: #08752a;
        }

        .unpaid-value {
            color: #d97706;
        }


        /* ================= ORDER STATUS ================= */

        .order-status {
            display: flex;
            align-items: center;
            justify-content: space-between;
            min-height: 250px;
            gap: 15px;
        }

        .donut {
            width: 205px;
            height: 205px;
            position: relative;
            flex-shrink: 0;
        }

        .donut canvas {
            width: 100% !important;
            height: 100% !important;
        }

        .donut-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            pointer-events: none;
        }

        .donut-number {
            font-size: 23px;
            font-weight: 700;
        }

        .donut-total {
            font-size: 11px;
            color: #888;
            margin-top: 2px;
        }

        .status-list {
            display: flex;
            flex-direction: column;
            gap: 17px;
            flex: 1;
        }

        .status-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 11px;
        }

        .status-item strong {
            margin-left: auto;
            font-size: 10px;
        }

        .status-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            flex-shrink: 0;
        }

        .completed {
            background: #08752a;
        }

        .processing {
            background: #16a34a;
        }

        .pending {
            background: #ffad00;
        }

        .ready {
            background: #8e00c7;
        }


        /* ================= BOTTOM ================= */

        .bottom-row {
            display: grid;
            grid-template-columns: 1.65fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .box-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .see-all {
            color: #08752a;
            font-size: 12px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
        }

        .see-all:hover {
            text-decoration: underline;
        }


        /* ================= TABLE ================= */

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th {
            text-align: left;
            color: #888;
            font-size: 11px;
            font-weight: 500;
            padding: 9px 5px;
            border-bottom: 1px solid #eeeeee;
        }

        td {
            padding: 12px 5px;
            font-size: 12px;
            border-bottom: 1px solid #eeeeee;
        }

        .order-id {
            font-weight: 600;
        }

        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: bold;
        }

        .badge-completed {
            background: #d7f8e4;
            color: #08752a;
        }

        .badge-pending {
            background: #fff0bd;
            color: #8a6200;
        }

        .badge-ready {
            background: #efd7ff;
            color: #7800a8;
        }


        /* ================= LOW STOCK ================= */

        .stock-list {
            margin-top: 13px;
        }

        .stock-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 13px 0;
            border-bottom: 1px solid #eeeeee;
        }

        .stock-image {
            width: 43px;
            height: 43px;
            border-radius: 7px;
            background: #ffeaea;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 21px;
        }

        .stock-info {
            flex: 1;
        }

        .stock-name {
            font-size: 12px;
            font-weight: 700;
        }

        .stock-description {
            font-size: 10px;
            color: #888;
            margin-top: 3px;
        }

        .stock-number {
            text-align: right;
        }

        .stock-quantity {
            color: #d63031;
            font-size: 12px;
            font-weight: bold;
        }

        .stock-label {
            color: #888;
            font-size: 9px;
        }


        /* ================= TOP SELLING PRODUCTS ================= */

        .product-list {
            margin-top: 13px;
        }

        .product {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 0;
            border-bottom: 1px solid #eeeeee;
        }

        .product-image {
            width: 43px;
            height: 43px;
            border-radius: 7px;
            background: #eeeeee;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .product-info {
            flex: 1;
        }

        .product-name {
            font-size: 12px;
            font-weight: 700;
        }

        .product-price {
            font-size: 10px;
            color: #888;
            margin-top: 3px;
        }

        .product-sales {
            text-align: right;
        }

        .sales-number {
            color: #08752a;
            font-size: 12px;
            font-weight: bold;
        }

        .sold {
            color: #888;
            font-size: 9px;
        }


        /* ================= RESPONSIVE ================= */

        @media (max-width: 1100px) {

            .sidebar {
                width: 200px;
            }

            .cards {
                grid-template-columns: repeat(2, 1fr);
            }

            .chart-row,
            .bottom-row {
                grid-template-columns: 1fr;
            }
        }


        @media (max-width: 700px) {

            .sidebar {
                display: none;
            }

            .cards {
                grid-template-columns: 1fr;
            }

            .content {
                padding: 20px;
            }

            .payment-overview {
                grid-template-columns: 1fr;
            }

            .order-status {
                flex-direction: column;
                padding: 15px 0;
            }

            .donut {
                width: 180px;
                height: 180px;
            }

            .box {
                overflow-x: auto;
            }

            table {
                min-width: 600px;
            }
        }

    </style>

</head>


<body>


<div class="dashboard">


    <!-- ================= SIDEBAR ================= -->

    <aside class="sidebar">

        <div class="logo">
            <span style="color:white;">E</span><span>LEE</span>
        </div>

        <div class="hardware">
            HARDWARE
        </div>

        <div class="menu">

            <a href="{{ url('/') }}" class="active">
                <span class="icon">☼</span>
                Dashboard
            </a>

            <a href="{{ url('/orders') }}">
                <span class="icon">▣</span>
                Orders
            </a>

            <a href="{{ url('/products') }}">
                <span class="icon">◇</span>
                Products
            </a>

            <a href="{{ url('/ai-recommendations') }}">
                <span class="icon">↗</span>
                AI Recommendations
            </a>

            <a href="{{ url('/payments') }}">
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>
                Payments
            </a>

            <a href="{{ url('/customers') }}">
                <span class="icon">♙</span>
                Customers
            </a>

            <a href="{{ url('/queuing') }}">
                <span class="icon">▱</span>
                Queuing
            </a>

            <a href="{{ url('/receipt-records') }}">
                <span class="icon">▤</span>
                Receipt Records
            </a>

            <a href="{{ url('/settings') }}">
                <span class="icon">⚙</span>
                Settings
            </a>

            <!-- ================= LOGOUT ================= -->

            <a href="{{ url('/admin/logout') }}" class="logout">
                <span class="icon">↪</span>
                Logout
            </a>

        </div>

    </aside>


    <!-- ================= MAIN ================= -->

    <main class="main">

        <div class="content">


            <!-- ================= HEADER ================= -->

            <div class="header">

                <h1>
                    Dashboard
                </h1>

                <p>
                    Overview of your store orders, sales, payments, and inventory.
                </p>

            </div>


            <!-- ================= SUMMARY CARDS ================= -->

            <div class="cards">


                <!-- TOTAL ORDERS -->

                <div class="card">

                    <div class="card-top">

                        <div class="card-icon green-icon">
                            🛒
                        </div>

                        <div class="card-title">
                            Total Orders
                        </div>

                    </div>

                    <div class="card-number">
                        128
                    </div>

                    <div class="card-change">
                        ↑ 12% from yesterday
                    </div>

                </div>


                <!-- PENDING ORDERS -->

                <div class="card">

                    <div class="card-top">

                        <div class="card-icon yellow-icon">
                            ◷
                        </div>

                        <div class="card-title">
                            Pending Orders
                        </div>

                    </div>

                    <div class="card-number">
                        28
                    </div>

                    <div class="card-change">
                        21.9% of total orders
                    </div>

                </div>


                <!-- TOTAL SALES -->

                <div class="card">

                    <div class="card-top">

                        <div class="card-icon purple-icon">
                            ₱
                        </div>

                        <div class="card-title">
                            Total Sales
                        </div>

                    </div>

                    <div class="card-number">
                        ₱98,450.00
                    </div>

                    <div class="card-change">
                        ↑ 12% from yesterday
                    </div>

                </div>


                <!-- LOW STOCK -->

                <div class="card">

                    <div class="card-top">

                        <div class="card-icon red-icon">
                            ⚠
                        </div>

                        <div class="card-title">
                            Low-Stock Products
                        </div>

                    </div>

                    <div class="card-number">
                        6
                    </div>

                    <div class="card-warning">
                        Requires attention
                    </div>

                </div>


            </div>


            <!-- ================= CHART ROW ================= -->

            <div class="chart-row">


                <!-- SALES REVENUE -->

                <div class="box">

                    <div class="box-title">
                        Sales Revenue Trend
                    </div>

                    <div class="box-subtitle">
                        Monthly performance overview
                    </div>

                    <div class="chart-container">

                        <canvas id="salesChart"></canvas>

                    </div>

                </div>


                <!-- ORDER STATUS -->

                <div class="box">

                    <div class="box-title">
                        Order Status
                    </div>

                    <div class="box-subtitle">
                        Current order overview
                    </div>


                    <div class="order-status">


                        <div class="donut">

                            <canvas id="orderChart"></canvas>

                            <div class="donut-center">

                                <div class="donut-number">
                                    128
                                </div>

                                <div class="donut-total">
                                    Total Orders
                                </div>

                            </div>

                        </div>


                        <div class="status-list">


                            <div class="status-item">

                                <span class="status-dot completed"></span>

                                <span>
                                    Completed
                                </span>

                                <strong>
                                    98
                                </strong>

                            </div>


                            <div class="status-item">

                                <span class="status-dot pending"></span>

                                <span>
                                    Pending
                                </span>

                                <strong>
                                    28
                                </strong>

                            </div>


                            <div class="status-item">

                                <span class="status-dot processing"></span>

                                <span>
                                    Processing
                                </span>

                                <strong>
                                    1
                                </strong>

                            </div>


                            <div class="status-item">

                                <span class="status-dot ready"></span>

                                <span>
                                    Ready
                                </span>

                                <strong>
                                    1
                                </strong>

                            </div>


                        </div>

                    </div>

                </div>


            </div>


            <!-- ================= PAYMENT OVERVIEW ================= -->

            <div class="box" style="margin-bottom:20px;">

                <div class="box-title">
                    Payment Overview
                </div>

                <div class="box-subtitle">
                    Summary of customer payment status
                </div>


                <div class="payment-overview">


                    <div class="payment-card">

                        <div class="payment-label">
                            Paid Orders
                        </div>

                        <div class="payment-value paid-value">
                            98 Orders
                        </div>

                    </div>


                    <div class="payment-card">

                        <div class="payment-label">
                            Unpaid Orders
                        </div>

                        <div class="payment-value unpaid-value">
                            30 Orders
                        </div>

                    </div>


                    <div class="payment-card">

                        <div class="payment-label">
                            Paid Amount
                        </div>

                        <div class="payment-value paid-value">
                            ₱78,320.00
                        </div>

                    </div>


                    <div class="payment-card">

                        <div class="payment-label">
                            Unpaid Amount
                        </div>

                        <div class="payment-value unpaid-value">
                            ₱20,130.00
                        </div>

                    </div>


                </div>

            </div>


            <!-- ================= BOTTOM ROW ================= -->

            <div class="bottom-row">


                <!-- RECENT ORDERS -->

                <div class="box">

                    <div class="box-header">

                        <div>

                            <div class="box-title">
                                Recent Orders
                            </div>

                            <div class="box-subtitle">
                                Latest customer orders
                            </div>

                        </div>

                        <!-- CLICKABLE SEE ALL ORDERS -->

                        <a href="{{ url('/orders') }}" class="see-all">
                            See All Orders →
                        </a>

                    </div>


                    <table>

                        <thead>

                            <tr>

                                <th>
                                    Order ID
                                </th>

                                <th>
                                    Customer
                                </th>

                                <th>
                                    Date
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Amount
                                </th>

                            </tr>

                        </thead>


                        <tbody></tbody>

                    </table>

                </div>


                <!-- LOW STOCK PRODUCTS -->

                <div class="box">

                    <div class="box-title">
                        Low-Stock Products
                    </div>

                    <div class="box-subtitle">
                        Products that need restocking
                    </div>


                    <div class="stock-list">


                        <div class="stock-item">

                            <div class="stock-image">
                                🧱
                            </div>

                            <div class="stock-info">

                                <div class="stock-name">
                                    Cement 25kg
                                </div>

                                <div class="stock-description">
                                    Inventory level is low
                                </div>

                            </div>

                            <div class="stock-number">

                                <div class="stock-quantity">
                                    8
                                </div>

                                <div class="stock-label">
                                    left
                                </div>

                            </div>

                        </div>


                        <div class="stock-item">

                            <div class="stock-image">
                                🔩
                            </div>

                            <div class="stock-info">

                                <div class="stock-name">
                                    GI Sheet 0.3mm
                                </div>

                                <div class="stock-description">
                                    Inventory level is low
                                </div>

                            </div>

                            <div class="stock-number">

                                <div class="stock-quantity">
                                    5
                                </div>

                                <div class="stock-label">
                                    left
                                </div>

                            </div>

                        </div>


                        <div class="stock-item">

                            <div class="stock-image">
                                🔨
                            </div>

                            <div class="stock-info">

                                <div class="stock-name">
                                    Hammer
                                </div>

                                <div class="stock-description">
                                    Inventory level is low
                                </div>

                            </div>

                            <div class="stock-number">

                                <div class="stock-quantity">
                                    4
                                </div>

                                <div class="stock-label">
                                    left
                                </div>

                            </div>

                        </div>


                        <div class="stock-item">

                            <div class="stock-image">
                                🔩
                            </div>

                            <div class="stock-info">

                                <div class="stock-name">
                                    Nails 1kg
                                </div>

                                <div class="stock-description">
                                    Inventory level is low
                                </div>

                            </div>

                            <div class="stock-number">

                                <div class="stock-quantity">
                                    3
                                </div>

                                <div class="stock-label">
                                    left
                                </div>

                            </div>

                        </div>


                    </div>

                </div>


            </div>


            <!-- ================= TOP SELLING PRODUCTS ================= -->

            <div class="box">

                <div class="box-title">
                    Top-Selling Products
                </div>

                <div class="box-subtitle">
                    Highest demand products this week
                </div>


                <div class="product-list">


                    <div class="product">

                        <div class="product-image">
                            🧱
                        </div>

                        <div class="product-info">

                            <div class="product-name">
                                Hollow Blocks 4"
                            </div>

                            <div class="product-price">
                                ₱250.00/pc
                            </div>

                        </div>

                        <div class="product-sales">

                            <div class="sales-number">
                                340
                            </div>

                            <div class="sold">
                                sold
                            </div>

                        </div>

                    </div>


                    <div class="product">

                        <div class="product-image">
                            🔩
                        </div>

                        <div class="product-info">

                            <div class="product-name">
                                GI Sheet 0.3mm
                            </div>

                            <div class="product-price">
                                ₱350.00/pc
                            </div>

                        </div>

                        <div class="product-sales">

                            <div class="sales-number">
                                180
                            </div>

                            <div class="sold">
                                sold
                            </div>

                        </div>

                    </div>


                    <div class="product">

                        <div class="product-image">
                            🧱
                        </div>

                        <div class="product-info">

                            <div class="product-name">
                                Cement 25kg
                            </div>

                            <div class="product-price">
                                ₱125.00/pc
                            </div>

                        </div>

                        <div class="product-sales">

                            <div class="sales-number">
                                124
                            </div>

                            <div class="sold">
                                sold
                            </div>

                        </div>

                    </div>


                </div>

            </div>


        </div>

    </main>

</div>


<!-- ================= JAVASCRIPT ================= -->




</body>
</html>`,Xn=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
<meta charset="UTF-8">\r
<meta name="viewport" content="width=device-width, initial-scale=1.0">\r
<title>EleeSiWeb - Orders & Products</title>\r
\r
<style>\r
*{box-sizing:border-box;margin:0;padding:0}\r
body{font-family:Arial,Helvetica,sans-serif;background:#fff;color:#111}\r
\r
.sidebar{position:fixed;left:0;top:0;width:235px;height:100vh;background:#00551f;color:#fff;padding:28px 16px;z-index:100}\r
.logo{font-size:36px;font-weight:900;margin-left:12px;letter-spacing:-2px}\r
.logo span{color:#ffbd00}\r
.hardware{color:#ffbd00;font-size:14px;font-weight:bold;margin-left:13px;margin-top:3px;margin-bottom:25px}\r
.menu{display:flex;flex-direction:column;gap:7px}\r
.menu a{text-decoration:none;color:#fff;padding:13px 14px;border-radius:7px;font-size:14px;display:flex;align-items:center;gap:12px}\r
.menu a:hover,.menu a.active{background:#08732e}\r
.icon{width:20px;text-align:center;font-size:18px}\r
\r
.main{margin-left:235px;padding:46px 42px;min-height:100vh}\r
.section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;gap:20px}\r
.section-title{font-size:25px;color:#147a36;font-weight:600}\r
.section-description{color:#777;font-size:14px;margin-top:4px}\r
\r
.tabs{\r
    display:grid;\r
    grid-template-columns:repeat(6,minmax(0,1fr));\r
    align-items:center;\r
    column-gap:18px;\r
    width:100%;\r
    min-width:950px;\r
    margin-bottom:18px\r
}\r
.tab{\r
    width:100%;border:none;background:transparent;font-size:15px;\r
    font-weight:600;cursor:pointer;padding:10px 8px;white-space:nowrap;\r
    color:#111;border-radius:7px;text-align:center\r
}\r
.tab.active{background:#b9e8c0;color:#075b21}\r
.tab:hover{background:#e4f5e7;color:#075b21}\r
\r
.search-container{width:100%;margin-bottom:25px}\r
.search-box{\r
    width:100%;height:55px;border:1px solid #dedede;border-radius:10px;\r
    display:flex;align-items:center;padding:0 18px;\r
    box-shadow:0 1px 4px rgba(0,0,0,.03)\r
}\r
.search-icon{font-size:28px;color:#999;margin-right:15px}\r
.search-box input{border:none;outline:none;width:100%;font-size:16px;color:#333}\r
.search-box input::placeholder{color:#999}\r
\r
.orders-table,.products-table{width:100%;overflow-x:auto}\r
.table-header,.order-row{\r
    display:grid;\r
    grid-template-columns:1.45fr 1.25fr 1fr .75fr 1.55fr .55fr;\r
    align-items:center;column-gap:18px;min-width:950px\r
}\r
.table-header{padding:0 3px 16px;font-size:15px;font-weight:700}\r
.order-row{min-height:75px;border-top:1px solid #eee;font-size:14px}\r
.order-id,.customer,.total{font-weight:600}\r
.date{color:#555}\r
\r
.status{display:inline-block;width:max-content;padding:6px 10px;border-radius:5px;font-size:12px;font-weight:600}\r
.pending{background:#fff0bd;color:#e49b00}\r
.processing{background:#c9e0ff;color:#277ed8}\r
.ready{background:#c3edc5;color:#13a52a}\r
.completed{background:#bcebbf;color:#08a425}\r
.cancelled{background:#ffc5c5;color:#e33b3b}\r
\r
.view-btn,.edit-btn{\r
    border:none;background:#b9e8c0;color:#16833a;padding:7px 13px;\r
    border-radius:5px;cursor:pointer;font-size:13px;font-weight:600\r
}\r
.view-btn:hover,.edit-btn:hover{background:#91d99d}\r
\r
.add-btn{\r
    background:#08752f;color:#fff;border:none;padding:11px 18px;\r
    border-radius:7px;cursor:pointer;font-size:14px;font-weight:600\r
}\r
.add-btn:hover{background:#065b25}\r
\r
.no-results{display:none;padding:25px;text-align:center;color:#777}\r
\r
.bottom{\r
    display:flex;justify-content:space-between;align-items:center;\r
    margin-top:30px;margin-bottom:70px;font-size:14px;color:#444\r
}\r
.pagination{display:flex;align-items:center;gap:8px}\r
.page{\r
    cursor:pointer;font-weight:500;min-width:32px;height:32px;\r
    display:flex;align-items:center;justify-content:center;\r
    border-radius:5px;padding:0 7px\r
}\r
.page.active{background:#299b4d;color:#fff}\r
.page:hover{background:#e4f5e7;color:#147a36}\r
.page.disabled{color:#bbb;cursor:not-allowed;background:none}\r
\r
.section-divider{height:1px;background:#e5e5e5;margin:20px 0 45px}\r
\r
.product-header,.product-row{\r
    display:grid;\r
    grid-template-columns:2fr 1fr 1fr 1.2fr 1fr 1fr .8fr;\r
    align-items:center;column-gap:18px;min-width:900px\r
}\r
.product-header{padding:0 3px 16px;font-size:15px;font-weight:700}\r
.product-row{min-height:82px;border-top:1px solid #eee;font-size:14px}\r
.product-info{display:flex;align-items:center;gap:12px}\r
.product-image{\r
    width:48px;height:48px;border-radius:8px;background:#e8f5eb;\r
    display:flex;align-items:center;justify-content:center;\r
    color:#147a36;font-size:22px;font-weight:bold\r
}\r
.product-name{font-weight:700}\r
.product-category{color:#777;font-size:12px;margin-top:3px}\r
.price,.stock{font-weight:600}\r
.stock.low{color:#e49b00}\r
.stock.critical{color:#e33b3b}\r
.availability{\r
    display:inline-block;padding:6px 10px;border-radius:5px;\r
    font-size:12px;font-weight:600\r
}\r
.available{background:#bcebbf;color:#08a425}\r
.unavailable{background:#ffc5c5;color:#e33b3b}\r
\r
.product-form{\r
    display:none;background:#f8faf8;border:1px solid #e2e8e3;\r
    border-radius:12px;padding:25px;margin-bottom:25px\r
}\r
.product-form.show{display:block}\r
.form-title{font-size:20px;color:#147a36;margin-bottom:20px;font-weight:600}\r
.form-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}\r
.form-group{display:flex;flex-direction:column}\r
.form-group label{font-size:13px;font-weight:600;margin-bottom:7px;color:#444}\r
.form-group input,.form-group select{\r
    width:100%;height:43px;padding:0 12px;border:1px solid #d7d7d7;\r
    border-radius:7px;outline:none;background:#fff;font-size:14px\r
}\r
.form-buttons{display:flex;justify-content:flex-end;gap:10px;margin-top:20px}\r
.cancel-form{background:#eee;border:none;padding:10px 18px;border-radius:6px;cursor:pointer}\r
.save-product,.save-btn{\r
    background:#08752f;color:#fff;border:none;padding:10px 18px;\r
    border-radius:6px;cursor:pointer\r
}\r
\r
.modal-bg{\r
    display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);\r
    justify-content:center;align-items:center;z-index:999;padding:20px\r
}\r
.modal{\r
    background:#fff;width:500px;max-width:100%;border-radius:12px;\r
    padding:28px;box-shadow:0 10px 40px rgba(0,0,0,.2)\r
}\r
.modal h2{color:#147a36;margin-bottom:22px}\r
.detail{margin-bottom:15px}\r
.detail label{display:block;color:#777;font-size:13px;margin-bottom:5px}\r
.detail strong{font-size:16px}\r
.status-select{\r
    width:100%;padding:11px;border:1px solid #ddd;\r
    border-radius:7px;font-size:15px;outline:none\r
}\r
.modal-buttons{display:flex;justify-content:flex-end;gap:10px;margin-top:25px}\r
.close-btn{background:#eee;border:none;padding:10px 18px;border-radius:6px;cursor:pointer}\r
\r
@media(max-width:1100px){\r
.sidebar{width:190px}\r
.main{margin-left:190px;padding:35px 25px}\r
.form-grid{grid-template-columns:repeat(2,1fr)}\r
}\r
@media(max-width:700px){\r
.sidebar{position:relative;width:100%;height:auto}\r
.menu{display:grid;grid-template-columns:repeat(2,1fr)}\r
.main{margin-left:0;padding:30px 18px}\r
.section-header{align-items:flex-start;flex-direction:column}\r
.form-grid{grid-template-columns:1fr}\r
.bottom{flex-direction:column;gap:20px;align-items:flex-start}\r
}\r
</style>\r
</head>\r
\r
<body>\r
\r
<div class="sidebar">\r
    <div class="logo"><span style="color:white">E</span><span>LEE</span></div>\r
    <div class="hardware">HARDWARE</div>\r
\r
    <div class="menu">\r
        <a href="/"><span class="icon">☼</span><span>Dashboard</span></a>\r
        <a href="/orders" class="active"><span class="icon">▣</span><span>Orders</span></a>\r
        <a href="/products"><span class="icon">◇</span><span>Products</span></a>\r
        <a href="/ai-recommendations"><span class="icon">↗</span><span>AI Recommendations</span></a>\r
        <a href="/payments"><span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span><span>Payments</span></a>\r
        <a href="/customers"><span class="icon">♙</span><span>Customers</span></a>\r
        <a href="/queuing"><span class="icon">▱</span><span>Queuing</span></a>\r
        <a href="/receipt-records"><span class="icon">▤</span><span>Receipt Records</span></a>\r
        <a href="/settings"><span class="icon">⚙</span><span>Settings</span></a>\r
    </div>\r
</div>\r
\r
<div class="main">\r
\r
<div class="section-header">\r
    <div>\r
        <div class="section-title">Order Management</div>\r
        <div class="section-description">View customer orders and update order status</div>\r
    </div>\r
</div>\r
\r
<div class="tabs">\r
    <button class="tab active" data-status="All Orders">All Orders</button>\r
    <button class="tab" data-status="Pending">Pending</button>\r
    <button class="tab" data-status="Processing">Processing</button>\r
    <button class="tab" data-status="Ready for Delivery">Ready for Delivery</button>\r
    <button class="tab" data-status="Completed">Completed</button>\r
    <button class="tab" data-status="Cancelled">Cancelled</button>\r
</div>\r
\r
<div class="search-container" id="searchContainer">\r
    <div class="search-box">\r
        <span class="search-icon">⌕</span>\r
        <input type="text" id="searchInput" placeholder="Search order ID or customer...">\r
    </div>\r
</div>\r
\r
<div class="orders-table">\r
\r
    <div class="table-header">\r
        <div>Order ID</div>\r
        <div>Customer</div>\r
        <div>Status</div>\r
        <div>Total</div>\r
        <div>Date</div>\r
        <div>Actions</div>\r
    </div>\r
\r
    <div id="ordersList"></div>\r
\r
    <div class="no-results" id="noResults">\r
        No orders found.\r
    </div>\r
</div>\r
\r
<div class="bottom">\r
    <div id="orderCount">Showing 0 to 0 of 0 orders</div>\r
    <div class="pagination" id="pagination"></div>\r
</div>\r
\r
<div class="section-divider"></div>\r
\r
<div class="section-header">\r
    <div>\r
        <div class="section-title">Products & Inventory</div>\r
        <div class="section-description">\r
            Add, edit, and manage product information, prices, units, categories, availability, images, and stock quantities\r
        </div>\r
    </div>\r
\r
    <button class="add-btn" id="addProductButton" type="button">+ Add Product</button>\r
</div>\r
\r
<div class="product-form" id="productForm">\r
\r
    <div class="form-title">Add / Edit Product</div>\r
\r
    <div class="form-grid">\r
\r
        <div class="form-group">\r
            <label>Product Name</label>\r
            <input type="text" id="productName" placeholder="Enter product name">\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Price</label>\r
            <input type="number" id="productPrice" placeholder="Enter price">\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Unit</label>\r
            <select id="productUnit">\r
                <option value="pc">Piece (pc)</option>\r
                <option value="kg">Kilogram (kg)</option>\r
                <option value="bag">Bag</option>\r
                <option value="box">Box</option>\r
                <option value="meter">Meter</option>\r
            </select>\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Category</label>\r
            <select id="productCategory">\r
                <option value="Construction">Construction</option>\r
                <option value="Electrical">Electrical</option>\r
                <option value="Plumbing">Plumbing</option>\r
                <option value="Tools">Tools</option>\r
                <option value="Others">Others</option>\r
            </select>\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Stock Quantity</label>\r
            <input type="number" id="productStock" placeholder="Enter stock quantity">\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Availability</label>\r
            <select id="productAvailability">\r
                <option value="Available">Available</option>\r
                <option value="Unavailable">Unavailable</option>\r
            </select>\r
        </div>\r
\r
        <div class="form-group">\r
            <label>Product Image</label>\r
            <input type="file" id="productImage" accept="image/*">\r
        </div>\r
\r
    </div>\r
\r
    <div class="form-buttons">\r
        <button class="cancel-form" id="cancelProductButton" type="button">Cancel</button>\r
        <button class="save-product" id="productSaveButton" type="button">Save Product</button>\r
    </div>\r
</div>\r
\r
<div class="search-container">\r
    <div class="search-box">\r
        <span class="search-icon">⌕</span>\r
        <input type="text" id="productSearch" placeholder="Search product...">\r
    </div>\r
</div>\r
\r
<div class="products-table">\r
\r
    <div class="product-header">\r
        <div>Product</div>\r
        <div>Price</div>\r
        <div>Unit</div>\r
        <div>Category</div>\r
        <div>Stock</div>\r
        <div>Availability</div>\r
        <div>Actions</div>\r
    </div>\r
\r
    <div id="productsList"></div>\r
</div>\r
\r
</div>\r
\r
<!-- ORDER MODAL -->\r
\r
<div class="modal-bg" id="modalBg">\r
    <div class="modal">\r
\r
        <h2>Order Details</h2>\r
\r
        <div class="detail">\r
            <label>Order ID</label>\r
            <strong id="modalOrderId"></strong>\r
        </div>\r
\r
        <div class="detail">\r
            <label>Customer</label>\r
            <strong id="modalCustomer"></strong>\r
        </div>\r
\r
        <div class="detail">\r
            <label>Total</label>\r
            <strong id="modalTotal"></strong>\r
        </div>\r
\r
        <div class="detail">\r
            <label>Date</label>\r
            <strong id="modalDate"></strong>\r
        </div>\r
\r
        <div class="detail">\r
            <label>Order Status</label>\r
            <select id="statusSelect" class="status-select">\r
                <option value="Pending">Pending</option>\r
                <option value="Processing">Processing</option>\r
                <option value="Ready for Delivery">Ready for Delivery</option>\r
                <option value="Completed">Completed</option>\r
                <option value="Cancelled">Cancelled</option>\r
            </select>\r
        </div>\r
\r
        <div class="modal-buttons">\r
            <button class="close-btn" id="closeOrderButton" type="button">Close</button>\r
            <button class="save-btn" id="saveOrderStatusButton" type="button">Save Status</button>\r
        </div>\r
\r
    </div>\r
</div>\r
\r
\r
\r
</body>\r
</html>\r
`,nr=`<!DOCTYPE html>\r
<html lang="en">\r
\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
\r
    <title>Payments - ELEE Hardware</title>\r
\r
    <style>\r
\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
            font-family: Arial, Helvetica, sans-serif;\r
        }\r
\r
        body {\r
            background: #f5f7f6;\r
            min-height: 100vh;\r
        }\r
\r
        .dashboard {\r
            display: flex;\r
            min-height: 100vh;\r
            width: 100%;\r
        }\r
\r
\r
        /* =====================================================\r
           SIDEBAR\r
        ===================================================== */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            z-index: 1000;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
            color: white;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
\r
        /* =====================================================\r
           CONTENT\r
        ===================================================== */\r
\r
        .content {\r
            flex: 1;\r
            min-height: 100vh;\r
            background: #f8faf9;\r
            padding: 35px 40px;\r
            margin-left: 235px;\r
            overflow-x: hidden;\r
        }\r
\r
        .page-header {\r
            margin-bottom: 25px;\r
        }\r
\r
        .page-title {\r
            color: #0b5c25;\r
            font-size: 28px;\r
            font-weight: 700;\r
            margin-bottom: 5px;\r
        }\r
\r
        .page-subtitle {\r
            color: #929292;\r
            font-size: 14px;\r
        }\r
\r
\r
        /* =====================================================\r
           SUMMARY CARDS\r
        ===================================================== */\r
\r
        .summary {\r
            display: grid;\r
            grid-template-columns: repeat(4, 1fr);\r
            gap: 15px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .summary-card {\r
            background: white;\r
            border: 1px solid #e2e7e4;\r
            border-radius: 12px;\r
            padding: 17px;\r
            display: flex;\r
            align-items: center;\r
            gap: 13px;\r
        }\r
\r
        .summary-icon {\r
            width: 43px;\r
            height: 43px;\r
            border-radius: 10px;\r
            background: #e8f7ec;\r
            color: #19803c;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-size: 20px;\r
        }\r
\r
        .summary-info small {\r
            display: block;\r
            color: #999;\r
            font-size: 11px;\r
            margin-bottom: 4px;\r
        }\r
\r
        .summary-info strong {\r
            color: #222;\r
            font-size: 19px;\r
        }\r
\r
\r
        /* =====================================================\r
           FILTERS\r
        ===================================================== */\r
\r
        .filters {\r
            display: grid;\r
            grid-template-columns: 170px 1fr 220px;\r
            gap: 15px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .filter-wrapper {\r
            position: relative;\r
        }\r
\r
        .filter-box {\r
            width: 100%;\r
            height: 46px;\r
            border: 1px solid #dedede;\r
            border-radius: 7px;\r
            background: white;\r
            display: flex;\r
            align-items: center;\r
            justify-content: space-between;\r
            padding: 0 14px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            color: #333;\r
        }\r
\r
        .filter-box:hover {\r
            border-color: #239447;\r
        }\r
\r
        .filter-arrow {\r
            color: #555;\r
        }\r
\r
        .filter-dropdown {\r
            display: none;\r
            position: absolute;\r
            top: 52px;\r
            left: 0;\r
            width: 100%;\r
            background: white;\r
            border: 1px solid #dedede;\r
            border-radius: 7px;\r
            box-shadow: 0 5px 15px rgba(0,0,0,0.12);\r
            z-index: 1000;\r
            overflow: hidden;\r
        }\r
\r
        .filter-dropdown.show {\r
            display: block;\r
        }\r
\r
        .filter-dropdown button {\r
            width: 100%;\r
            padding: 11px 14px;\r
            border: none;\r
            background: white;\r
            text-align: left;\r
            cursor: pointer;\r
            font-size: 12px;\r
            color: #333;\r
        }\r
\r
        .filter-dropdown button:hover {\r
            background: #eaf8ed;\r
            color: #19803c;\r
        }\r
\r
\r
        /* =====================================================\r
           SEARCH\r
        ===================================================== */\r
\r
        .search-box {\r
            height: 46px;\r
            border: 1px solid #dedede;\r
            border-radius: 7px;\r
            background: white;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 14px;\r
            gap: 10px;\r
        }\r
\r
        .search-icon {\r
            font-size: 20px;\r
            color: #555;\r
        }\r
\r
        .search-box input {\r
            border: none;\r
            outline: none;\r
            width: 100%;\r
            font-size: 13px;\r
        }\r
\r
\r
        /* =====================================================\r
           DATE\r
        ===================================================== */\r
\r
        .date-box {\r
            height: 46px;\r
            border: 1px solid #dedede;\r
            border-radius: 7px;\r
            background: white;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 12px;\r
            gap: 8px;\r
        }\r
\r
        .calendar-icon {\r
            font-size: 17px;\r
        }\r
\r
        .date-box input {\r
            border: none;\r
            outline: none;\r
            width: 100%;\r
            font-size: 12px;\r
            background: transparent;\r
        }\r
\r
\r
        /* =====================================================\r
           PAYMENT TABLE\r
        ===================================================== */\r
\r
        .table-card {\r
            background: white;\r
            border: 1px solid #e2e7e4;\r
            border-radius: 12px;\r
            overflow: hidden;\r
        }\r
\r
        .table-wrapper {\r
            width: 100%;\r
            overflow-x: auto;\r
        }\r
\r
        table {\r
            width: 100%;\r
            min-width: 1100px;\r
            border-collapse: collapse;\r
        }\r
\r
        thead {\r
            background: #f8faf9;\r
        }\r
\r
        thead th {\r
            text-align: left;\r
            font-size: 12px;\r
            font-weight: 700;\r
            color: #444;\r
            padding: 16px 12px;\r
            border-bottom: 1px solid #e5e5e5;\r
            white-space: nowrap;\r
        }\r
\r
        tbody td {\r
            font-size: 12px;\r
            color: #222;\r
            padding: 16px 12px;\r
            border-bottom: 1px solid #f0f0f0;\r
            vertical-align: middle;\r
            white-space: nowrap;\r
        }\r
\r
        tbody tr:hover {\r
            background: #fbfdfb;\r
        }\r
\r
\r
        /* =====================================================\r
           PAYMENT METHOD\r
        ===================================================== */\r
\r
        .payment-method {\r
            display: inline-flex;\r
            align-items: center;\r
            gap: 6px;\r
            background: #f1f7f3;\r
            color: #167636;\r
            padding: 6px 9px;\r
            border-radius: 6px;\r
            font-size: 10px;\r
            font-weight: 600;\r
        }\r
\r
        .method-icon {\r
            font-size: 12px;\r
        }\r
\r
\r
        /* =====================================================\r
           STATUS\r
        ===================================================== */\r
\r
        .status {\r
            display: inline-flex;\r
            align-items: center;\r
            justify-content: center;\r
            min-width: 68px;\r
            height: 24px;\r
            padding: 0 9px;\r
            border-radius: 6px;\r
            font-size: 10px;\r
            font-weight: 700;\r
        }\r
\r
        .unpaid {\r
            background: #fff0bd;\r
            color: #966f00;\r
        }\r
\r
        .paid {\r
            background: #b8f2b9;\r
            color: #268238;\r
        }\r
\r
        .cancelled {\r
            background: #ffb6b6;\r
            color: #d83c3c;\r
        }\r
\r
\r
        /* =====================================================\r
           ACTION BUTTONS\r
        ===================================================== */\r
\r
        .actions {\r
            display: flex;\r
            gap: 6px;\r
            flex-wrap: wrap;\r
        }\r
\r
        .action-btn {\r
            border: none;\r
            border-radius: 6px;\r
            padding: 7px 9px;\r
            cursor: pointer;\r
            font-size: 10px;\r
            font-weight: 600;\r
            transition: 0.2s;\r
        }\r
\r
        .action-btn:hover {\r
            opacity: 0.8;\r
        }\r
\r
        .view-btn {\r
            background: #edf5ff;\r
            color: #2766a5;\r
        }\r
\r
        .pay-btn {\r
            background: #dff6e5;\r
            color: #16813a;\r
        }\r
\r
        .undo-btn {\r
            background: #fff0bd;\r
            color: #966f00;\r
        }\r
\r
        .cancel-btn {\r
            background: #ffe8e8;\r
            color: #c93434;\r
        }\r
\r
\r
        /* =====================================================\r
           EMPTY\r
        ===================================================== */\r
\r
        .no-results {\r
            display: none;\r
            text-align: center;\r
            padding: 45px;\r
            color: #999;\r
            font-size: 14px;\r
        }\r
\r
\r
        /* =====================================================\r
           BOTTOM\r
        ===================================================== */\r
\r
        .table-bottom {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            padding: 18px 20px;\r
            gap: 20px;\r
        }\r
\r
        .showing {\r
            color: #929292;\r
            font-size: 12px;\r
            font-weight: 600;\r
        }\r
\r
        .pagination {\r
            display: flex;\r
            align-items: center;\r
            gap: 7px;\r
        }\r
\r
        .page-number,\r
        .next {\r
            width: 28px;\r
            height: 28px;\r
            border: none;\r
            background: transparent;\r
            color: #777;\r
            border-radius: 5px;\r
            cursor: pointer;\r
            font-size: 12px;\r
        }\r
\r
        .page-number:hover,\r
        .next:hover {\r
            background: #eaf8ed;\r
            color: #19803c;\r
        }\r
\r
        .page-number.active {\r
            background: #239447;\r
            color: white;\r
        }\r
\r
        .next:disabled {\r
            color: #ccc;\r
            cursor: not-allowed;\r
            background: transparent;\r
        }\r
\r
        .page-dots {\r
            color: #777;\r
            font-size: 12px;\r
            padding: 0 2px;\r
        }\r
\r
\r
        /* =====================================================\r
           MODAL\r
        ===================================================== */\r
\r
        .modal {\r
            display: none;\r
            position: fixed;\r
            inset: 0;\r
            background: rgba(0,0,0,0.55);\r
            align-items: center;\r
            justify-content: center;\r
            z-index: 9999;\r
            padding: 20px;\r
        }\r
\r
        .modal.show {\r
            display: flex;\r
        }\r
\r
        .modal-content {\r
            width: 470px;\r
            max-width: 100%;\r
            max-height: 90vh;\r
            overflow-y: auto;\r
            background: white;\r
            border-radius: 15px;\r
            padding: 25px;\r
            position: relative;\r
        }\r
\r
        .close-modal {\r
            position: absolute;\r
            right: 15px;\r
            top: 10px;\r
            border: none;\r
            background: transparent;\r
            font-size: 25px;\r
            color: #555;\r
            cursor: pointer;\r
        }\r
\r
        .modal-title {\r
            color: #19803c;\r
            font-size: 21px;\r
            margin-bottom: 5px;\r
        }\r
\r
        .modal-subtitle {\r
            color: #999;\r
            font-size: 12px;\r
            margin-bottom: 20px;\r
        }\r
\r
\r
        /* =====================================================\r
           RECEIPT\r
        ===================================================== */\r
\r
        .receipt {\r
            border: 1px solid #ddd;\r
            border-radius: 10px;\r
            padding: 20px;\r
            background: white;\r
        }\r
\r
        .receipt-header {\r
            text-align: center;\r
            border-bottom: 1px dashed #bbb;\r
            padding-bottom: 15px;\r
            margin-bottom: 15px;\r
        }\r
\r
        .receipt-logo {\r
            color: #00551b;\r
            font-size: 25px;\r
            font-weight: 900;\r
        }\r
\r
        .receipt-logo span {\r
            color: #ffc400;\r
        }\r
\r
        .receipt-title {\r
            color: #777;\r
            font-size: 12px;\r
            margin-top: 4px;\r
        }\r
\r
        .receipt-row {\r
            display: flex;\r
            justify-content: space-between;\r
            gap: 15px;\r
            padding: 7px 0;\r
            font-size: 12px;\r
        }\r
\r
        .receipt-row span:first-child {\r
            color: #888;\r
        }\r
\r
        .receipt-row span:last-child {\r
            color: #222;\r
            font-weight: 600;\r
            text-align: right;\r
        }\r
\r
        .receipt-total {\r
            border-top: 1px dashed #bbb;\r
            margin-top: 10px;\r
            padding-top: 12px;\r
        }\r
\r
        .receipt-total span:last-child {\r
            color: #19803c;\r
            font-size: 17px;\r
        }\r
\r
        .receipt-note {\r
            margin-top: 15px;\r
            background: #eaf8ed;\r
            padding: 10px;\r
            border-radius: 7px;\r
            text-align: center;\r
            color: #19803c;\r
            font-size: 11px;\r
            font-weight: 600;\r
        }\r
\r
        .modal-actions {\r
            display: flex;\r
            gap: 10px;\r
            margin-top: 18px;\r
        }\r
\r
        .modal-btn {\r
            flex: 1;\r
            height: 40px;\r
            border: none;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 12px;\r
            font-weight: 600;\r
        }\r
\r
        .modal-green {\r
            background: #069b45;\r
            color: white;\r
        }\r
\r
        .modal-gray {\r
            background: #eeeeee;\r
            color: #555;\r
        }\r
\r
\r
        /* =====================================================\r
           PAYMENT FLOW\r
        ===================================================== */\r
\r
        .flow-box {\r
            margin-top: 18px;\r
            background: #f7faf8;\r
            border: 1px solid #e5ebe7;\r
            border-radius: 10px;\r
            padding: 15px;\r
        }\r
\r
        .flow-title {\r
            color: #19803c;\r
            font-size: 13px;\r
            font-weight: 700;\r
            margin-bottom: 12px;\r
        }\r
\r
        .flow-step {\r
            display: flex;\r
            align-items: center;\r
            gap: 10px;\r
            margin-bottom: 8px;\r
            font-size: 11px;\r
            color: #555;\r
        }\r
\r
        .flow-number {\r
            width: 22px;\r
            height: 22px;\r
            border-radius: 50%;\r
            background: #dff4e5;\r
            color: #19803c;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-weight: bold;\r
            flex-shrink: 0;\r
        }\r
\r
\r
        /* =====================================================\r
           PRINT\r
        ===================================================== */\r
\r
        @media print {\r
\r
            body * {\r
                visibility: hidden;\r
            }\r
\r
            #receiptModal,\r
            #receiptModal * {\r
                visibility: visible;\r
            }\r
\r
            #receiptModal {\r
                position: absolute;\r
                left: 0;\r
                top: 0;\r
                width: 100%;\r
                background: white;\r
            }\r
\r
            .close-modal,\r
            .modal-actions {\r
                display: none !important;\r
            }\r
\r
            .modal-content {\r
                box-shadow: none;\r
                width: 100%;\r
            }\r
\r
        }\r
\r
\r
        /* =====================================================\r
           RESPONSIVE\r
        ===================================================== */\r
\r
        @media (max-width: 1100px) {\r
\r
            .content {\r
                padding: 30px;\r
            }\r
\r
            .summary {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
            .filters {\r
                grid-template-columns: 1fr 1fr;\r
            }\r
\r
            .date-box {\r
                grid-column: 1 / 3;\r
            }\r
\r
        }\r
\r
\r
        @media (max-width: 800px) {\r
\r
            .dashboard {\r
                flex-direction: column;\r
            }\r
\r
            .sidebar {\r
                position: relative;\r
                width: 100%;\r
                height: auto;\r
                min-height: auto;\r
            }\r
\r
            .content {\r
                margin-left: 0;\r
                padding: 25px 20px;\r
            }\r
\r
            .menu {\r
                display: grid;\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
            .summary {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .filters {\r
                display: flex;\r
                flex-direction: column;\r
            }\r
\r
            .date-box {\r
                width: 100%;\r
            }\r
\r
            .table-bottom {\r
                flex-direction: column;\r
                align-items: flex-start;\r
            }\r
\r
        }\r
\r
    </style>\r
</head>\r
\r
\r
<body>\r
\r
<div class="dashboard">\r
\r
\r
    <!-- =====================================================\r
         SIDEBAR\r
    ===================================================== -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <nav class="menu">\r
\r
            <a href="{{ url('/dashboard') }}">\r
                <span class="icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}">\r
                <span class="icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}">\r
                <span class="icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}" class="active">\r
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}">\r
                <span class="icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}">\r
                <span class="icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </nav>\r
\r
    </aside>\r
\r
\r
\r
    <!-- =====================================================\r
         MAIN CONTENT\r
    ===================================================== -->\r
\r
    <main class="content">\r
\r
\r
        <div class="page-header">\r
\r
            <h1 class="page-title">\r
                Payments\r
            </h1>\r
\r
            <p class="page-subtitle">\r
                Manage customer payments and payment status\r
            </p>\r
\r
        </div>\r
\r
\r
\r
        <!-- =====================================================\r
             SUMMARY\r
        ===================================================== -->\r
\r
        <div class="summary">\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ₱\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Total Payments</small>\r
                    <strong id="totalPayments">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    ✓\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Paid</small>\r
                    <strong id="paidCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    !\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Unpaid</small>\r
                    <strong id="unpaidCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="summary-card">\r
\r
                <div class="summary-icon">\r
                    #\r
                </div>\r
\r
                <div class="summary-info">\r
                    <small>Cancelled</small>\r
                    <strong id="cancelledCount">0</strong>\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
\r
        <!-- =====================================================\r
             FILTERS\r
        ===================================================== -->\r
\r
        <div class="filters">\r
\r
\r
            <!-- STATUS FILTER -->\r
\r
            <div class="filter-wrapper">\r
\r
                <button\r
                    type="button"\r
                    class="filter-box"\r
                    onclick="toggleFilter()"\r
                >\r
\r
                    <span id="filterText">\r
                        All Payments\r
                    </span>\r
\r
                    <span class="filter-arrow">\r
                        ▾\r
                    </span>\r
\r
                </button>\r
\r
\r
                <div\r
                    class="filter-dropdown"\r
                    id="filterDropdown"\r
                >\r
\r
                    <button\r
                        type="button"\r
                        onclick="filterPayments('all')"\r
                    >\r
                        All Payments\r
                    </button>\r
\r
                    <button\r
                        type="button"\r
                        onclick="filterPayments('unpaid')"\r
                    >\r
                        Unpaid\r
                    </button>\r
\r
                    <button\r
                        type="button"\r
                        onclick="filterPayments('paid')"\r
                    >\r
                        Paid\r
                    </button>\r
\r
                    <button\r
                        type="button"\r
                        onclick="filterPayments('cancelled')"\r
                    >\r
                        Cancelled\r
                    </button>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
\r
            <!-- SEARCH -->\r
\r
            <div class="search-box">\r
\r
                <span class="search-icon">\r
                    ⌕\r
                </span>\r
\r
                <input\r
                    type="text"\r
                    id="searchInput"\r
                    placeholder="Search payment ID, order ID, customer..."\r
                    oninput="applyFilters()"\r
                >\r
\r
            </div>\r
\r
\r
\r
            <!-- DATE -->\r
\r
            <div class="date-box">\r
\r
                <span class="calendar-icon">\r
                    ▣\r
                </span>\r
\r
                <input\r
                    type="date"\r
                    id="dateFilter"\r
                    onchange="applyFilters()"\r
                >\r
\r
            </div>\r
\r
        </div>\r
\r
\r
\r
        <!-- =====================================================\r
             TABLE\r
        ===================================================== -->\r
\r
        <div class="table-card">\r
\r
            <div class="table-wrapper">\r
\r
                <table id="paymentTable">\r
\r
                    <thead>\r
\r
                        <tr>\r
\r
                            <th>Payment ID</th>\r
\r
                            <th>Order ID</th>\r
\r
                            <th>Customer</th>\r
\r
                            <th>Amount</th>\r
\r
                            <th>Payment Method</th>\r
\r
                            <th>Status</th>\r
\r
                            <th>Date</th>\r
\r
                            <th>Actions</th>\r
\r
                        </tr>\r
\r
                    </thead>\r
\r
\r
                    <tbody id="paymentBody"></tbody>\r
\r
                </table>\r
\r
\r
                <div\r
                    class="no-results"\r
                    id="noResults"\r
                >\r
                    No payments found.\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- TABLE BOTTOM -->\r
\r
            <div class="table-bottom">\r
\r
                <div\r
                    class="showing"\r
                    id="showingText"\r
                >\r
                    Showing 0 payments\r
                </div>\r
\r
\r
                <div\r
                    class="pagination"\r
                    id="pagination"\r
                >\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
\r
<!-- =====================================================\r
     PAYMENT DETAILS MODAL\r
===================================================== -->\r
\r
<div\r
    class="modal"\r
    id="paymentModal"\r
>\r
\r
    <div class="modal-content">\r
\r
        <button\r
            class="close-modal"\r
            onclick="closePaymentModal()"\r
        >\r
            ×\r
        </button>\r
\r
\r
        <h2 class="modal-title">\r
            Payment Details\r
        </h2>\r
\r
        <p class="modal-subtitle">\r
            Review the customer's payment information.\r
        </p>\r
\r
\r
        <div class="receipt">\r
\r
            <div class="receipt-header">\r
\r
                <div class="receipt-logo">\r
                    EL<span>EE</span>\r
                </div>\r
\r
                <div class="receipt-title">\r
                    HARDWARE\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="receipt-row">\r
                <span>Payment ID</span>\r
                <span id="detailPaymentId">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Order ID</span>\r
                <span id="detailOrderId">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Customer</span>\r
                <span id="detailCustomer">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Amount</span>\r
                <span id="detailAmount">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Payment Method</span>\r
                <span id="detailMethod">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Status</span>\r
                <span id="detailStatus">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Date</span>\r
                <span id="detailDate">-</span>\r
            </div>\r
\r
\r
            <div\r
                class="flow-box"\r
                id="flowBox"\r
            >\r
\r
                <div class="flow-title">\r
                    Payment Flow\r
                </div>\r
\r
                <div id="flowContent">\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="modal-actions">\r
\r
            <button\r
                class="modal-btn modal-gray"\r
                onclick="closePaymentModal()"\r
            >\r
                Close\r
            </button>\r
\r
            <button\r
                class="modal-btn modal-green"\r
                id="modalPayButton"\r
                onclick="markModalPaymentPaid()"\r
            >\r
                Mark as Paid\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
<!-- =====================================================\r
     PAID RECEIPT MODAL\r
===================================================== -->\r
\r
<div\r
    class="modal"\r
    id="receiptModal"\r
>\r
\r
    <div class="modal-content">\r
\r
        <button\r
            class="close-modal"\r
            onclick="closeReceiptModal()"\r
        >\r
            ×\r
        </button>\r
\r
\r
        <h2 class="modal-title">\r
            Paid Receipt\r
        </h2>\r
\r
        <p class="modal-subtitle">\r
            Physical receipt record\r
        </p>\r
\r
\r
        <div class="receipt">\r
\r
            <div class="receipt-header">\r
\r
                <div class="receipt-logo">\r
                    EL<span>EE</span>\r
                </div>\r
\r
                <div class="receipt-title">\r
                    HARDWARE\r
                </div>\r
\r
                <div\r
                    style="\r
                        color:#19803c;\r
                        font-size:12px;\r
                        font-weight:bold;\r
                        margin-top:8px;\r
                    "\r
                >\r
                    PAID RECEIPT\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="receipt-row">\r
                <span>Payment ID</span>\r
                <span id="receiptPaymentId">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Order ID</span>\r
                <span id="receiptOrderId">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Customer</span>\r
                <span id="receiptCustomer">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Payment Method</span>\r
                <span id="receiptMethod">-</span>\r
            </div>\r
\r
            <div class="receipt-row receipt-total">\r
                <span>Total Paid</span>\r
                <span id="receiptAmount">-</span>\r
            </div>\r
\r
            <div class="receipt-row">\r
                <span>Date Paid</span>\r
                <span id="receiptDate">-</span>\r
            </div>\r
\r
\r
            <div class="receipt-note">\r
                Payment received successfully.\r
                Thank you for shopping at ELEE Hardware.\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="modal-actions">\r
\r
            <button\r
                class="modal-btn modal-gray"\r
                onclick="closeReceiptModal()"\r
            >\r
                Close\r
            </button>\r
\r
            <button\r
                class="modal-btn modal-green"\r
                onclick="window.print()"\r
            >\r
                Print Receipt\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
\r
</body>\r
</html>`,rr=`<!DOCTYPE html>\r
<html lang="en">\r
\r
<head>\r
\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
\r
    <title>EleeSiWeb - Products</title>\r
\r
    <style>\r
\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
            font-family: Arial, Helvetica, sans-serif;\r
        }\r
\r
        body {\r
            background: #fff;\r
            color: #111;\r
        }\r
\r
        .layout {\r
            display: flex;\r
            min-height: 100vh;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            z-index: 100;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
            cursor: pointer;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= MAIN ================= */\r
\r
        .main {\r
            flex: 1;\r
            min-width: 0;\r
            margin-left: 235px;\r
        }\r
\r
        .content {\r
            padding: 28px 25px;\r
        }\r
\r
        .header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: flex-start;\r
        }\r
\r
        .title {\r
            font-size: 30px;\r
            font-weight: 700;\r
            margin-bottom: 3px;\r
        }\r
\r
        .subtitle {\r
            color: #888;\r
            font-size: 14px;\r
        }\r
\r
        .add-btn {\r
            border: none;\r
            background: #069b45;\r
            color: white;\r
            padding: 10px 16px;\r
            border-radius: 9px;\r
            font-size: 13px;\r
            cursor: pointer;\r
        }\r
\r
        .add-btn:hover {\r
            background: #057d38;\r
        }\r
\r
        /* ================= INVENTORY SUMMARY ================= */\r
\r
        .inventory-summary {\r
            display: grid;\r
            grid-template-columns: repeat(4, 1fr);\r
            gap: 15px;\r
            margin-top: 30px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .summary-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 10px;\r
            padding: 18px;\r
            background: white;\r
        }\r
\r
        .summary-title {\r
            font-size: 12px;\r
            color: #888;\r
            margin-bottom: 8px;\r
        }\r
\r
        .summary-number {\r
            font-size: 25px;\r
            font-weight: 700;\r
        }\r
\r
        .summary-green {\r
            color: #069b45;\r
        }\r
\r
        .summary-yellow {\r
            color: #c58a00;\r
        }\r
\r
        .summary-red {\r
            color: #d84848;\r
        }\r
\r
        /* ================= SEARCH ================= */\r
\r
        .search-area {\r
            margin-top: 15px;\r
            margin-bottom: 28px;\r
        }\r
\r
        .search-box {\r
            width: 100%;\r
            height: 48px;\r
            border: 1px solid #ddd;\r
            border-radius: 9px;\r
            display: flex;\r
            align-items: center;\r
        }\r
\r
        .search-icon {\r
            font-size: 27px;\r
            color: #999;\r
            margin-left: 12px;\r
            margin-right: 12px;\r
        }\r
\r
        .search-box input {\r
            width: 100%;\r
            border: none;\r
            outline: none;\r
            font-size: 14px;\r
        }\r
\r
        .filter-area {\r
            display: flex;\r
            justify-content: flex-end;\r
            gap: 10px;\r
            margin-top: 15px;\r
        }\r
\r
        .filter-area select {\r
            border: 1px solid #ddd;\r
            border-radius: 7px;\r
            padding: 8px 12px;\r
            color: #666;\r
            outline: none;\r
            background: white;\r
        }\r
\r
        /* ================= PRODUCT TABLE ================= */\r
\r
        .product-table {\r
            width: 100%;\r
            overflow-x: auto;\r
        }\r
\r
        .product-header,\r
        .product-row {\r
            display: grid;\r
\r
            grid-template-columns:\r
                80px\r
                1.4fr\r
                1.1fr\r
                .7fr\r
                .7fr\r
                .7fr\r
                .8fr\r
                85px;\r
\r
            align-items: center;\r
            column-gap: 15px;\r
            min-width: 900px;\r
        }\r
\r
        .product-header {\r
            font-weight: 700;\r
            font-size: 13px;\r
            padding: 0 10px 16px;\r
        }\r
\r
        .product-row {\r
            min-height: 83px;\r
            border: 1px solid #e5e5e5;\r
            border-radius: 9px;\r
            padding: 10px;\r
            margin-bottom: 14px;\r
            background: white;\r
        }\r
\r
        .product-row:hover {\r
            border-color: #b9dfc5;\r
            box-shadow: 0 2px 8px rgba(0,0,0,.04);\r
        }\r
\r
        /* ================= IMAGE ================= */\r
\r
        .product-image-box {\r
            width: 60px;\r
            height: 55px;\r
            border: 1px solid #e5e5e5;\r
            border-radius: 7px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            overflow: hidden;\r
            background: #fafafa;\r
        }\r
\r
        .product-image {\r
            width: 100%;\r
            height: 100%;\r
            object-fit: contain;\r
        }\r
\r
        .image-placeholder {\r
            font-size: 27px;\r
        }\r
\r
        .product-name {\r
            font-size: 14px;\r
            font-weight: 600;\r
        }\r
\r
        .category {\r
            font-size: 12px;\r
            color: #888;\r
        }\r
\r
        .price,\r
        .stock,\r
        .unit {\r
            font-size: 12px;\r
            font-weight: 600;\r
        }\r
\r
        /* ================= STATUS ================= */\r
\r
        .status {\r
            display: inline-block;\r
            padding: 5px 9px;\r
            border-radius: 5px;\r
            font-size: 10px;\r
            font-weight: 600;\r
        }\r
\r
        .in-stock {\r
            background: #c9f1ce;\r
            color: #258b3e;\r
        }\r
\r
        .low-stock {\r
            background: #fff0c2;\r
            color: #a87500;\r
        }\r
\r
        .out-stock {\r
            background: #ffd6d6;\r
            color: #c53b3b;\r
        }\r
\r
        .unavailable {\r
            background: #eeeeee;\r
            color: #777;\r
        }\r
\r
        /* ================= ACTIONS ================= */\r
\r
        .actions {\r
            display: flex;\r
            gap: 7px;\r
        }\r
\r
        .edit,\r
        .stock-btn,\r
        .delete {\r
            width: 30px;\r
            height: 30px;\r
            border: none;\r
            background: none;\r
            border-radius: 6px;\r
            cursor: pointer;\r
            font-size: 16px;\r
        }\r
\r
        .edit {\r
            color: #777;\r
        }\r
\r
        .edit:hover {\r
            background: #eeeeee;\r
        }\r
\r
        .stock-btn {\r
            color: #069b45;\r
        }\r
\r
        .stock-btn:hover {\r
            background: #e4f5e9;\r
        }\r
\r
        .delete {\r
            color: #e75b5b;\r
        }\r
\r
        .delete:hover {\r
            background: #ffe7e7;\r
        }\r
\r
        /* ================= NO RESULTS ================= */\r
\r
        .no-results {\r
            display: none;\r
            text-align: center;\r
            padding: 35px;\r
            color: #888;\r
            font-size: 14px;\r
            border: 1px solid #eee;\r
            border-radius: 9px;\r
            min-width: 900px;\r
        }\r
\r
        /* ================= STOCK NOTICE ================= */\r
\r
        .stock-notice {\r
            display: flex;\r
            align-items: center;\r
            gap: 10px;\r
            background: #f4faf5;\r
            border: 1px solid #d6eadb;\r
            border-radius: 9px;\r
            padding: 13px 15px;\r
            margin-top: 30px;\r
            color: #397049;\r
            font-size: 12px;\r
        }\r
\r
        .stock-notice strong {\r
            color: #17612d;\r
        }\r
\r
        /* ================= PAGINATION ================= */\r
\r
        .bottom {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            margin-top: 35px;\r
            padding: 0 10px;\r
            gap: 15px;\r
        }\r
\r
        .showing-text {\r
            font-size: 12px;\r
            color: #777;\r
        }\r
\r
        .pagination {\r
            display: flex;\r
            align-items: center;\r
            gap: 6px;\r
        }\r
\r
        .page {\r
            min-width: 30px;\r
            height: 30px;\r
            padding: 0 8px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            border: 1px solid #ddd;\r
            border-radius: 6px;\r
            font-size: 12px;\r
            color: #555;\r
            cursor: pointer;\r
            background: white;\r
            user-select: none;\r
        }\r
\r
        .page:hover:not(.disabled):not(.dots) {\r
            border-color: #299447;\r
            color: #299447;\r
        }\r
\r
        .page.active {\r
            background: #299447;\r
            color: white;\r
            border-color: #299447;\r
        }\r
\r
        .page.disabled {\r
            color: #ccc;\r
            cursor: not-allowed;\r
            background: #f8f8f8;\r
        }\r
\r
        .page.dots {\r
            border: none;\r
            cursor: default;\r
            background: transparent;\r
        }\r
\r
        /* ================= MODAL ================= */\r
\r
        .modal {\r
            display: none;\r
            position: fixed;\r
            inset: 0;\r
            background: rgba(0,0,0,.45);\r
            align-items: center;\r
            justify-content: center;\r
            z-index: 1000;\r
            padding: 20px;\r
        }\r
\r
        .modal-box {\r
            background: white;\r
            width: 470px;\r
            max-width: 100%;\r
            max-height: 92vh;\r
            overflow-y: auto;\r
            border-radius: 12px;\r
            padding: 25px;\r
        }\r
\r
        .modal-box h2 {\r
            margin-bottom: 20px;\r
            font-size: 22px;\r
        }\r
\r
        .form-group {\r
            margin-bottom: 15px;\r
        }\r
\r
        .form-group label {\r
            display: block;\r
            font-size: 13px;\r
            font-weight: 600;\r
            margin-bottom: 6px;\r
        }\r
\r
        .form-group input,\r
        .form-group select {\r
            width: 100%;\r
            padding: 10px;\r
            border: 1px solid #ddd;\r
            border-radius: 7px;\r
            outline: none;\r
            background: white;\r
        }\r
\r
        .form-group input:focus,\r
        .form-group select:focus {\r
            border-color: #069b45;\r
        }\r
\r
        /* ================= IMAGE UPLOAD ================= */\r
\r
        .image-upload-area {\r
            border: 2px dashed #cfcfcf;\r
            border-radius: 9px;\r
            padding: 15px;\r
            text-align: center;\r
            background: #fafafa;\r
        }\r
\r
        .image-upload-area:hover {\r
            border-color: #069b45;\r
        }\r
\r
        .image-upload-area input[type="file"] {\r
            border: none;\r
            padding: 0;\r
            cursor: pointer;\r
        }\r
\r
        .image-preview {\r
            width: 120px;\r
            height: 100px;\r
            object-fit: contain;\r
            border: 1px solid #ddd;\r
            border-radius: 8px;\r
            margin: 10px auto;\r
            display: none;\r
            background: white;\r
        }\r
\r
        .upload-text {\r
            color: #888;\r
            font-size: 12px;\r
            margin-top: 5px;\r
        }\r
\r
        /* ================= AVAILABILITY ================= */\r
\r
        .availability-box {\r
            display: flex;\r
            align-items: center;\r
            gap: 8px;\r
        }\r
\r
        .availability-box input {\r
            width: auto;\r
        }\r
\r
        /* ================= MODAL BUTTONS ================= */\r
\r
        .modal-buttons {\r
            display: flex;\r
            justify-content: flex-end;\r
            gap: 10px;\r
            margin-top: 20px;\r
        }\r
\r
        .cancel-btn {\r
            border: 1px solid #ccc;\r
            background: white;\r
            padding: 9px 15px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
        }\r
\r
        .save-btn {\r
            border: none;\r
            background: #069b45;\r
            color: white;\r
            padding: 9px 15px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
        }\r
\r
        .save-btn:hover {\r
            background: #057d38;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media (max-width: 1000px) {\r
\r
            .sidebar {\r
                width: 190px;\r
            }\r
\r
            .main {\r
                margin-left: 190px;\r
            }\r
\r
            .inventory-summary {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
        }\r
\r
        @media (max-width: 650px) {\r
\r
            .sidebar {\r
                display: none;\r
            }\r
\r
            .main {\r
                margin-left: 0;\r
            }\r
\r
            .content {\r
                padding: 18px;\r
            }\r
\r
            .header {\r
                align-items: center;\r
            }\r
\r
            .title {\r
                font-size: 25px;\r
            }\r
\r
            .add-btn {\r
                padding: 8px 12px;\r
            }\r
\r
            .inventory-summary {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .bottom {\r
                flex-direction: column;\r
                align-items: flex-start;\r
            }\r
\r
        }\r
\r
    </style>\r
\r
</head>\r
\r
\r
<body>\r
\r
\r
<div class="layout">\r
\r
\r
    <!-- ================= SIDEBAR ================= -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <div class="menu">\r
\r
            <a href="{{ url('/') }}">\r
                <span class="icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}" class="active">\r
                <span class="icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}">\r
                <span class="icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}">\r
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}">\r
                <span class="icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}">\r
                <span class="icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </div>\r
\r
    </aside>\r
\r
\r
    <!-- ================= MAIN ================= -->\r
\r
    <main class="main">\r
\r
        <div class="content">\r
\r
\r
            <!-- HEADER -->\r
\r
            <div class="header">\r
\r
                <div>\r
\r
                    <h1 class="title">\r
                        Products & Inventory\r
                    </h1>\r
\r
                    <p class="subtitle">\r
                        Manage products, prices, availability and stock\r
                    </p>\r
\r
                </div>\r
\r
                <button\r
                    class="add-btn"\r
                    onclick="openAddModal()"\r
                >\r
                    + Add Product\r
                </button>\r
\r
            </div>\r
\r
\r
            <!-- ================= INVENTORY SUMMARY ================= -->\r
\r
            <div class="inventory-summary">\r
\r
                <div class="summary-card">\r
\r
                    <div class="summary-title">\r
                        Total Products\r
                    </div>\r
\r
                    <div\r
                        class="summary-number summary-green"\r
                        id="totalProducts"\r
                    >\r
                        0\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="summary-card">\r
\r
                    <div class="summary-title">\r
                        In Stock\r
                    </div>\r
\r
                    <div\r
                        class="summary-number summary-green"\r
                        id="inStockCount"\r
                    >\r
                        0\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="summary-card">\r
\r
                    <div class="summary-title">\r
                        Low Stock\r
                    </div>\r
\r
                    <div\r
                        class="summary-number summary-yellow"\r
                        id="lowStockCount"\r
                    >\r
                        0\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="summary-card">\r
\r
                    <div class="summary-title">\r
                        Out of Stock\r
                    </div>\r
\r
                    <div\r
                        class="summary-number summary-red"\r
                        id="outStockCount"\r
                    >\r
                        0\r
                    </div>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- ================= SEARCH ================= -->\r
\r
            <div class="search-area">\r
\r
                <div class="search-box">\r
\r
                    <span class="search-icon">\r
                        ⌕\r
                    </span>\r
\r
                    <input\r
                        type="text"\r
                        id="searchInput"\r
                        placeholder="Search products..."\r
                        oninput="filterProducts()"\r
                    >\r
\r
                </div>\r
\r
\r
                <div class="filter-area">\r
\r
                    <select\r
                        id="categoryFilter"\r
                        onchange="filterProducts()"\r
                    >\r
\r
                        <option value="all">\r
                            All Categories\r
                        </option>\r
\r
                        <option value="Building Materials">\r
                            Building Materials\r
                        </option>\r
\r
                        <option value="Tools">\r
                            Tools\r
                        </option>\r
\r
                        <option value="Electrical">\r
                            Electrical\r
                        </option>\r
\r
                        <option value="Plumbing">\r
                            Plumbing\r
                        </option>\r
\r
                    </select>\r
\r
\r
                    <select\r
                        id="statusFilter"\r
                        onchange="filterProducts()"\r
                    >\r
\r
                        <option value="all">\r
                            All Status\r
                        </option>\r
\r
                        <option value="In Stock">\r
                            In Stock\r
                        </option>\r
\r
                        <option value="Low Stock">\r
                            Low Stock\r
                        </option>\r
\r
                        <option value="Out of Stock">\r
                            Out of Stock\r
                        </option>\r
\r
                        <option value="Unavailable">\r
                            Unavailable\r
                        </option>\r
\r
                    </select>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- ================= PRODUCT TABLE ================= -->\r
\r
            <div class="product-table">\r
\r
                <div class="product-header">\r
\r
                    <div>Image</div>\r
                    <div>Product Name</div>\r
                    <div>Category</div>\r
                    <div>Price</div>\r
                    <div>Stock</div>\r
                    <div>Unit</div>\r
                    <div>Status</div>\r
                    <div>Actions</div>\r
\r
                </div>\r
\r
\r
                <div id="productList"></div>\r
\r
\r
                <div\r
                    id="noResults"\r
                    class="no-results"\r
                >\r
                    No products found.\r
                </div>\r
\r
            </div>\r
\r
\r
            <!-- ================= AUTOMATIC STOCK NOTICE ================= -->\r
\r
            <div class="stock-notice">\r
\r
                <span>\r
                    📦\r
                </span>\r
\r
                <span>\r
                    <strong>Automatic Stock Update:</strong>\r
                    Stock is automatically deducted when an order is confirmed.\r
                    Staff can use the <strong>+</strong> button to add new stock\r
                    when supplies arrive.\r
                </span>\r
\r
            </div>\r
\r
\r
            <!-- ================= PAGINATION ================= -->\r
\r
            <div class="bottom">\r
\r
                <div\r
                    class="showing-text"\r
                    id="showingText"\r
                >\r
                    Showing 0 to 0 of 0 products\r
                </div>\r
\r
                <div\r
                    class="pagination"\r
                    id="pagination"\r
                ></div>\r
\r
            </div>\r
\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
<!-- ================================================= -->\r
<!-- ADD / EDIT PRODUCT MODAL -->\r
<!-- ================================================= -->\r
\r
<div\r
    class="modal"\r
    id="productModal"\r
>\r
\r
    <div class="modal-box">\r
\r
        <h2 id="modalTitle">\r
            Add Product\r
        </h2>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Product Image\r
            </label>\r
\r
            <div class="image-upload-area">\r
\r
                <img\r
                    id="imagePreview"\r
                    class="image-preview"\r
                    alt="Image Preview"\r
                >\r
\r
                <input\r
                    type="file"\r
                    id="productImage"\r
                    accept="image/*"\r
                    onchange="previewImage(event)"\r
                >\r
\r
                <div class="upload-text">\r
                    Choose a product picture\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Product Name\r
            </label>\r
\r
            <input\r
                type="text"\r
                id="productName"\r
                placeholder="Enter product name"\r
            >\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Category\r
            </label>\r
\r
            <select id="productCategory">\r
\r
                <option value="">\r
                    Select category\r
                </option>\r
\r
                <option value="Building Materials">\r
                    Building Materials\r
                </option>\r
\r
                <option value="Tools">\r
                    Tools\r
                </option>\r
\r
                <option value="Electrical">\r
                    Electrical\r
                </option>\r
\r
                <option value="Plumbing">\r
                    Plumbing\r
                </option>\r
\r
            </select>\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Price\r
            </label>\r
\r
            <input\r
                type="number"\r
                id="productPrice"\r
                min="0"\r
                step="0.01"\r
                placeholder="Enter price"\r
            >\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Unit\r
            </label>\r
\r
            <select id="productUnit">\r
\r
                <option value="">\r
                    Select unit\r
                </option>\r
\r
                <option value="piece">\r
                    Piece\r
                </option>\r
\r
                <option value="set">\r
                    Set\r
                </option>\r
\r
                <option value="box">\r
                    Box\r
                </option>\r
\r
                <option value="meter">\r
                    Meter\r
                </option>\r
\r
                <option value="kg">\r
                    Kilogram\r
                </option>\r
\r
                <option value="liter">\r
                    Liter\r
                </option>\r
\r
            </select>\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Stock Quantity\r
            </label>\r
\r
            <input\r
                type="number"\r
                id="productStock"\r
                min="0"\r
                placeholder="Enter stock quantity"\r
            >\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Availability\r
            </label>\r
\r
            <div class="availability-box">\r
\r
                <input\r
                    type="checkbox"\r
                    id="productAvailability"\r
                    checked\r
                >\r
\r
                <span>\r
                    Product is available for ordering\r
                </span>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="modal-buttons">\r
\r
            <button\r
                class="cancel-btn"\r
                onclick="closeModal()"\r
            >\r
                Cancel\r
            </button>\r
\r
            <button\r
                class="save-btn"\r
                onclick="saveProduct()"\r
                id="saveButton"\r
            >\r
                Add Product\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
<!-- ================================================= -->\r
<!-- ADD STOCK MODAL -->\r
<!-- ================================================= -->\r
\r
<div\r
    class="modal"\r
    id="stockModal"\r
>\r
\r
    <div class="modal-box">\r
\r
        <h2>\r
            Add New Stock\r
        </h2>\r
\r
\r
        <p\r
            id="stockProductName"\r
            style="\r
                font-size:13px;\r
                color:#777;\r
                margin-bottom:18px;\r
            "\r
        >\r
            Product\r
        </p>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Current Stock\r
            </label>\r
\r
            <input\r
                type="number"\r
                id="currentStock"\r
                readonly\r
            >\r
\r
        </div>\r
\r
\r
        <div class="form-group">\r
\r
            <label>\r
                Quantity to Add\r
            </label>\r
\r
            <input\r
                type="number"\r
                id="stockToAdd"\r
                min="1"\r
                placeholder="Enter quantity"\r
            >\r
\r
        </div>\r
\r
\r
        <div\r
            style="\r
                background:#f4faf5;\r
                border:1px solid #d6eadb;\r
                padding:12px;\r
                border-radius:7px;\r
                font-size:12px;\r
                color:#397049;\r
            "\r
        >\r
            New stock will be added to the existing quantity.\r
        </div>\r
\r
\r
        <div class="modal-buttons">\r
\r
            <button\r
                class="cancel-btn"\r
                onclick="closeStockModal()"\r
            >\r
                Cancel\r
            </button>\r
\r
            <button\r
                class="save-btn"\r
                onclick="addStock()"\r
            >\r
                Add Stock\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
</body>\r
\r
</html>`,er=`<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Queue - ELEE Hardware</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: Arial, Helvetica, sans-serif; }
        body { background: #f5f7f6; color: #17211b; }
        .sidebar { position: fixed; inset: 0 auto 0 0; width: 235px; background: #00551f; color: white; padding: 28px 16px; z-index: 10; }
        .logo { font-size: 36px; font-weight: 900; margin-left: 12px; letter-spacing: -2px; }
        .logo span { color: #ffbd00; }
        .hardware { color: #ffbd00; font-size: 14px; font-weight: bold; margin: 3px 0 25px 13px; }
        .menu { display: flex; flex-direction: column; gap: 7px; }
        .menu a { color: white; text-decoration: none; padding: 13px 14px; border-radius: 7px; font-size: 14px; display: flex; align-items: center; gap: 12px; }
        .menu a:hover, .menu a.active { background: #08732e; }
        .main { margin-left: 235px; padding: 42px; min-height: 100vh; }
        .section-header { display: flex; justify-content: space-between; align-items: center; gap: 20px; margin-bottom: 25px; }
        .section-title { color: #147a36; font-size: 27px; font-weight: 700; }
        .section-description { color: #748078; font-size: 14px; margin-top: 6px; }
        .orders-link { display: inline-flex; padding: 11px 16px; border-radius: 8px; background: #08752f; color: #fff; font-size: 14px; text-decoration: none; font-weight: 600; white-space: nowrap; }
        .summary { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; margin-bottom: 22px; }
        .summary-card { background: #fff; border: 1px solid #e7ece8; border-radius: 12px; padding: 18px 20px; box-shadow: 0 2px 8px #12301508; }
        .summary-label { color: #78827b; font-size: 13px; margin-bottom: 10px; }
        .summary-value { color: #075b27; font-size: 27px; font-weight: 700; }
        .queue-panel { background: #fff; border: 1px solid #e7ece8; border-radius: 12px; overflow: hidden; }
        .queue-toolbar { display: flex; justify-content: space-between; align-items: center; gap: 14px; padding: 18px 20px; border-bottom: 1px solid #edf0ed; }
        .queue-toolbar h2 { font-size: 17px; }
        .controls { display: flex; gap: 10px; }
        .controls input, .controls select { height: 40px; border: 1px solid #dce3dd; border-radius: 7px; padding: 0 11px; background: white; color: #26352b; font-size: 13px; }
        .controls input { width: 235px; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; min-width: 740px; border-collapse: collapse; text-align: left; }
        th { color: #718077; background: #fafcfb; font-size: 12px; font-weight: 600; padding: 14px 16px; white-space: nowrap; }
        td { padding: 16px; border-top: 1px solid #eff2ef; font-size: 13px; }
        .position { width: 52px; color: #13813c; font-size: 16px; font-weight: 700; }
        .order-id { color: #147a36; font-weight: 700; white-space: nowrap; }
        .customer-name { font-weight: 600; }
        .order-time { color: #718077; white-space: nowrap; }
        .status { display: inline-block; border-radius: 20px; padding: 6px 10px; background: #fff2cd; color: #896400; font-size: 11px; font-weight: 700; white-space: nowrap; }
        .status.processing { background: #e7efff; color: #345ca0; }
        .status.ready { background: #e2f5e8; color: #167338; }
        .status.completed { background: #e9eeee; color: #56625b; }
        .status.cancelled { background: #ffebeb; color: #af3838; }
        .total { font-weight: 700; white-space: nowrap; }
        .empty { display: none; padding: 48px 20px; color: #77827a; text-align: center; font-size: 14px; }
        .empty strong { display: block; color: #36463b; font-size: 16px; margin-bottom: 7px; }
        .queue-footer { padding: 14px 20px; border-top: 1px solid #edf0ed; color: #748078; font-size: 12px; }
        @media(max-width: 1050px) { .sidebar { width: 195px; } .main { margin-left: 195px; padding: 30px 24px; } .queue-toolbar { align-items: flex-start; flex-direction: column; } .controls { width: 100%; } .controls input { flex: 1; } }
        @media(max-width: 700px) { .sidebar { position: static; width: 100%; height: auto; } .menu { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); } .main { margin: 0; padding: 24px 16px; } .section-header { align-items: flex-start; flex-direction: column; } .summary { grid-template-columns: 1fr; gap: 10px; } .summary-card { padding: 15px 17px; } .summary-value { font-size: 23px; } .controls { flex-direction: column; } .controls input { width: 100%; flex: initial; } }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="logo"><span style="color:white">E</span><span>LEE</span></div>
        <div class="hardware">HARDWARE</div>
        <nav class="menu">
            <a href="/"><span class="icon">☼</span><span>Dashboard</span></a>
            <a href="/orders"><span class="icon">▣</span><span>Orders</span></a>
            <a href="/products"><span class="icon">◇</span><span>Products</span></a>
            <a href="/ai-recommendations"><span class="icon">↗</span><span>AI Recommendations</span></a>
            <a href="/payments"><span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span><span>Payments</span></a>
            <a href="/customers"><span class="icon">♙</span><span>Customers</span></a>
            <a href="/queuing" class="active"><span class="icon">☷</span><span>Queuing</span></a>
            <a href="/receipt-records"><span class="icon">▤</span><span>Receipt Records</span></a>
            <a href="/settings"><span class="icon">⚙</span><span>Settings</span></a>
        </nav>
    </aside>

    <main class="main">
        <header class="section-header">
            <div>
                <h1 class="section-title">Order Queue</h1>
                <p class="section-description">Orders are lined up by the time they were placed. Oldest orders are served first.</p>
            </div>
            <a class="orders-link" href="/orders">Manage orders</a>
        </header>

        <section class="summary" aria-label="Queue summary">
            <div class="summary-card"><div class="summary-label">Active orders in queue</div><div class="summary-value" id="activeCount">0</div></div>
            <div class="summary-card"><div class="summary-label">Waiting for processing</div><div class="summary-value" id="pendingCount">0</div></div>
            <div class="summary-card"><div class="summary-label">Next order</div><div class="summary-value" id="nextOrder" style="font-size:18px">—</div></div>
        </section>

        <section class="queue-panel">
            <div class="queue-toolbar">
                <h2>Customer order sequence</h2>
                <div class="controls">
                    <input id="queueSearch" type="search" placeholder="Search order or customer" oninput="renderQueue()" aria-label="Search queue">
                    <select id="statusFilter" onchange="renderQueue()" aria-label="Filter by order status">
                        <option value="active">Active orders</option>
                        <option value="all">All orders</option>
                        <option value="Pending">Pending</option>
                        <option value="Processing">Processing</option>
                        <option value="Ready for Delivery">Ready for Delivery</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                    <select id="sortBy" onchange="renderQueue()" aria-label="Sort queue">
                        <option value="oldest">Oldest order first (FIFO)</option>
                        <option value="newest">Newest order first</option>
                        <option value="customer">Customer A–Z</option>
                        <option value="amount">Highest amount</option>
                    </select>
                </div>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Queue</th><th>Order</th><th>Customer</th><th>Placed</th><th>Status</th><th>Total</th></tr></thead>
                    <tbody id="queueRows"></tbody>
                </table>
            </div>
            <div class="empty" id="queueEmpty"><strong>No orders in this view</strong>New customer orders will appear here in the order they are received.</div>
            <div class="queue-footer" id="queueFooter">Showing 0 orders</div>
        </section>
    </main>

    
</body>
</html>
`,tr=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
    <title>Receipt Records - ELEE Hardware</title>\r
\r
    <style>\r
        * {\r
            box-sizing: border-box;\r
            margin: 0;\r
            padding: 0;\r
            font-family: Arial, sans-serif;\r
        }\r
\r
        body {\r
            background: #f5f5f5;\r
            color: #222;\r
        }\r
\r
        .layout {\r
            display: flex;\r
            min-height: 100vh;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
            z-index: 100;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= MAIN ================= */\r
\r
        .main {\r
            flex: 1;\r
            background: white;\r
            padding: 40px 50px;\r
            min-width: 0;\r
            margin-left: 235px;\r
        }\r
\r
        .page-title {\r
            color: #075b21;\r
            font-size: 30px;\r
            font-weight: bold;\r
        }\r
\r
        .subtitle {\r
            color: #888;\r
            margin-top: 5px;\r
            margin-bottom: 28px;\r
        }\r
\r
        /* ================= SUMMARY ================= */\r
\r
        .summary {\r
            display: grid;\r
            grid-template-columns: repeat(4, 1fr);\r
            gap: 16px;\r
            margin-bottom: 28px;\r
        }\r
\r
        .summary-card {\r
            border: 1px solid #e5e5e5;\r
            border-radius: 10px;\r
            padding: 18px;\r
            background: white;\r
        }\r
\r
        .summary-card .label {\r
            color: #777;\r
            font-size: 13px;\r
            margin-bottom: 8px;\r
        }\r
\r
        .summary-card .number {\r
            font-size: 25px;\r
            font-weight: bold;\r
            color: #075b21;\r
        }\r
\r
        .summary-card.paid .number {\r
            color: #16853b;\r
        }\r
\r
        .summary-card.unpaid .number {\r
            color: #d88a00;\r
        }\r
\r
        /* ================= TOOLBAR ================= */\r
\r
        .toolbar {\r
            display: flex;\r
            gap: 15px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .search-box {\r
            flex: 1;\r
            height: 50px;\r
            border: 1px solid #ddd;\r
            border-radius: 9px;\r
            display: flex;\r
            align-items: center;\r
            padding: 0 16px;\r
        }\r
\r
        .search-box span {\r
            font-size: 24px;\r
            color: #666;\r
            margin-right: 12px;\r
        }\r
\r
        .search-box input {\r
            border: none;\r
            outline: none;\r
            width: 100%;\r
            font-size: 14px;\r
        }\r
\r
        .filter-box {\r
            height: 50px;\r
            min-width: 190px;\r
            border: 1px solid #ddd;\r
            border-radius: 9px;\r
            padding: 0 14px;\r
            outline: none;\r
            background: white;\r
            cursor: pointer;\r
            color: #444;\r
        }\r
\r
        /* ================= TABLE ================= */\r
\r
        .table-wrapper {\r
            width: 100%;\r
            overflow-x: auto;\r
        }\r
\r
        table {\r
            width: 100%;\r
            border-collapse: collapse;\r
            min-width: 800px;\r
        }\r
\r
        th {\r
            text-align: left;\r
            padding: 15px 12px;\r
            font-size: 13px;\r
            color: #333;\r
            background: #fafafa;\r
            border-bottom: 1px solid #ddd;\r
        }\r
\r
        td {\r
            padding: 16px 12px;\r
            border-bottom: 1px solid #eee;\r
            font-size: 13px;\r
        }\r
\r
        .order-id {\r
            color: #075b21;\r
            font-weight: bold;\r
        }\r
\r
        .amount {\r
            font-weight: bold;\r
        }\r
\r
        /* ================= STATUS ================= */\r
\r
        .status {\r
            display: inline-flex;\r
            align-items: center;\r
            gap: 6px;\r
            padding: 5px 10px;\r
            border-radius: 20px;\r
            font-size: 11px;\r
            font-weight: bold;\r
        }\r
\r
        .status.paid {\r
            background: #e5f7ea;\r
            color: #16853b;\r
        }\r
\r
        .status.unpaid {\r
            background: #fff3d6;\r
            color: #b87500;\r
        }\r
\r
        .status-dot {\r
            width: 6px;\r
            height: 6px;\r
            border-radius: 50%;\r
            background: currentColor;\r
        }\r
\r
        .payment-method {\r
            color: #555;\r
            font-size: 12px;\r
        }\r
\r
        /* ================= BUTTON ================= */\r
\r
        .view-btn {\r
            border: 1px solid #16a34a;\r
            color: #12813b;\r
            background: white;\r
            padding: 7px 17px;\r
            border-radius: 5px;\r
            cursor: pointer;\r
            font-size: 12px;\r
            transition: .2s;\r
        }\r
\r
        .view-btn:hover {\r
            background: #12813b;\r
            color: white;\r
        }\r
\r
        /* ================= EMPTY ================= */\r
\r
        .empty {\r
            text-align: center;\r
            padding: 50px;\r
            color: #999;\r
        }\r
\r
        /* ================= BOTTOM ================= */\r
\r
        .bottom {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: center;\r
            margin-top: 25px;\r
            color: #777;\r
            font-size: 13px;\r
        }\r
\r
        .pagination {\r
            display: flex;\r
            gap: 6px;\r
            align-items: center;\r
        }\r
\r
        .page {\r
            padding: 7px 11px;\r
            cursor: pointer;\r
            border-radius: 5px;\r
        }\r
\r
        .page:hover {\r
            background: #e8f5eb;\r
        }\r
\r
        .page.active {\r
            background: #239447;\r
            color: white;\r
        }\r
\r
        /* ================= MODAL ================= */\r
\r
        .modal-overlay {\r
            display: none;\r
            position: fixed;\r
            z-index: 999;\r
            inset: 0;\r
            background: rgba(0,0,0,.55);\r
            align-items: center;\r
            justify-content: center;\r
            padding: 20px;\r
        }\r
\r
        .modal-overlay.show {\r
            display: flex;\r
        }\r
\r
        .receipt-modal {\r
            background: white;\r
            width: 680px;\r
            max-width: 100%;\r
            max-height: 92vh;\r
            overflow-y: auto;\r
            border-radius: 10px;\r
            padding: 28px;\r
            box-shadow: 0 10px 40px rgba(0,0,0,.25);\r
        }\r
\r
        .modal-title {\r
            display: flex;\r
            align-items: center;\r
            gap: 10px;\r
            margin-bottom: 20px;\r
        }\r
\r
        .receipt-icon {\r
            width: 34px;\r
            height: 34px;\r
            background: #1c9142;\r
            color: white;\r
            display: flex;\r
            justify-content: center;\r
            align-items: center;\r
            border-radius: 6px;\r
        }\r
\r
        .modal-title h2 {\r
            font-size: 18px;\r
        }\r
\r
        .modal-title p {\r
            font-size: 11px;\r
            color: #999;\r
            margin-top: 3px;\r
        }\r
\r
        /* ================= RECEIPT PAPER ================= */\r
\r
        .receipt-paper {\r
            border: 1px solid #ddd;\r
            padding: 25px;\r
        }\r
\r
        .receipt-header {\r
            display: flex;\r
            justify-content: space-between;\r
            align-items: flex-start;\r
            padding-bottom: 18px;\r
            border-bottom: 1px solid #ddd;\r
        }\r
\r
        .receipt-logo {\r
            font-size: 32px;\r
            font-weight: 900;\r
            color: #00a52a;\r
        }\r
\r
        .receipt-logo span {\r
            color: #ffb000;\r
        }\r
\r
        .receipt-hardware {\r
            color: #ffb000;\r
            font-size: 9px;\r
            font-weight: bold;\r
        }\r
\r
        .receipt-type {\r
            text-align: right;\r
        }\r
\r
        .receipt-type strong {\r
            display: block;\r
            color: #168537;\r
            font-size: 12px;\r
        }\r
\r
        .receipt-type span {\r
            font-size: 10px;\r
            color: #888;\r
        }\r
\r
        /* ================= RECEIPT INFO ================= */\r
\r
        .receipt-info {\r
            display: grid;\r
            grid-template-columns: 1fr 1fr;\r
            margin-top: 16px;\r
            border-bottom: 1px solid #ddd;\r
            padding-bottom: 15px;\r
        }\r
\r
        .info-box {\r
            padding: 8px 10px;\r
            font-size: 11px;\r
        }\r
\r
        .info-box:nth-child(odd) {\r
            border-right: 1px solid #ddd;\r
        }\r
\r
        .info-label {\r
            color: #777;\r
            margin-bottom: 5px;\r
        }\r
\r
        .info-value {\r
            font-weight: bold;\r
        }\r
\r
        /* ================= CUSTOMER ================= */\r
\r
        .customer-section {\r
            margin-top: 15px;\r
            padding-bottom: 15px;\r
            border-bottom: 1px solid #ddd;\r
        }\r
\r
        .customer-title {\r
            font-size: 11px;\r
            color: #777;\r
            margin-bottom: 5px;\r
        }\r
\r
        .customer-name {\r
            font-size: 13px;\r
            font-weight: bold;\r
        }\r
\r
        .customer-phone {\r
            font-size: 10px;\r
            color: #666;\r
            margin-top: 3px;\r
        }\r
\r
        /* ================= ITEMS ================= */\r
\r
        .items-title {\r
            margin-top: 18px;\r
            background: #e8f6e9;\r
            padding: 9px;\r
            font-size: 11px;\r
            font-weight: bold;\r
        }\r
\r
        .items-table {\r
            width: 100%;\r
            min-width: 0;\r
            border-collapse: collapse;\r
        }\r
\r
        .items-table th {\r
            background: #f3faf4;\r
            font-size: 10px;\r
            padding: 9px;\r
        }\r
\r
        .items-table td {\r
            font-size: 10px;\r
            padding: 9px;\r
            border-bottom: 1px solid #eee;\r
        }\r
\r
        /* ================= TOTAL ================= */\r
\r
        .totals {\r
            margin-top: 15px;\r
            margin-left: auto;\r
            width: 260px;\r
        }\r
\r
        .total-row {\r
            display: flex;\r
            justify-content: space-between;\r
            padding: 5px 0;\r
            font-size: 11px;\r
        }\r
\r
        .total-row.final {\r
            border-top: 1px solid #bbb;\r
            margin-top: 5px;\r
            padding-top: 10px;\r
            font-weight: bold;\r
            font-size: 14px;\r
            color: #075b21;\r
        }\r
\r
        /* ================= MODAL ACTIONS ================= */\r
\r
        .modal-actions {\r
            display: flex;\r
            justify-content: flex-end;\r
            gap: 10px;\r
            margin-top: 16px;\r
        }\r
\r
        .close-btn {\r
            background: white;\r
            border: 1px solid #ddd;\r
            padding: 9px 18px;\r
            border-radius: 5px;\r
            cursor: pointer;\r
        }\r
\r
        .print-btn {\r
            background: #238f45;\r
            border: none;\r
            color: white;\r
            padding: 9px 18px;\r
            border-radius: 5px;\r
            cursor: pointer;\r
        }\r
\r
        .print-btn:hover {\r
            background: #176d32;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media(max-width: 1000px) {\r
\r
            .sidebar {\r
                width: 200px;\r
            }\r
\r
            .main {\r
                margin-left: 200px;\r
                padding: 30px;\r
            }\r
\r
            .summary {\r
                grid-template-columns: repeat(2, 1fr);\r
            }\r
\r
        }\r
\r
        @media(max-width: 700px) {\r
\r
            .layout {\r
                display: block;\r
            }\r
\r
            .sidebar {\r
                position: relative;\r
                width: 100%;\r
                height: auto;\r
                min-height: auto;\r
                padding: 20px;\r
            }\r
\r
            .menu {\r
                display: grid;\r
                grid-template-columns: repeat(2, 1fr);\r
                gap: 7px;\r
            }\r
\r
            .menu a {\r
                margin: 0;\r
            }\r
\r
            .main {\r
                margin-left: 0;\r
                padding: 25px 18px;\r
            }\r
\r
            .summary {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .toolbar {\r
                flex-direction: column;\r
            }\r
\r
            .filter-box {\r
                width: 100%;\r
            }\r
\r
            .bottom {\r
                flex-direction: column;\r
                gap: 15px;\r
                align-items: flex-start;\r
            }\r
\r
            .receipt-paper {\r
                padding: 15px;\r
            }\r
\r
        }\r
\r
        /* ================= PRINT ================= */\r
\r
        @media print {\r
\r
            body * {\r
                visibility: hidden;\r
            }\r
\r
            .receipt-modal,\r
            .receipt-modal * {\r
                visibility: visible;\r
            }\r
\r
            .receipt-modal {\r
                position: absolute;\r
                left: 0;\r
                top: 0;\r
                width: 100%;\r
                max-width: none;\r
                max-height: none;\r
                box-shadow: none;\r
                border-radius: 0;\r
            }\r
\r
            .modal-actions {\r
                display: none;\r
            }\r
\r
        }\r
    </style>\r
</head>\r
\r
<body>\r
\r
<div class="layout">\r
\r
    <!-- ================= SIDEBAR ================= -->\r
\r
    <aside class="sidebar">\r
\r
        <div class="logo">\r
            <span style="color:white;">E</span><span>LEE</span>\r
        </div>\r
\r
        <div class="hardware">\r
            HARDWARE\r
        </div>\r
\r
        <div class="menu">\r
\r
            <a href="{{ url('/') }}">\r
                <span class="icon">☼</span>\r
                Dashboard\r
            </a>\r
\r
            <a href="{{ url('/orders') }}">\r
                <span class="icon">▣</span>\r
                Orders\r
            </a>\r
\r
            <a href="{{ url('/products') }}">\r
                <span class="icon">◇</span>\r
                Products\r
            </a>\r
\r
            <a href="{{ url('/ai-recommendations') }}">\r
                <span class="icon">↗</span>\r
                AI Recommendations\r
            </a>\r
\r
            <a href="{{ url('/payments') }}">\r
                <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
                Payments\r
            </a>\r
\r
            <a href="{{ url('/customers') }}">\r
                <span class="icon">♙</span>\r
                Customers\r
            </a>\r
\r
            <a href="{{ url('/queuing') }}">\r
                <span class="icon">▱</span>\r
                Queuing\r
            </a>\r
\r
            <a href="{{ url('/receipt-records') }}" class="active">\r
                <span class="icon">▤</span>\r
                Receipt Records\r
            </a>\r
\r
            <a href="{{ url('/settings') }}">\r
                <span class="icon">⚙</span>\r
                Settings\r
            </a>\r
\r
        </div>\r
\r
    </aside>\r
\r
\r
    <!-- ================= MAIN ================= -->\r
\r
    <main class="main">\r
\r
        <h1 class="page-title">Receipt Records</h1>\r
\r
        <p class="subtitle">\r
            View and manage order receipts, totals, payment methods, and payment status.\r
        </p>\r
\r
\r
        <!-- ================= SUMMARY ================= -->\r
\r
        <div class="summary">\r
\r
            <div class="summary-card">\r
                <div class="label">Total Orders</div>\r
                <div class="number" id="totalOrders">0</div>\r
            </div>\r
\r
            <div class="summary-card">\r
                <div class="label">Total Amount</div>\r
                <div class="number" id="totalAmount">₱0.00</div>\r
            </div>\r
\r
            <div class="summary-card paid">\r
                <div class="label">Paid Orders</div>\r
                <div class="number" id="paidOrders">0</div>\r
            </div>\r
\r
            <div class="summary-card unpaid">\r
                <div class="label">Unpaid Orders</div>\r
                <div class="number" id="unpaidOrders">0</div>\r
            </div>\r
\r
        </div>\r
\r
\r
        <!-- ================= TOOLBAR ================= -->\r
\r
        <div class="toolbar">\r
\r
            <div class="search-box">\r
                <span>⌕</span>\r
\r
                <input\r
                    type="text"\r
                    id="searchInput"\r
                    placeholder="Search receipt, order, or customer..."\r
                    oninput="renderReceipts()"\r
                >\r
            </div>\r
\r
            <select\r
                class="filter-box"\r
                id="statusFilter"\r
                onchange="renderReceipts()"\r
            >\r
                <option value="all">All Payment Status</option>\r
                <option value="Paid">Paid</option>\r
                <option value="Unpaid">Unpaid</option>\r
            </select>\r
\r
        </div>\r
\r
\r
        <!-- ================= TABLE ================= -->\r
\r
        <div class="table-wrapper">\r
\r
            <table>\r
\r
                <thead>\r
                    <tr>\r
                        <th>Receipt No.</th>\r
                        <th>Order ID</th>\r
                        <th>Customer</th>\r
                        <th>Order Total</th>\r
                        <th>Payment Method</th>\r
                        <th>Payment Status</th>\r
                        <th>Date</th>\r
                        <th>Action</th>\r
                    </tr>\r
                </thead>\r
\r
                <tbody id="receiptTableBody"></tbody>\r
\r
            </table>\r
\r
        </div>\r
\r
\r
        <!-- ================= BOTTOM ================= -->\r
\r
        <div class="bottom">\r
\r
            <div id="showingText">\r
                Showing 0 orders\r
            </div>\r
\r
            <div class="pagination">\r
\r
                <span class="page active">\r
                    1\r
                </span>\r
\r
            </div>\r
\r
        </div>\r
\r
    </main>\r
\r
</div>\r
\r
\r
<!-- ================= RECEIPT MODAL ================= -->\r
\r
<div\r
    class="modal-overlay"\r
    id="receiptModal"\r
    onclick="closeOutside(event)"\r
>\r
\r
    <div class="receipt-modal">\r
\r
        <div class="modal-title">\r
\r
            <div class="receipt-icon">\r
                ▣\r
            </div>\r
\r
            <div>\r
                <h2>View Receipt</h2>\r
\r
                <p>\r
                    Order and payment details\r
                </p>\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="receipt-paper">\r
\r
            <div class="receipt-header">\r
\r
                <div>\r
\r
                    <div class="receipt-logo">\r
                        EL<span>EE</span>\r
                    </div>\r
\r
                    <div class="receipt-hardware">\r
                        HARDWARE\r
                    </div>\r
\r
                </div>\r
\r
                <div class="receipt-type">\r
\r
                    <strong>ORDER RECEIPT</strong>\r
\r
                    <span>\r
                        Thank you for your purchase\r
                    </span>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="receipt-info">\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Receipt No.\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalReceiptNo">\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Order ID\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalOrderId">\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Date\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalDate">\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Payment Method\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalPaymentMethod">\r
                    </div>\r
\r
                </div>\r
\r
\r
                <div class="info-box">\r
\r
                    <div class="info-label">\r
                        Payment Status\r
                    </div>\r
\r
                    <div\r
                        class="info-value"\r
                        id="modalPaymentStatus">\r
                    </div>\r
\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="customer-section">\r
\r
                <div class="customer-title">\r
                    Customer\r
                </div>\r
\r
                <div\r
                    class="customer-name"\r
                    id="modalCustomer">\r
                </div>\r
\r
                <div\r
                    class="customer-phone"\r
                    id="modalPhone">\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="items-title">\r
                Items Ordered\r
            </div>\r
\r
            <table class="items-table">\r
\r
                <thead>\r
\r
                    <tr>\r
                        <th>Product</th>\r
                        <th>Qty</th>\r
                        <th>Unit Price</th>\r
                        <th>Subtotal</th>\r
                    </tr>\r
\r
                </thead>\r
\r
                <tbody id="modalItems"></tbody>\r
\r
            </table>\r
\r
\r
            <div class="totals">\r
\r
                <div class="total-row">\r
\r
                    <span>\r
                        Subtotal\r
                    </span>\r
\r
                    <span id="modalSubtotal">\r
                        ₱0.00\r
                    </span>\r
\r
                </div>\r
\r
\r
                <div class="total-row">\r
\r
                    <span>\r
                        Delivery Fee\r
                    </span>\r
\r
                    <span id="modalDeliveryFee">\r
                        ₱0.00\r
                    </span>\r
\r
                </div>\r
\r
\r
                <div class="total-row final">\r
\r
                    <span>\r
                        Order Total\r
                    </span>\r
\r
                    <span id="modalTotal">\r
                        ₱0.00\r
                    </span>\r
\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
\r
        <div class="modal-actions">\r
\r
            <button\r
                class="close-btn"\r
                onclick="closeReceipt()"\r
            >\r
                Close\r
            </button>\r
\r
            <button\r
                class="print-btn"\r
                onclick="printReceipt()"\r
            >\r
                🖨 Print Receipt\r
            </button>\r
\r
        </div>\r
\r
    </div>\r
\r
</div>\r
\r
\r
\r
\r
</body>\r
</html>`,ir=`<!DOCTYPE html>\r
<html lang="en">\r
<head>\r
    <meta charset="UTF-8">\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0">\r
    <title>Settings - ELEE Hardware</title>\r
\r
    <style>\r
        * {\r
            margin: 0;\r
            padding: 0;\r
            box-sizing: border-box;\r
        }\r
\r
        body {\r
            font-family: Arial, sans-serif;\r
            background: #f5f7f5;\r
            color: #333;\r
        }\r
\r
        /* ================= SIDEBAR ================= */\r
\r
        .sidebar {\r
            position: fixed;\r
            left: 0;\r
            top: 0;\r
            width: 235px;\r
            height: 100vh;\r
            background: #00551f;\r
            color: white;\r
            padding: 28px 16px;\r
        }\r
\r
        .logo {\r
            font-size: 36px;\r
            font-weight: 900;\r
            margin-left: 12px;\r
            letter-spacing: -2px;\r
        }\r
\r
        .logo span {\r
            color: #ffbd00;\r
        }\r
\r
        .hardware {\r
            color: #ffbd00;\r
            font-size: 14px;\r
            font-weight: bold;\r
            margin-left: 13px;\r
            margin-top: 3px;\r
            margin-bottom: 25px;\r
        }\r
\r
        .menu {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 7px;\r
        }\r
\r
        .menu a {\r
            text-decoration: none;\r
            color: white;\r
            padding: 13px 14px;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            display: flex;\r
            align-items: center;\r
            gap: 12px;\r
            transition: 0.2s;\r
        }\r
\r
        .menu a:hover {\r
            background: #08732e;\r
        }\r
\r
        .menu a.active {\r
            background: #08732e;\r
        }\r
\r
        .icon {\r
            width: 20px;\r
            text-align: center;\r
            font-size: 18px;\r
        }\r
\r
        /* ================= MAIN ================= */\r
\r
        .main {\r
            margin-left: 235px;\r
            padding: 38px 45px;\r
            min-height: 100vh;\r
        }\r
\r
        .page-title {\r
            font-size: 30px;\r
            font-weight: bold;\r
            color: #075b21;\r
            margin-bottom: 6px;\r
        }\r
\r
        .page-subtitle {\r
            color: #777;\r
            margin-bottom: 28px;\r
        }\r
\r
        /* ================= TABS ================= */\r
\r
        .setting-tabs {\r
            display: flex;\r
            gap: 9px;\r
            flex-wrap: wrap;\r
            margin-bottom: 22px;\r
        }\r
\r
        .setting-tab {\r
            border: 1px solid #e0e0e0;\r
            background: white;\r
            color: #555;\r
            padding: 11px 17px;\r
            border-radius: 8px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            transition: .2s;\r
        }\r
\r
        .setting-tab:hover {\r
            background: #e9f7ec;\r
            color: #087f23;\r
        }\r
\r
        .setting-tab.active {\r
            background: #087f23;\r
            border-color: #087f23;\r
            color: white;\r
        }\r
\r
        /* ================= CONTENT ================= */\r
\r
        .tab-content {\r
            display: none;\r
            background: white;\r
            padding: 28px;\r
            border-radius: 12px;\r
            box-shadow: 0 2px 8px rgba(0,0,0,.07);\r
            max-width: 900px;\r
        }\r
\r
        .tab-content.active {\r
            display: block;\r
        }\r
\r
        .section-header {\r
            margin-bottom: 24px;\r
            padding-bottom: 16px;\r
            border-bottom: 1px solid #eee;\r
        }\r
\r
        .section-title {\r
            font-size: 21px;\r
            font-weight: bold;\r
            color: #222;\r
            margin-bottom: 5px;\r
        }\r
\r
        .section-description {\r
            color: #888;\r
            font-size: 13px;\r
        }\r
\r
        /* ================= FORM ================= */\r
\r
        .form-grid {\r
            display: grid;\r
            grid-template-columns: 1fr 1fr;\r
            gap: 18px;\r
        }\r
\r
        .full-width {\r
            grid-column: 1 / -1;\r
        }\r
\r
        .form-group {\r
            margin-bottom: 4px;\r
        }\r
\r
        .form-group label {\r
            display: block;\r
            margin-bottom: 7px;\r
            font-size: 13px;\r
            font-weight: bold;\r
            color: #444;\r
        }\r
\r
        .form-group input,\r
        .form-group select,\r
        .form-group textarea {\r
            width: 100%;\r
            padding: 11px 12px;\r
            border: 1px solid #d5d5d5;\r
            border-radius: 7px;\r
            font-size: 14px;\r
            outline: none;\r
            background: white;\r
            transition: .2s;\r
        }\r
\r
        .form-group input:focus,\r
        .form-group select:focus,\r
        .form-group textarea:focus {\r
            border-color: #087f23;\r
            box-shadow: 0 0 0 2px rgba(8,127,35,.08);\r
        }\r
\r
        .form-group textarea {\r
            min-height: 95px;\r
            resize: vertical;\r
        }\r
\r
        .hint {\r
            font-size: 11px;\r
            color: #888;\r
            margin-top: 5px;\r
        }\r
\r
        /* ================= INFO BOX ================= */\r
\r
        .info-box {\r
            padding: 15px 17px;\r
            background: #f1f8f2;\r
            border-left: 4px solid #087f23;\r
            border-radius: 6px;\r
            margin-bottom: 22px;\r
            color: #4d4d4d;\r
            font-size: 13px;\r
            line-height: 1.5;\r
        }\r
\r
        /* ================= PAYMENT CARDS ================= */\r
\r
        .option-list {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 12px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .option-card {\r
            display: flex;\r
            align-items: center;\r
            gap: 14px;\r
            border: 1px solid #ddd;\r
            border-radius: 9px;\r
            padding: 16px;\r
            cursor: pointer;\r
            transition: .2s;\r
        }\r
\r
        .option-card:hover {\r
            border-color: #087f23;\r
            background: #f8fcf8;\r
        }\r
\r
        .option-card input {\r
            width: 18px;\r
            height: 18px;\r
            accent-color: #087f23;\r
            cursor: pointer;\r
        }\r
\r
        .option-icon {\r
            width: 40px;\r
            height: 40px;\r
            background: #eaf6ed;\r
            color: #087f23;\r
            border-radius: 8px;\r
            display: flex;\r
            justify-content: center;\r
            align-items: center;\r
            font-size: 20px;\r
        }\r
\r
        .option-info {\r
            flex: 1;\r
        }\r
\r
        .option-title {\r
            font-weight: bold;\r
            font-size: 14px;\r
            margin-bottom: 3px;\r
        }\r
\r
        .option-description {\r
            color: #888;\r
            font-size: 11px;\r
        }\r
\r
        /* ================= NOTIFICATIONS ================= */\r
\r
        .notification-list {\r
            display: flex;\r
            flex-direction: column;\r
            gap: 12px;\r
            margin-bottom: 24px;\r
        }\r
\r
        .notification-item {\r
            display: flex;\r
            align-items: center;\r
            justify-content: space-between;\r
            gap: 15px;\r
            padding: 16px;\r
            border: 1px solid #e2e2e2;\r
            border-radius: 9px;\r
        }\r
\r
        .notification-left {\r
            display: flex;\r
            align-items: center;\r
            gap: 13px;\r
        }\r
\r
        .notification-icon {\r
            width: 40px;\r
            height: 40px;\r
            background: #eaf6ed;\r
            color: #087f23;\r
            border-radius: 8px;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-size: 18px;\r
        }\r
\r
        .notification-name {\r
            font-size: 14px;\r
            font-weight: bold;\r
        }\r
\r
        .notification-description {\r
            color: #888;\r
            font-size: 11px;\r
            margin-top: 3px;\r
        }\r
\r
        /* ================= SWITCH ================= */\r
\r
        .switch {\r
            position: relative;\r
            width: 45px;\r
            height: 24px;\r
            flex-shrink: 0;\r
        }\r
\r
        .switch input {\r
            opacity: 0;\r
            width: 0;\r
            height: 0;\r
        }\r
\r
        .slider {\r
            position: absolute;\r
            inset: 0;\r
            background: #ccc;\r
            border-radius: 30px;\r
            cursor: pointer;\r
            transition: .2s;\r
        }\r
\r
        .slider:before {\r
            content: "";\r
            position: absolute;\r
            width: 18px;\r
            height: 18px;\r
            left: 3px;\r
            top: 3px;\r
            background: white;\r
            border-radius: 50%;\r
            transition: .2s;\r
            box-shadow: 0 1px 3px rgba(0,0,0,.2);\r
        }\r
\r
        .switch input:checked + .slider {\r
            background: #087f23;\r
        }\r
\r
        .switch input:checked + .slider:before {\r
            transform: translateX(21px);\r
        }\r
\r
        /* ================= ACCOUNT ================= */\r
\r
        .account-card {\r
            display: flex;\r
            align-items: center;\r
            gap: 15px;\r
            padding: 18px;\r
            background: #f8faf8;\r
            border: 1px solid #e5e5e5;\r
            border-radius: 9px;\r
            margin-bottom: 22px;\r
        }\r
\r
        .account-avatar {\r
            width: 55px;\r
            height: 55px;\r
            background: #087f23;\r
            color: white;\r
            border-radius: 50%;\r
            display: flex;\r
            align-items: center;\r
            justify-content: center;\r
            font-size: 23px;\r
            font-weight: bold;\r
        }\r
\r
        .account-name {\r
            font-weight: bold;\r
            font-size: 15px;\r
        }\r
\r
        .account-role {\r
            color: #888;\r
            font-size: 12px;\r
            margin-top: 3px;\r
        }\r
\r
        /* ================= BUTTON ================= */\r
\r
        .save-btn {\r
            background: #087f23;\r
            color: white;\r
            border: none;\r
            padding: 11px 23px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 13px;\r
            font-weight: bold;\r
            transition: .2s;\r
        }\r
\r
        .save-btn:hover {\r
            background: #06691c;\r
        }\r
\r
        .secondary-btn {\r
            background: white;\r
            color: #087f23;\r
            border: 1px solid #087f23;\r
            padding: 10px 20px;\r
            border-radius: 7px;\r
            cursor: pointer;\r
            font-size: 13px;\r
        }\r
\r
        .secondary-btn:hover {\r
            background: #eaf6ed;\r
        }\r
\r
        .button-row {\r
            display: flex;\r
            gap: 10px;\r
            margin-top: 22px;\r
        }\r
\r
        /* ================= TOAST ================= */\r
\r
        .toast {\r
            position: fixed;\r
            right: 25px;\r
            bottom: 25px;\r
            background: #087f23;\r
            color: white;\r
            padding: 14px 20px;\r
            border-radius: 8px;\r
            box-shadow: 0 5px 20px rgba(0,0,0,.2);\r
            font-size: 13px;\r
            display: flex;\r
            align-items: center;\r
            gap: 10px;\r
            transform: translateY(100px);\r
            opacity: 0;\r
            pointer-events: none;\r
            transition: .3s;\r
            z-index: 2000;\r
        }\r
\r
        .toast.show {\r
            transform: translateY(0);\r
            opacity: 1;\r
        }\r
\r
        /* ================= RESPONSIVE ================= */\r
\r
        @media(max-width: 900px) {\r
\r
            .sidebar {\r
                width: 210px;\r
            }\r
\r
            .main {\r
                margin-left: 210px;\r
                padding: 25px;\r
            }\r
\r
            .form-grid {\r
                grid-template-columns: 1fr;\r
            }\r
\r
            .full-width {\r
                grid-column: auto;\r
            }\r
        }\r
\r
        @media(max-width: 650px) {\r
\r
            .sidebar {\r
                position: relative;\r
                width: 100%;\r
                height: auto;\r
                padding: 20px;\r
            }\r
\r
            .menu {\r
                display: grid;\r
                grid-template-columns: 1fr 1fr;\r
            }\r
\r
            .menu a {\r
                padding: 11px 15px;\r
            }\r
\r
            .main {\r
                margin-left: 0;\r
                padding: 20px 15px;\r
            }\r
\r
            .page-title {\r
                font-size: 25px;\r
            }\r
\r
            .tab-content {\r
                padding: 20px;\r
            }\r
\r
            .setting-tabs {\r
                display: grid;\r
                grid-template-columns: 1fr 1fr;\r
            }\r
\r
            .setting-tab {\r
                width: 100%;\r
            }\r
\r
            .notification-item {\r
                align-items: flex-start;\r
            }\r
        }\r
    </style>\r
</head>\r
\r
<body>\r
\r
<!-- ================= SIDEBAR ================= -->\r
\r
<div class="sidebar">\r
\r
    <div class="logo">\r
        <span style="color:white;">E</span><span>LEE</span>\r
    </div>\r
\r
    <div class="hardware">\r
        HARDWARE\r
    </div>\r
\r
    <div class="menu">\r
\r
        <a href="{{ url('/') }}">\r
            <span class="icon">☼</span>\r
            Dashboard\r
        </a>\r
\r
        <a href="{{ url('/orders') }}">\r
            <span class="icon">▣</span>\r
            Orders\r
        </a>\r
\r
        <a href="{{ url('/products') }}">\r
            <span class="icon">◇</span>\r
            Products\r
        </a>\r
\r
        <a href="{{ url('/ai-recommendations') }}">\r
            <span class="icon">↗</span>\r
            AI Recommendations\r
        </a>\r
\r
        <a href="{{ url('/payments') }}">\r
            <span class="icon"><svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5.5" width="17" height="14" rx="2"/><path d="M3.5 9h17M7 5.5v-.75A1.75 1.75 0 0 1 8.75 3h8.5"/><path d="M16 13h4.5"/><circle cx="16" cy="13" r=".55"/></svg></span>\r
            Payments\r
        </a>\r
\r
        <a href="{{ url('/customers') }}">\r
            <span class="icon">♙</span>\r
            Customers\r
        </a>\r
\r
        <a href="{{ url('/queuing') }}">\r
            <span class="icon">▱</span>\r
            Queuing\r
        </a>\r
\r
        <a href="{{ url('/receipt-records') }}">\r
            <span class="icon">▤</span>\r
            Receipt Records\r
        </a>\r
\r
        <a href="{{ url('/settings') }}" class="active">\r
            <span class="icon">⚙</span>\r
            Settings\r
        </a>\r
\r
    </div>\r
</div>\r
\r
\r
<!-- ================= MAIN ================= -->\r
\r
<main class="main settings-page">\r
\r
    <h1 class="page-title">\r
        Settings\r
    </h1>\r
\r
    <p class="page-subtitle">\r
        Manage your store information, payment options, notifications, and admin account.\r
    </p>\r
\r
\r
    <!-- ================= TABS ================= -->\r
\r
    <div class="setting-tabs">\r
\r
        <button\r
            type="button"\r
            class="setting-tab active"\r
            onclick="openTab('general', this)"\r
        >\r
            ⚙️ General\r
        </button>\r
\r
        <button\r
            type="button"\r
            class="setting-tab"\r
            onclick="openTab('store', this)"\r
        >\r
            🏪 Store Information\r
        </button>\r
\r
        <button\r
            type="button"\r
            class="setting-tab"\r
            onclick="openTab('payment', this)"\r
        >\r
            💳 Payment Methods\r
        </button>\r
\r
        <button\r
            type="button"\r
            class="setting-tab"\r
            onclick="openTab('notification', this)"\r
        >\r
            🔔 Notifications\r
        </button>\r
\r
        <button\r
            type="button"\r
            class="setting-tab"\r
            onclick="openTab('account', this)"\r
        >\r
            👤 Admin Account\r
        </button>\r
\r
    </div>\r
\r
\r
    <!-- GENERAL SETTINGS -->\r
\r
    <section id="general" class="tab-content active">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                General Settings\r
            </h2>\r
\r
            <p class="section-description">\r
                Manage the basic settings of the ELEE Hardware system.\r
            </p>\r
\r
        </div>\r
\r
        <div class="info-box">\r
            These settings control the basic information displayed\r
            throughout the store management system.\r
        </div>\r
\r
        <div class="form-grid">\r
\r
            <div class="form-group">\r
                <label>System Name</label>\r
                <input\r
                    type="text"\r
                    id="systemName"\r
                    value="ELEE Hardware"\r
                >\r
            </div>\r
\r
            <div class="form-group">\r
                <label>Language</label>\r
\r
                <!-- ENGLISH ONLY -->\r
                <select id="language">\r
                    <option value="English">English</option>\r
                </select>\r
\r
            </div>\r
\r
        </div>\r
\r
        <div class="button-row">\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="saveGeneralSettings()"\r
            >\r
                Save Settings\r
            </button>\r
        </div>\r
\r
    </section>\r
\r
\r
    <!-- STORE INFORMATION -->\r
\r
    <section id="store" class="tab-content">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                Store Information\r
            </h2>\r
\r
            <p class="section-description">\r
                Update the basic information of your hardware store.\r
            </p>\r
\r
        </div>\r
\r
        <div class="form-grid">\r
\r
            <div class="form-group">\r
                <label>Store Name</label>\r
                <input\r
                    type="text"\r
                    id="storeName"\r
                    value="ELEE Hardware"\r
                >\r
            </div>\r
\r
            <div class="form-group">\r
                <label>Contact Number</label>\r
                <input\r
                    type="text"\r
                    id="storeContact"\r
                    placeholder="Enter contact number"\r
                >\r
            </div>\r
\r
            <div class="form-group full-width">\r
                <label>Store Address</label>\r
                <textarea\r
                    id="storeAddress"\r
                    placeholder="Enter store address"\r
                ></textarea>\r
            </div>\r
\r
            <div class="form-group">\r
                <label>Email Address</label>\r
                <input\r
                    type="email"\r
                    id="storeEmail"\r
                    placeholder="Enter store email"\r
                >\r
            </div>\r
\r
            <div class="form-group">\r
                <label>Store Status</label>\r
                <select id="storeStatus">\r
                    <option value="Open">Open</option>\r
                    <option value="Closed">Closed</option>\r
                </select>\r
            </div>\r
\r
        </div>\r
\r
        <div class="button-row">\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="saveStoreSettings()"\r
            >\r
                Save Store Information\r
            </button>\r
        </div>\r
\r
    </section>\r
\r
\r
    <!-- PAYMENT METHODS -->\r
\r
    <section id="payment" class="tab-content">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                Payment Methods\r
            </h2>\r
\r
            <p class="section-description">\r
                Select the payment methods available to customers.\r
            </p>\r
\r
        </div>\r
\r
        <div class="info-box">\r
            The system currently supports cash payments for\r
            Cash at Store and Cash on Delivery orders.\r
        </div>\r
\r
        <div class="option-list">\r
\r
            <label class="option-card">\r
\r
                <input\r
                    type="checkbox"\r
                    id="cashStore"\r
                    checked\r
                >\r
\r
                <div class="option-icon">\r
                    🏪\r
                </div>\r
\r
                <div class="option-info">\r
\r
                    <div class="option-title">\r
                        Cash at Store\r
                    </div>\r
\r
                    <div class="option-description">\r
                        Customer pays the order at the physical store.\r
                    </div>\r
\r
                </div>\r
\r
            </label>\r
\r
\r
            <label class="option-card">\r
\r
                <input\r
                    type="checkbox"\r
                    id="cashDelivery"\r
                    checked\r
                >\r
\r
                <div class="option-icon">\r
                    🚚\r
                </div>\r
\r
                <div class="option-info">\r
\r
                    <div class="option-title">\r
                        Cash on Delivery\r
                    </div>\r
\r
                    <div class="option-description">\r
                        Customer pays cash when the order is delivered.\r
                    </div>\r
\r
                </div>\r
\r
            </label>\r
\r
        </div>\r
\r
        <div class="button-row">\r
\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="savePaymentSettings()"\r
            >\r
                Save Payment Settings\r
            </button>\r
\r
        </div>\r
\r
    </section>\r
\r
\r
    <!-- NOTIFICATIONS -->\r
\r
    <section id="notification" class="tab-content">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                Notifications\r
            </h2>\r
\r
            <p class="section-description">\r
                Choose which alerts should be shown to staff.\r
            </p>\r
\r
        </div>\r
\r
        <div class="info-box">\r
            Notifications help staff monitor new orders, changes,\r
            cancellations, and products that are running low in stock.\r
        </div>\r
\r
        <div class="notification-list">\r
\r
            <div class="notification-item">\r
\r
                <div class="notification-left">\r
\r
                    <div class="notification-icon">\r
                        🛒\r
                    </div>\r
\r
                    <div>\r
\r
                        <div class="notification-name">\r
                            New Orders\r
                        </div>\r
\r
                        <div class="notification-description">\r
                            Alert staff when a new order is received.\r
                        </div>\r
\r
                    </div>\r
\r
                </div>\r
\r
                <label class="switch">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="notifyNewOrders"\r
                        checked\r
                    >\r
\r
                    <span class="slider"></span>\r
\r
                </label>\r
\r
            </div>\r
\r
\r
            <div class="notification-item">\r
\r
                <div class="notification-left">\r
\r
                    <div class="notification-icon">\r
                        ✏️\r
                    </div>\r
\r
                    <div>\r
\r
                        <div class="notification-name">\r
                            Order Changes\r
                        </div>\r
\r
                        <div class="notification-description">\r
                            Alert staff when an existing order is changed.\r
                        </div>\r
\r
                    </div>\r
\r
                </div>\r
\r
                <label class="switch">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="notifyOrderChanges"\r
                        checked\r
                    >\r
\r
                    <span class="slider"></span>\r
\r
                </label>\r
\r
            </div>\r
\r
\r
            <div class="notification-item">\r
\r
                <div class="notification-left">\r
\r
                    <div class="notification-icon">\r
                        ❌\r
                    </div>\r
\r
                    <div>\r
\r
                        <div class="notification-name">\r
                            Order Cancellations\r
                        </div>\r
\r
                        <div class="notification-description">\r
                            Alert staff when an order is cancelled.\r
                        </div>\r
\r
                    </div>\r
\r
                </div>\r
\r
                <label class="switch">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="notifyCancellations"\r
                        checked\r
                    >\r
\r
                    <span class="slider"></span>\r
\r
                </label>\r
\r
            </div>\r
\r
\r
            <div class="notification-item">\r
\r
                <div class="notification-left">\r
\r
                    <div class="notification-icon">\r
                        ⚠️\r
                    </div>\r
\r
                    <div>\r
\r
                        <div class="notification-name">\r
                            Low-Stock Products\r
                        </div>\r
\r
                        <div class="notification-description">\r
                            Alert staff when product inventory reaches a low level.\r
                        </div>\r
\r
                    </div>\r
\r
                </div>\r
\r
                <label class="switch">\r
\r
                    <input\r
                        type="checkbox"\r
                        id="notifyLowStock"\r
                        checked\r
                    >\r
\r
                    <span class="slider"></span>\r
\r
                </label>\r
\r
            </div>\r
\r
        </div>\r
\r
        <div class="button-row">\r
\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="saveNotificationSettings()"\r
            >\r
                Save Notification Settings\r
            </button>\r
\r
        </div>\r
\r
    </section>\r
\r
\r
    <!-- ADMIN ACCOUNT -->\r
\r
    <section id="account" class="tab-content">\r
\r
        <div class="section-header">\r
\r
            <h2 class="section-title">\r
                Admin Account\r
            </h2>\r
\r
            <p class="section-description">\r
                Manage the administrator account information.\r
            </p>\r
\r
        </div>\r
\r
        <div class="account-card">\r
\r
            <div class="account-avatar">\r
                A\r
            </div>\r
\r
            <div>\r
\r
                <div\r
                    class="account-name"\r
                    id="accountDisplayName"\r
                >\r
                    Administrator\r
                </div>\r
\r
                <div class="account-role">\r
                    Store Administrator\r
                </div>\r
\r
            </div>\r
\r
        </div>\r
\r
        <div class="form-grid">\r
\r
            <div class="form-group">\r
\r
                <label>Admin Name</label>\r
\r
                <input\r
                    type="text"\r
                    id="adminName"\r
                    value="Administrator"\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>Username</label>\r
\r
                <input\r
                    type="text"\r
                    id="adminUsername"\r
                    value="admin"\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>Email Address</label>\r
\r
                <input\r
                    type="email"\r
                    id="adminEmail"\r
                    placeholder="admin@example.com"\r
                >\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>Role</label>\r
\r
                <select id="adminRole">\r
\r
                    <option value="Administrator">\r
                        Administrator\r
                    </option>\r
\r
                    <option value="Staff">\r
                        Staff\r
                    </option>\r
\r
                </select>\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>New Password</label>\r
\r
                <input\r
                    type="password"\r
                    id="adminPassword"\r
                    placeholder="Enter new password"\r
                >\r
\r
                <div class="hint">\r
                    Leave blank if you do not want to change the password.\r
                </div>\r
\r
            </div>\r
\r
\r
            <div class="form-group">\r
\r
                <label>Confirm Password</label>\r
\r
                <input\r
                    type="password"\r
                    id="confirmPassword"\r
                    placeholder="Confirm new password"\r
                >\r
\r
            </div>\r
\r
        </div>\r
\r
        <div class="button-row">\r
\r
            <button\r
                type="button"\r
                class="save-btn"\r
                onclick="saveAccountSettings()"\r
            >\r
                Save Account Settings\r
            </button>\r
\r
        </div>\r
\r
    </section>\r
\r
</main>\r
\r
\r
<!-- ================= TOAST ================= -->\r
\r
<div class="toast" id="toast">\r
\r
    <span>✓</span>\r
\r
    <span id="toastMessage">\r
        Settings saved successfully!\r
    </span>\r
\r
</div>\r
\r
\r
\r
\r
</body>\r
</html>\r
`,ar=".legacy-screen{--admin-sidebar-width: 244px;--admin-page-gutter: 36px;--admin-text: #202a24;--admin-muted: #6e7b73;min-height:100vh;background:#f7f9f7;color:var(--admin-text);line-height:1.5}.legacy-screen .sidebar{position:fixed;inset:0 auto 0 0;width:var(--admin-sidebar-width);height:100vh;min-height:0;padding:24px 14px;overflow-y:auto}.legacy-screen .logo{margin-left:12px;font-size:33px;line-height:1.1;letter-spacing:-1.5px}.legacy-screen .hardware{margin:4px 0 22px 13px;font-size:12px;letter-spacing:.06em}.legacy-screen .menu{gap:4px}.legacy-screen .menu a{min-height:44px;padding:9px 12px;gap:10px;border-radius:8px;font-size:13px;line-height:1.3}.legacy-screen .menu-icon,.legacy-screen .menu .icon{display:inline-flex;flex:0 0 22px;width:22px;height:22px;align-items:center;justify-content:center;font-size:17px;line-height:1}.legacy-screen .menu-icon svg,.legacy-screen .menu .icon svg,.legacy-screen .menu a>svg{display:block;width:18px;height:18px;flex:0 0 18px}.legacy-screen .main{box-sizing:border-box;flex:1 1 0%;width:auto;min-width:0;margin-left:var(--admin-sidebar-width);padding:32px var(--admin-page-gutter)}.legacy-screen .main:has(>.content){padding:0}.legacy-screen .content{box-sizing:border-box;flex:1 1 0%;width:auto;min-width:0;padding:32px var(--admin-page-gutter)}.legacy-screen .dashboard>.content{margin-left:var(--admin-sidebar-width)}.legacy-screen .dashboard>.main{margin-left:var(--admin-sidebar-width)}.legacy-screen .section-header,.legacy-screen .page-header,.legacy-screen .header{align-items:flex-start;gap:18px;margin-bottom:24px}.legacy-screen .section-title,.legacy-screen .page-title,.legacy-screen .page-header h1,.legacy-screen .header h1,.legacy-screen .title{color:#137a37;font-family:Arial,Helvetica,sans-serif;font-size:27px;line-height:1.25;letter-spacing:-.02em}.legacy-screen .page-header h1{background:transparent}.legacy-screen .header h1{font-size:27px;font-weight:700}.legacy-screen .customer-page{width:auto;min-width:0;margin-left:var(--admin-sidebar-width);margin-right:0;padding:32px var(--admin-page-gutter)}.legacy-screen .settings-page .tab-content{width:100%;max-width:none}.legacy-screen .section-description,.legacy-screen .page-subtitle,.legacy-screen .subtitle,.legacy-screen .header p{color:var(--admin-muted);font-size:14px;line-height:1.5}.legacy-screen .summary-grid,.legacy-screen .summary-cards,.legacy-screen .summary{gap:16px}.legacy-screen .search-container,.legacy-screen .search-box,.legacy-screen input:not([type=checkbox]):not([type=radio]),.legacy-screen select{min-width:0}.legacy-screen input:not([type=checkbox]):not([type=radio]),.legacy-screen select,.legacy-screen textarea{border-radius:8px}.legacy-screen button{border-radius:8px}.legacy-screen .table-container,.legacy-screen .table-wrapper,.legacy-screen .orders-table,.legacy-screen .table-wrap{max-width:100%;overflow-x:auto}.legacy-screen table th,.legacy-screen table td{padding:12px 16px;vertical-align:middle}.legacy-screen .table-header,.legacy-screen .order-row{min-height:64px;align-items:center}.legacy-screen .status{line-height:1.25}.legacy-screen .status.pending,.legacy-screen .badge-pending{background:#fff3d6;color:#ffb300}.legacy-screen .status.processing{background:#e8f2ff;color:#307fd9}.legacy-screen .status.ready,.legacy-screen .badge-ready{background:#efd7ff;color:#7800a8}.legacy-screen .status.completed,.legacy-screen .badge-completed{background:#e7f8e8;color:#13ae16}.legacy-screen .status.cancelled{background:#fde8e8;color:#ea1e1e}.legacy-screen .status-dot.pending{background:#ffb300}.legacy-screen .status-dot.processing{background:#307fd9}.legacy-screen .status-dot.ready{background:#8e00c7}.legacy-screen .status-dot.completed{background:#13ae16}.legacy-screen .badge-cancelled{background:#fde8e8;color:#ea1e1e}@media(max-width:1000px){.legacy-screen{--admin-sidebar-width: 220px;--admin-page-gutter: 26px}}@media(max-width:760px){.legacy-screen .dashboard,.legacy-screen .layout{display:block}.legacy-screen .sidebar{position:relative;inset:auto;width:100%;height:auto;min-height:0;padding:18px 16px}.legacy-screen .menu{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}.legacy-screen .menu a{min-height:40px;padding:8px;gap:7px;font-size:12px}.legacy-screen .menu-icon,.legacy-screen .menu .icon{flex-basis:20px;width:20px}.legacy-screen .main,.legacy-screen .content,.legacy-screen .dashboard>.main,.legacy-screen .dashboard>.content{width:100%;margin-left:0;padding:24px 18px}.legacy-screen .main:has(>.content){padding:0}.legacy-screen .section-header,.legacy-screen .page-header,.legacy-screen .header{flex-wrap:wrap}.legacy-screen .summary-grid,.legacy-screen .summary-cards,.legacy-screen .summary{grid-template-columns:repeat(2,minmax(0,1fr))}.legacy-screen .tabs{display:flex;max-width:100%;overflow-x:auto;gap:8px}.legacy-screen .tabs .tab{flex:0 0 auto}}@media(max-width:520px){.legacy-screen{--admin-page-gutter: 18px}.legacy-screen .menu{grid-template-columns:repeat(2,minmax(0,1fr))}.legacy-screen .section-title,.legacy-screen .page-title,.legacy-screen .page-header h1,.legacy-screen .header h1,.legacy-screen .title{font-size:23px}.legacy-screen .summary-grid,.legacy-screen .summary-cards,.legacy-screen .summary{grid-template-columns:1fr}}";function or({product:e,products:t,save:s,busy:p}){const[g,d]=u.useState((e.recommended_product_ids||[]).filter(i=>t.some(h=>h.id===i))),[m,v]=u.useState(""),o=Object.entries(e.ml_recommendation_scores||{}).map(([i,h])=>({product:t.find(j=>j.id===Number(i)),score:h})).filter(i=>{var h;return((h=i.product)==null?void 0:h.is_active)&&i.product.stock>0}).sort((i,h)=>h.score-i.score);return n.jsxs("section",{className:"recommendation-editor",children:[n.jsxs("h3",{children:["Automatic AI suggestions for ",e.name]}),n.jsx("p",{children:"Learned from completed order history. No manual selection is needed."}),o.length?n.jsx("div",{className:"recommendation-options",children:o.map(({product:i,score:h})=>n.jsxs("article",{className:"learned-product",children:[n.jsx("strong",{children:i.name}),n.jsxs("p",{children:[i.category," · ₱",i.price.toFixed(2)]}),n.jsxs("small",{children:["Learned similarity: ",h.toFixed(3)]})]},i.id))}):n.jsx("p",{children:"No learned suggestions for this product yet. Complete orders containing this product with other items so the model can learn."}),n.jsxs("details",{children:[n.jsx("summary",{children:"Optional manual fallback"}),n.jsxs("form",{onSubmit:async i=>{i.preventDefault(),v(""),await s(e.id,g)&&v("Recommendations saved. Customers will see these products in their cart.")},children:[n.jsxs("h3",{children:["Related products for ",e.name]}),n.jsx("p",{children:"Choose up to 20 products. Hidden and out-of-stock products are excluded from customer suggestions."}),n.jsx("div",{className:"recommendation-options",children:t.filter(i=>i.id!==e.id).map(i=>n.jsxs("label",{children:[n.jsx("input",{type:"checkbox",checked:g.includes(i.id),disabled:p||!g.includes(i.id)&&g.length>=20,onChange:h=>d(j=>h.target.checked?[...j,i.id]:j.filter(T=>T!==i.id))}),n.jsxs("span",{children:[n.jsx("strong",{children:i.name}),n.jsxs("small",{children:[i.category," · ₱",i.price.toFixed(2)," · ",i.is_active?`${i.stock} in stock`:"Hidden"]})]})]},i.id))}),n.jsx("button",{disabled:p,type:"submit",children:p?"Saving…":"Save recommendations"}),m&&n.jsx("p",{role:"status",children:m})]})]})]})}const gn=e=>new Intl.NumberFormat("en-PH",{style:"currency",currency:"PHP",maximumFractionDigits:0}).format(e);function _n(e){const t=new Intl.DateTimeFormat("en-US",{year:"numeric",month:"2-digit",day:"2-digit",timeZone:"Asia/Manila"}).formatToParts(new Date(e)),s=p=>t.find(g=>g.type===p).value;return`${s("year")}-${s("month")}-${s("day")}`}function sr({orders:e}){const[t,s]=u.useState(7),p=new Map;e.forEach(x=>{const l=_n(x.paid_at||x.created_at);p.set(l,(p.get(l)||0)+x.total)});const g=new Date(`${_n(new Date)}T00:00:00Z`),d=Array.from({length:t},(x,l)=>{const A=new Date(g);A.setUTCDate(A.getUTCDate()-t+1+l);const O=A.toISOString().slice(0,10);return{key:O,total:p.get(O)||0,date:A}}),m=d.reduce((x,l)=>x+l.total,0),v=720,o=240,i=74,h=25,j=25,T=42,I=Math.max(100,...d.map(x=>x.total)),U=10**Math.floor(Math.log10(I)),N=Math.ceil(I/U)*U,C=x=>i+x*(v-i-h)/(t-1),b=x=>o-T-x/N*(o-j-T),E=d.map((x,l)=>`${C(l)},${b(x.total)}`).join(" ");return n.jsxs("section",{className:"sales-line-chart","aria-label":"Daily sales trend",children:[n.jsxs("div",{className:"sales-trend-header",children:[n.jsxs("div",{children:[n.jsx("strong",{children:gn(m)}),n.jsxs("small",{children:["Paid sales · Last ",t," days"]})]}),n.jsx("div",{className:"sales-period","aria-label":"Chart period",children:[7,30].map(x=>n.jsxs("button",{type:"button",className:t===x?"active":"","aria-pressed":t===x,onClick:()=>s(x),children:[x," days"]},x))})]}),n.jsxs("svg",{viewBox:`0 0 ${v} ${o}`,role:"img","aria-label":`Daily paid sales over the last ${t} days`,children:[n.jsx("title",{children:"Daily sales in Philippine pesos"}),n.jsx("desc",{children:d.map(x=>`${x.key}: ${gn(x.total)}`).join("; ")}),n.jsx("defs",{children:n.jsxs("linearGradient",{id:"sales-area",x1:"0",y1:"0",x2:"0",y2:"1",children:[n.jsx("stop",{offset:"0%",stopColor:"#08752f",stopOpacity:".16"}),n.jsx("stop",{offset:"100%",stopColor:"#08752f",stopOpacity:".01"})]})}),[0,.25,.5,.75,1].map(x=>n.jsxs("g",{children:[n.jsx("line",{x1:i,x2:v-h,y1:b(N*x),y2:b(N*x),stroke:"#e7ede7",strokeDasharray:x?"3 6":void 0}),n.jsx("text",{x:i-12,y:b(N*x)+4,textAnchor:"end",className:"sales-axis",children:gn(N*x)})]},x)),n.jsx("polygon",{points:`${i},${b(0)} ${E} ${v-h},${b(0)}`,fill:"url(#sales-area)"}),n.jsx("polyline",{points:E,fill:"none",stroke:"#08752f",strokeWidth:"2.8",strokeLinejoin:"round",strokeLinecap:"round"}),d.map((x,l)=>n.jsxs("g",{children:[n.jsx("circle",{cx:C(l),cy:b(x.total),r:x.total?4:2,fill:x.total?"#08752f":"#94b49a",stroke:"white",strokeWidth:"1.5",children:n.jsxs("title",{children:[x.key,": ",gn(x.total)]})}),(t===7||l%5===0||l===t-1)&&n.jsx("text",{x:C(l),y:o-15,textAnchor:"middle",className:"sales-axis",children:x.date.toLocaleDateString("en-PH",{month:"short",day:"numeric",timeZone:"UTC"})})]},x.key))]}),!m&&n.jsx("p",{className:"sales-chart-caption",children:"No paid sales in this period."})]})}const dr=Object.assign({"../legacy/admin-login.html":Qn,"../legacy/ai-recommendations.html":Kn,"../legacy/customers.html":Zn,"../legacy/dashboard.html":Jn,"../legacy/orders.html":Xn,"../legacy/payments.html":nr,"../legacy/products.html":rr,"../legacy/queuing.html":er,"../legacy/receipt-records.html":tr,"../legacy/settings.html":ir}),B=e=>new Intl.NumberFormat("en-PH",{style:"currency",currency:"PHP"}).format(e),on=e=>new Intl.DateTimeFormat("en-PH",{dateStyle:"medium",timeStyle:"short",timeZone:"Asia/Manila"}).format(new Date(e)),Dn=e=>["Completed","Cancelled"].includes(e.order_status);function lr(e){var d,m,v;const t=dr[`../legacy/${e}.html`].replace(/\{\{\s*url\('([^']+)'\)\s*\}\}/g,"$1").replace(/@if\s*\(session\('error'\)\)[\s\S]*?@endif/g,"").replace(/@csrf/g,""),s=new DOMParser().parseFromString(t,"text/html"),p=[...s.querySelectorAll("style")].map(o=>o.textContent).join(`
`);s.querySelectorAll('script, style, .modal-overlay, .modal-bg, [id$="Modal"], #productForm, .toast').forEach(o=>o.remove()),s.querySelectorAll("*").forEach(o=>{[...o.attributes].filter(i=>i.name.startsWith("on")).forEach(i=>{i.name==="onclick"&&(o.dataset.originalAction=i.value),o.removeAttribute(i.name)})}),s.querySelectorAll("tbody").forEach(o=>o.replaceChildren()),s.querySelectorAll(".card-number, .card-change, .payment-value, .donut-number, .status-item strong").forEach(o=>{o.textContent="—"}),s.querySelectorAll(".sidebar a").forEach(o=>{const i=o.getAttribute("href");if(i!=null&&i.includes("logout")){o.href="#sign-out";return}const h=i==="/"?"dashboard":i==null?void 0:i.replace(/^\//,"");o.href=`/admin/${h}`,o.classList.toggle("active",h===e)});const g=new Set(["dashboard","orders","products","queuing","customers","payments","receipt-records","settings","ai-recommendations"]);if(s.querySelectorAll("a[href]").forEach(o=>{const i=o.getAttribute("href"),h=i==="/"?"dashboard":i==null?void 0:i.replace(/^\//,"");g.has(h)&&(o.href=`/admin/${h}`)}),e==="queuing"){const o=s.createElement("option");o.value="Ready for Pickup",o.textContent="Ready for Pickup",(d=s.querySelector("#statusFilter"))==null||d.append(o)}if(e==="orders"){const o=s.querySelector(".main > .section-divider");if(o){for(;o.nextElementSibling;)o.nextElementSibling.remove();o.remove()}const i=s.querySelector(".tabs"),h=s.createElement("button");h.className="tab",h.dataset.status="Ready for Pickup",h.textContent="Ready for Pickup",i==null||i.insertBefore(h,i.querySelector('[data-status="Completed"]')),i==null||i.setAttribute("aria-label","Filter orders by status")}if(e==="dashboard"&&s.querySelectorAll(".box-subtitle").forEach(o=>{o.textContent.includes("Monthly performance")&&(o.textContent="Daily paid sales · Philippine peso")}),e==="products"){const o=s.querySelector("#statusFilter"),i=s.createElement("option");i.value="Archived",i.textContent="Archived",o==null||o.append(i)}if(e==="ai-recommendations"){(m=s.querySelector(".add-btn"))==null||m.remove();const o=s.querySelector(".page-title");o&&(o.textContent="Product Recommendations");const i=s.querySelector(".page-subtitle");i&&(i.textContent="Manage related products shown in the customer cart"),s.querySelectorAll("*").forEach(h=>{h.children.length===0&&h.textContent.includes("AI recommendations help")&&(h.textContent="Related products selected here appear in the customer cart.")})}if(e!=="admin-login"&&!s.querySelector('.sidebar a[href="#sign-out"]')){const o=s.createElement("a");o.href="#sign-out",o.className="logout",o.textContent="↪ Logout",(v=s.querySelector(".sidebar .menu"))==null||v.append(o)}if(e==="settings"){const o=s.querySelector(".page-subtitle");o&&(o.textContent="Manage store details, order options, alerts and your account.");const i=s.querySelector("#general");i&&i.replaceChildren(),s.querySelectorAll(".tab-content:not(#general), .tabs, .setting-tabs").forEach(h=>h.remove())}return s.querySelectorAll('input[placeholder^="Search"]').forEach(o=>{let i=o.parentElement;i.matches(".search-box, .search-container")||(i=s.createElement("div"),o.before(i),i.append(o)),i.classList.add("unified-search"),[...i.children].filter(j=>j!==o&&j.tagName!=="BUTTON").forEach(j=>j.remove());const h=s.createElement("span");h.className="unified-search-icon",h.setAttribute("aria-hidden","true"),h.innerHTML='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>',i.prepend(h),o.hasAttribute("aria-label")||o.setAttribute("aria-label",o.placeholder.replace(/\.+$/,""))}),{html:s.body.innerHTML,css:p}}function cr({children:e}){return n.jsx("main",{className:"legacy-screen original-login staff-login",children:n.jsxs("div",{className:"login-shell",children:[n.jsxs("section",{className:"login-story","aria-label":"ELEE Hardware",children:[n.jsxs("div",{className:"login-brand","aria-label":"ELEE Hardware",children:[n.jsxs("div",{className:"login-wordmark","aria-hidden":"true",children:[n.jsx("span",{children:"E"}),n.jsx("span",{children:"LEE"})]}),n.jsx("small",{"aria-hidden":"true",children:"HARDWARE".split("").map((t,s)=>n.jsx("span",{children:t},s))})]}),n.jsxs("div",{className:"login-story-copy",children:[n.jsx("span",{className:"login-eyebrow",children:"YOUR STORE, CONNECTED"}),n.jsxs("h1",{children:["Every order.",n.jsx("br",{}),"One clear view."]}),n.jsx("p",{children:"Keep orders moving, inventory updated, and customers informed."}),n.jsxs("div",{className:"login-feature-list",children:[n.jsx("span",{children:"Orders & queue"}),n.jsx("span",{children:"Live inventory"}),n.jsx("span",{children:"Customer updates"})]})]}),n.jsxs("div",{className:"login-story-footer",children:[n.jsx("span",{className:"login-dot"})," ELEE staff workspace"]}),n.jsx("div",{className:"login-orbit orbit-one","aria-hidden":"true"}),n.jsx("div",{className:"login-orbit orbit-two","aria-hidden":"true"})]}),n.jsxs("section",{className:"login-card","aria-labelledby":"staff-login-title",children:[n.jsx("div",{className:"login-access-icon","aria-hidden":"true",children:n.jsxs("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.7",children:[n.jsx("rect",{x:"5",y:"10",width:"14",height:"11",rx:"3"}),n.jsx("path",{d:"M8 10V7a4 4 0 0 1 8 0v3M12 14v3"})]})}),n.jsx("span",{className:"login-eyebrow",children:"STAFF & ADMIN"}),n.jsx("h2",{id:"staff-login-title",children:"Welcome back"}),n.jsx("p",{className:"login-subtitle",children:"Sign in to manage your store."}),e,n.jsx("p",{className:"login-footnote",children:"Authorized store personnel only."})]})]})})}function pr({page:e,data:t,loading:s,busy:p,error:g,navigate:d,logout:m,refresh:v,actions:o,editProduct:i,details:h,settings:j,saveRecommendations:T,changeProduct:I,deleteProduct:U}){var En,An,Cn,Nn,Pn,zn;const N=u.useMemo(()=>lr(e),[e]),C=u.useRef(null),[b,E]=u.useState({}),[x,l]=u.useState(null),[A,O]=u.useState(""),[y,F]=u.useState(e==="queuing"?"active":"all"),[D,hn]=u.useState("oldest"),[Q,xn]=u.useState("All Categories"),[X,fn]=u.useState("All Status"),[c,w]=u.useState(1),[L,K]=u.useState(null),[nn,bn]=u.useState(""),[qn,Bn]=u.useState("");u.useLayoutEffect(()=>{var un,Tn;const r=C.current,a={};r.querySelectorAll("[id], canvas, .card-number, .card-change, .payment-value, .donut-number, .status-item strong, .chart-container, .donut-wrapper").forEach((k,J)=>{k.id&&(a[k.id]=k)}),e==="dashboard"&&(a.dashboardRows=r.querySelector("tbody"),a.dashboardCards=[...r.querySelectorAll(".card-number")],a.dashboardChanges=[...r.querySelectorAll(".card-change")],a.dashboardPayments=[...r.querySelectorAll(".payment-value")],a.dashboardStatuses=[...r.querySelectorAll(".status-item strong")],a.salesChart=(un=r.querySelector("#salesChart"))==null?void 0:un.parentElement,a.orderChart=(Tn=r.querySelector("#orderChart"))==null?void 0:Tn.parentElement,a.lowStock=r.querySelector(".stock-list"),a.topProducts=r.querySelector(".product-list"));const V=r.querySelector("main, .main, .content"),f=document.createElement("div");f.className="api-notices",V.prepend(f),a.notices=f,a.allBodies=[...r.querySelectorAll("tbody")],Object.values(a).flat().filter(k=>k instanceof HTMLElement&&k!==a.refresh).forEach(k=>{(k.tagName==="TBODY"||["ordersList","productsList","productList","triggerList","productGrid","general"].includes(k.id))&&k.replaceChildren()}),a.salesChart&&a.salesChart.replaceChildren(),a.orderChart&&a.orderChart.replaceChildren(),a.lowStock&&a.lowStock.replaceChildren(),a.topProducts&&a.topProducts.replaceChildren(),r.querySelectorAll(".summary-value, .summary-number, .summary-card .number, .summary-card strong, .card-number, .card-change, .payment-value, .status-item strong, #paginationInfo, #showingText, #orderCount, #queueFooter, #customerCount, #pagination, #categoryFilter, #recommendationText, #currentTrigger").forEach(k=>k.replaceChildren()),E(a);const S=k=>{var On;const J=k.target.closest("a");if(J){const q=J.getAttribute("href");q!=null&&q.startsWith("/admin/")?(k.preventDefault(),d(q.split("/").at(-1))):q==="#sign-out"&&(k.preventDefault(),m())}const G=k.target.closest("button");if(!G)return;const mn=G.dataset.originalAction||"";if(mn.includes("toggleFilter")){const q=r.querySelector("#filterDropdown");q&&(q.style.display=q.style.display==="block"?"none":"block")}else if(mn.includes("filterPayments")){const q=((On=mn.match(/'([^']+)'/))==null?void 0:On[1])||"all";F(q),w(1);const Rn=r.querySelector("#filterDropdown");Rn&&(Rn.style.display="none")}else if(G.id==="clearSearch"){const q=r.querySelector("#customerSearch");q.value="",O("")}else G.dataset.status?(F(G.dataset.status==="All Orders"?"all":G.dataset.status),w(1)):(/open.*(?:add|product).*modal|openModal\(|openAdd|addProduct/i.test(mn)||G.id==="addProductButton")&&i({})},R=k=>{if(["customerSearch","searchInput","queueSearch"].includes(k.target.id)&&(O(k.target.value),w(1)),k.target.id==="productSearch"&&Bn(k.target.value),k.target.id==="dateFilter"&&(bn(k.target.value),w(1)),k.target.id==="statusFilter"){const J=k.target.value;F(J),fn(J),w(1)}k.target.id==="categoryFilter"&&(xn(k.target.value),w(1)),k.target.id==="sortBy"&&hn(k.target.value)};return r.addEventListener("click",S),r.addEventListener("input",R),r.addEventListener("change",R),()=>{r.removeEventListener("click",S),r.removeEventListener("input",R),r.removeEventListener("change",R)}},[e]);const z=(t==null?void 0:t.orders)||[],M=(t==null?void 0:t.products)||[],rn=((En=t==null?void 0:t.store)==null?void 0:En.low_stock_threshold)??10,$=z.filter(r=>r.payment_status==="Paid"),ln=z.filter(r=>!Dn(r)),vn=A.trim().toLowerCase();let H=z.filter(r=>`${r.order_number} ${r.customer_name}`.toLowerCase().includes(vn));(e==="queuing"||e==="orders")&&(H=H.filter(r=>["all","All","All Orders",""].includes(y)||(y==="active"?!Dn(r):r.order_status===y))),(e==="payments"||e==="receipt-records")&&(H=H.filter(r=>["all","All","All Status",""].includes(y)||r.payment_status.toLowerCase()===y.toLowerCase()||y==="cancelled"&&r.order_status==="Cancelled")),nn&&(H=H.filter(r=>{const a=new Intl.DateTimeFormat("en",{year:"numeric",month:"2-digit",day:"2-digit",timeZone:"Asia/Manila"}).formatToParts(new Date(r.paid_at||r.created_at)),V=f=>a.find(S=>S.type===f).value;return`${V("year")}-${V("month")}-${V("day")}`===nn})),D==="newest"&&(H=[...H].reverse()),D==="customer"&&H.sort((r,a)=>r.customer_name.localeCompare(a.customer_name)),D==="amount"&&H.sort((r,a)=>a.total-r.total);const cn=new Map;z.forEach(r=>{const a=cn.get(r.mobile_number)||{name:r.customer_name,mobile:r.mobile_number,address:"",orders:[],spent:0};a.name=r.customer_name,a.address=r.address||a.address,a.orders.push(r),r.payment_status==="Paid"&&(a.spent+=r.total),cn.set(r.mobile_number,a)});const Un=[...cn.values()].filter(r=>`${r.name} ${r.mobile} ${r.address}`.toLowerCase().includes(vn)),yn=r=>r.is_active?r.stock===0?"Out of Stock":r.stock<=rn?"Low Stock":"In Stock":"Archived",Fn=M.filter(r=>`${r.name} ${r.sku}`.toLowerCase().includes(vn)&&(["All Categories","All","all",""].includes(Q)||r.category===Q)&&(["All Status","All","all",""].includes(X)||yn(r)===X)),en=10,W=e==="customers"?Un:e==="products"?Fn:H,wn=Math.max(1,Math.ceil(W.length/en)),Y=Math.min(c,wn),kn=W.slice((Y-1)*en,Y*en),Hn=e==="customers"?kn:[],Sn=["orders","queuing","payments","receipt-records"].includes(e)?kn:[],Z=[],P=(r,a)=>{b[r]&&Z.push(an.createPortal(typeof a=="number"?String(a):a,b[r],r))},tn=r=>n.jsx("span",{className:`status status-badge ${r==="Processing"?"processing":r.startsWith("Ready")?"ready":r.toLowerCase()}`,children:r});P("notices",n.jsxs(n.Fragment,{children:[g&&n.jsxs("div",{className:"error",role:"alert",children:[g," ",n.jsx("button",{onClick:v,disabled:s||p,children:"Retry"})]}),s&&n.jsx("p",{role:"status",children:"Loading store data…"})]}));const pn=r=>Object.keys(r.ml_recommendation_scores||{}).length?Object.keys(r.ml_recommendation_scores).map(Number):r.recommended_product_ids||[],$n={totalCustomers:cn.size,totalOrders:z.length,totalSales:B($.reduce((r,a)=>r+a.total,0)),activeCustomers:new Set(ln.map(r=>r.mobile_number)).size,activeCount:ln.length,pendingCount:z.filter(r=>r.order_status==="Pending").length,nextOrder:((An=ln[0])==null?void 0:An.order_number)||"—",totalProducts:M.length,inStockCount:M.filter(r=>r.stock>rn&&r.is_active).length,lowStockCount:M.filter(r=>r.stock>0&&r.stock<=rn&&r.is_active).length,outStockCount:M.filter(r=>r.stock===0&&r.is_active).length,totalPayments:z.length,paidCount:$.length,unpaidCount:z.filter(r=>r.payment_status==="Unpaid"&&r.order_status!=="Cancelled").length,cancelledCount:z.filter(r=>r.order_status==="Cancelled").length,totalAmount:B(z.reduce((r,a)=>r+a.total,0)),paidOrders:$.length,unpaidOrders:z.filter(r=>r.payment_status==="Unpaid"&&r.order_status!=="Cancelled").length,triggerCount:M.filter(r=>pn(r).length).length,recommendationCount:new Set(M.flatMap(pn)).size,linkCount:M.reduce((r,a)=>r+pn(a).length,0)};Object.entries($n).forEach(([r,a])=>P(r,a)),P("categoryFilter",n.jsxs(n.Fragment,{children:[n.jsx("option",{children:"All Categories"}),[...new Set(M.map(r=>r.category))].sort().map(r=>n.jsx("option",{children:r},r))]})),P("customerTable",Hn.map(r=>n.jsxs("tr",{children:[n.jsx("td",{className:"customer-name",children:r.name}),n.jsx("td",{children:r.mobile}),n.jsx("td",{children:r.address||"Store pickup"}),n.jsx("td",{children:r.orders.length}),n.jsx("td",{children:B(r.spent)}),n.jsx("td",{children:on(r.orders.at(-1).created_at)}),n.jsx("td",{children:n.jsx("button",{className:"history-btn",onClick:()=>K(r),children:"View History"})})]},r.mobile))),P("queueRows",Sn.map(r=>n.jsxs("tr",{children:[n.jsx("td",{className:"position",children:r.queue_position?`#${r.queue_position}`:"—"}),n.jsx("td",{className:"order-id",children:r.order_number}),n.jsx("td",{className:"customer-name",children:r.customer_name}),n.jsx("td",{className:"order-time",children:on(r.created_at)}),n.jsx("td",{children:tn(r.order_status)}),n.jsx("td",{className:"total",children:B(r.total)})]},r.order_number))),P("ordersList",Sn.map(r=>n.jsxs("div",{className:"order-row",children:[n.jsxs("div",{className:"order-id",title:r.order_number,children:[n.jsx("span",{className:"order-code-prefix",children:"ELEE-"}),n.jsx("span",{className:"order-code-value",children:r.order_number.replace(/^ELEE-/,"")})]}),n.jsx("div",{children:r.customer_name}),n.jsx("div",{children:tn(r.order_status)}),n.jsx("div",{children:B(r.total)}),n.jsx("div",{children:on(r.created_at)}),n.jsx("div",{children:o(r)})]},r.order_number))),P("productList",(r=>r.map(a=>n.jsxs("div",{className:"product-row",children:[n.jsx("div",{className:"product-image",children:a.image_url?n.jsx("img",{src:a.image_url,alt:a.name}):n.jsx("span",{className:"api-product-icon",children:"◇"})}),n.jsx("div",{className:"product-name",children:a.name}),n.jsx("div",{children:a.category}),n.jsx("div",{children:B(a.price)}),n.jsx("div",{children:a.stock}),n.jsx("div",{children:a.unit}),n.jsx("div",{children:tn(a.is_active?yn(a):"Archived")}),n.jsxs("div",{className:"product-actions",children:[n.jsx("button",{className:"edit-btn",disabled:p,onClick:()=>i(a),children:"Edit"}),n.jsx("button",{className:"product-archive",disabled:p,onClick:()=>{confirm(a.is_active?`Archive ${a.name}? It will be hidden from customers. Past orders are kept.`:`Restore ${a.name} to the customer catalog?`)&&I(a.id,{is_active:!a.is_active})},children:a.is_active?"Archive":"Restore"}),a.can_delete&&n.jsx("button",{className:"product-delete",disabled:p,onClick:()=>{confirm(`Permanently delete ${a.name}? This cannot be undone.`)&&U(a.id)},children:"Delete"})]})]},a.id)))(e==="products"?kn:[])),P("productsList",M.filter(r=>`${r.name} ${r.sku}`.toLowerCase().includes(qn.trim().toLowerCase())).map(r=>n.jsxs("div",{className:"product-row",children:[n.jsx("div",{className:"product-name",children:r.name}),n.jsx("div",{children:B(r.price)}),n.jsx("div",{children:r.unit}),n.jsx("div",{children:r.category}),n.jsx("div",{children:r.stock}),n.jsx("div",{children:yn(r)}),n.jsx("div",{children:n.jsx("button",{onClick:()=>i(r),children:"Edit"})})]},r.id))),["paymentBody","receiptTableBody"].forEach(r=>P(r,Sn.map(a=>n.jsxs("tr",{children:[n.jsx("td",{children:a.order_number}),n.jsx("td",{children:a.order_number}),n.jsx("td",{children:a.customer_name}),n.jsx("td",{children:B(a.total)}),n.jsx("td",{children:a.payment_method==="cash_at_store"?"Cash at Store":"Cash on Delivery"}),n.jsx("td",{children:tn(a.payment_status)}),n.jsx("td",{children:on(a.paid_at||a.created_at)}),n.jsx("td",{children:o(a)})]},a.order_number))));const Yn=`Showing ${W.length?(Y-1)*en+1:0} to ${Math.min(Y*en,W.length)} of ${W.length}`;if(["paginationInfo","showingText","orderCount","queueFooter","customerCount"].forEach(r=>P(r,Yn)),P("pagination",n.jsxs(n.Fragment,{children:[n.jsx("button",{disabled:Y<=1,onClick:()=>w(Y-1),children:"‹"}),n.jsxs("span",{className:"api-page-number",children:[Y," / ",wn]}),n.jsx("button",{disabled:Y>=wn,onClick:()=>w(Y+1),children:"›"})]})),P("general",j),e==="dashboard"){[z.length,z.filter(f=>f.order_status==="Pending").length,B($.reduce((f,S)=>f+S.total,0)),M.filter(f=>f.is_active&&f.stock<=rn).length].forEach((f,S)=>{var R;(R=b.dashboardCards)!=null&&R[S]&&Z.push(an.createPortal(String(f),b.dashboardCards[S],`metric-${S}`))}),(Cn=b.dashboardChanges)==null||Cn.forEach((f,S)=>Z.push(an.createPortal(S===1?`${z.length?Math.round(ln.length/z.length*100):0}% active orders`:"From recorded orders",f,`change-${S}`))),(Nn=b.dashboardStatuses)==null||Nn.forEach((f,S)=>Z.push(an.createPortal(String(z.filter(R=>S===3?R.order_status.startsWith("Ready"):R.order_status===["Completed","Pending","Processing"][S]).length),f,`status-${S}`))),(Pn=b.dashboardPayments)==null||Pn.forEach((f,S)=>Z.push(an.createPortal(S===0?`${$.length} Orders`:S===1?`${z.length-$.length} Orders`:B((S===2?$:z.filter(R=>R.payment_status!=="Paid")).reduce((R,un)=>R+un.total,0)),f,`payment-${S}`))),P("dashboardRows",z.slice(-3).reverse().map(f=>n.jsxs("tr",{children:[n.jsx("td",{children:n.jsx("button",{className:"text-button",onClick:()=>h(f),children:f.order_number})}),n.jsx("td",{children:f.customer_name}),n.jsx("td",{children:on(f.created_at)}),n.jsx("td",{children:tn(f.order_status)}),n.jsx("td",{children:B(f.total)})]},f.order_number))),P("salesChart",n.jsx(sr,{orders:$})),P("orderChart",n.jsxs("div",{className:"api-donut",children:[n.jsx("strong",{children:z.length}),n.jsx("span",{children:"Total Orders"})]}));const r=M.filter(f=>f.is_active&&f.stock<=rn);P("lowStock",r.length?r.map(f=>n.jsxs("div",{className:"stock-item",children:[n.jsx("div",{className:"stock-image",children:"◇"}),n.jsxs("div",{className:"stock-info",children:[n.jsx("div",{className:"stock-name",children:f.name}),n.jsx("div",{className:"stock-description",children:f.category})]}),n.jsxs("div",{className:"stock-number",children:[n.jsx("div",{className:"stock-quantity",children:f.stock}),n.jsxs("div",{className:"stock-label",children:[f.unit," left"]})]})]},f.id)):n.jsx("p",{children:"No products need restocking."}));const a=new Map,V=Date.now()-10080*60*1e3;$.filter(f=>new Date(f.paid_at||f.created_at).getTime()>=V).forEach(f=>f.items.forEach(S=>{const R=a.get(S.product_id)||{...S,quantity:0};R.quantity+=S.quantity,a.set(S.product_id,R)})),P("topProducts",a.size?[...a.values()].sort((f,S)=>S.quantity-f.quantity).slice(0,3).map(f=>n.jsxs("div",{className:"product",children:[n.jsx("div",{className:"product-image",children:"◇"}),n.jsxs("div",{className:"product-info",children:[n.jsx("div",{className:"product-name",children:f.name}),n.jsxs("div",{className:"product-price",children:[B(f.price)," / ",f.unit]})]}),n.jsxs("div",{className:"product-sales",children:[n.jsx("div",{className:"sales-number",children:f.quantity}),n.jsx("div",{className:"sold",children:"sold"})]})]},f.product_id)):n.jsx("p",{children:"No paid sales this week."}))}if(e==="ai-recommendations"){const r=M.find(a=>a.id===x);P("triggerList",M.filter(a=>a.name.toLowerCase().includes(A.toLowerCase())).map(a=>n.jsxs("button",{className:`trigger-item ${x===a.id?"active":""}`,onClick:()=>l(a.id),children:[a.name," ",n.jsxs("small",{children:["(",pn(a).length,")"]})]},a.id))),P("productGrid",r?n.jsx(or,{product:r,products:M,save:T,busy:p},r.id+JSON.stringify(r.recommended_product_ids)):n.jsx("p",{children:"Select a trigger product to choose its related products."})),P("recommendationText","Select a product to inspect its automatically learned customer suggestions."),P("currentTrigger",(r==null?void 0:r.name)||"No trigger selected")}return u.useLayoutEffect(()=>{C.current&&(C.current.querySelectorAll("#emptyState, #queueEmpty, #noResults").forEach(r=>{r.style.display=W.length?"none":"block"}),C.current.querySelectorAll(".tab[data-status]").forEach(r=>{const a=r.dataset.status===y||r.dataset.status==="All Orders"&&y==="all";r.classList.toggle("active",a),r.setAttribute("aria-pressed",String(a))}),C.current.querySelectorAll('a[href="/admin/settings"]').forEach(r=>{var a;r.style.display=((a=t==null?void 0:t.account)==null?void 0:a.is_admin)===!1?"none":""}))},[W.length,y,s,p,b,(zn=t==null?void 0:t.account)==null?void 0:zn.is_admin]),n.jsxs("div",{className:`legacy-screen restored-page page-${e}`,children:[n.jsx("style",{children:N.css}),n.jsx("style",{children:ar}),n.jsx("div",{ref:C,dangerouslySetInnerHTML:{__html:N.html}}),Z,L&&n.jsx("div",{className:"api-history-backdrop",children:n.jsxs("section",{className:"api-history-dialog",role:"dialog","aria-modal":"true",children:[n.jsx("h2",{children:"Customer Details"}),n.jsxs("p",{children:[L.name," · ",L.mobile]}),n.jsx("p",{children:L.address||"Store pickup"}),n.jsxs("table",{children:[n.jsx("thead",{children:n.jsxs("tr",{children:[n.jsx("th",{children:"Order"}),n.jsx("th",{children:"Status"}),n.jsx("th",{children:"Total"})]})}),n.jsx("tbody",{children:L.orders.map(r=>n.jsxs("tr",{children:[n.jsx("td",{children:r.order_number}),n.jsx("td",{children:r.order_status}),n.jsx("td",{children:B(r.total)})]},r.order_number))})]}),n.jsx("button",{onClick:()=>K(null),children:"Close"})]})})]})}function ur(e=()=>{const t=window.AudioContext||window.webkitAudioContext;return t?new t:null}){let t;return{async unlock(){try{return t||(t=e()),(t==null?void 0:t.state)==="suspended"&&await t.resume(),(t==null?void 0:t.state)==="running"}catch{return!1}},play(){if((t==null?void 0:t.state)!=="running")return!1;try{const s=t.currentTime;return[660,880].forEach((p,g)=>{const d=t.createOscillator(),m=t.createGain(),v=s+g*.16;d.type="sine",d.frequency.value=p,m.gain.setValueAtTime(0,v),m.gain.linearRampToValueAtTime(.12,v+.015),m.gain.exponentialRampToValueAtTime(.001,v+.3),d.connect(m),m.connect(t.destination),d.start(v),d.stop(v+.32),d.onended=()=>{d.disconnect(),m.disconnect()}}),!0}catch{return!1}}}}const sn=ur(),Mn=[["store","Store Information"],["orders","Order Settings"],["notifications","Notifications"],["account","Admin Account"]],In=[["notify_new_orders","New Orders"],["notify_order_changes","Order Changes"],["notify_cancellations","Cancellations"],["notify_low_stock","Low Stock"]];function mr({api:e}){const[t,s]=u.useState(null),[p,g]=u.useState("store"),[d,m]=u.useState(!1),[v,o]=u.useState(""),[i,h]=u.useState(""),[j,T]=u.useState(0);async function I(){try{const[b,E]=await Promise.all([e.request("staff/me"),e.request("staff/settings")]);s({account:b,store:E})}catch(b){o(b.message)}}u.useEffect(()=>{I()},[]);async function U(b){b.preventDefault();const E=new FormData(b.currentTarget);let x=Object.fromEntries(E);p==="orders"&&(x={delivery_fee_centavos:Math.round(Number(E.get("fee"))*100),pickup_enabled:E.has("pickup_enabled"),delivery_enabled:E.has("delivery_enabled")}),p==="notifications"&&(x={...Object.fromEntries(In.map(([l])=>[l,E.has(l)])),low_stock_threshold:Number(E.get("low_stock_threshold"))}),p==="account"&&!x.password&&(delete x.password,delete x.password_confirmation),m(!0),o(""),h("");try{await e.request(p==="account"?"staff/account":"staff/settings",{method:"PATCH",body:x}),await I(),T(l=>l+1),h("Changes saved.")}catch(l){o(l.message)}finally{m(!1)}}const N=(b,E,x={})=>n.jsxs("label",{children:[E,n.jsx("input",{name:b,defaultValue:t.store[b]??"",...x})]}),C=(b,E,x)=>n.jsxs("label",{className:"settings-toggle",children:[n.jsxs("span",{children:[n.jsx("strong",{children:E}),n.jsx("small",{children:x})]}),n.jsx("input",{name:b,type:"checkbox",defaultChecked:t.store[b]})]});return n.jsxs("div",{className:"connected-settings",children:[n.jsx("nav",{className:"settings-tabs","aria-label":"Settings sections",children:Mn.map(([b,E])=>n.jsx("button",{type:"button",className:p===b?"active":"","aria-pressed":p===b,disabled:d,onClick:()=>{g(b),o(""),h("")},children:E},b))}),n.jsxs("section",{className:"settings-card",children:[v&&n.jsx("p",{className:"error",role:"alert",children:v}),i&&n.jsx("p",{className:"settings-success",role:"status",children:i}),t?n.jsxs("form",{onSubmit:U,children:[n.jsx("h2",{children:Mn.find(([b])=>b===p)[1]}),p==="store"&&n.jsxs(n.Fragment,{children:[n.jsx("p",{className:"settings-help",children:"Contact details and pickup information."}),n.jsxs("div",{className:"settings-grid",children:[N("store_name","Store name",{required:!0,maxLength:255}),N("store_phone","Contact number",{type:"tel",maxLength:50})]}),N("store_address","Store address",{maxLength:2e3}),N("store_hours","Store hours",{maxLength:500,placeholder:"Monday–Saturday, 8 AM–5 PM"})]}),p==="orders"&&n.jsxs(n.Fragment,{children:[n.jsx("p",{className:"settings-help",children:"Applies to new orders. Existing orders retain their original fees. Sunday orders are accepted for Monday delivery; no deliveries on Sunday."}),C("pickup_enabled","Store Pickup","Accept orders for collection at the store."),C("delivery_enabled","Delivery","Accept delivery orders."),n.jsxs("label",{children:["Delivery fee (PHP)",n.jsx("input",{name:"fee",type:"number",min:"0",max:"1000000",step:"0.01",defaultValue:t.store.delivery_fee_centavos/100,required:!0})]})]}),p==="notifications"&&n.jsxs(n.Fragment,{children:[n.jsx("p",{className:"settings-help",children:"Show alerts while the admin website is open."}),In.map(([b,E])=>n.jsx(Wn.Fragment,{children:C(b,E,"Show this alert in the admin website.")},b)),N("low_stock_threshold","Low stock threshold",{type:"number",min:0,max:1e6,required:!0})]}),p==="account"&&n.jsxs(n.Fragment,{children:[n.jsx("p",{className:"settings-help",children:"Enter your current password to save changes."}),n.jsxs("div",{className:"settings-grid",children:[n.jsxs("label",{children:["Name",n.jsx("input",{name:"name",defaultValue:t.account.name,maxLength:255,required:!0})]}),n.jsxs("label",{children:["Email",n.jsx("input",{name:"email",type:"email",defaultValue:t.account.email,required:!0})]})]}),n.jsxs("label",{children:["Current password",n.jsx("input",{name:"current_password",type:"password",autoComplete:"current-password",required:!0})]}),n.jsxs("div",{className:"settings-grid",children:[n.jsxs("label",{children:["New password (optional)",n.jsx("input",{name:"password",type:"password",autoComplete:"new-password",minLength:12})]}),n.jsxs("label",{children:["Confirm new password",n.jsx("input",{name:"password_confirmation",type:"password",autoComplete:"new-password",minLength:12})]})]}),n.jsx("p",{className:"settings-help",children:"At least 12 characters. Leave blank to keep your password."})]}),n.jsx("div",{className:"settings-footer",children:n.jsx("button",{disabled:d,children:d?"Saving…":"Save changes"})})]},p+j+JSON.stringify(t)):n.jsx("p",{children:v?n.jsx("button",{onClick:I,children:"Retry"}):"Loading settings…"})]})]})}function gr({api:e,data:t}){const[s,p]=u.useState(null),[g,d]=u.useState([]),[m,v]=u.useState(""),[o,i]=u.useState(!1),h=u.useRef(null),[j,T]=u.useState(()=>{try{return localStorage.getItem("elee.alert-sound")!=="off"}catch{return!0}}),[I,U]=u.useState(!1),N=u.useRef(null);if(u.useEffect(()=>{const l=()=>{sn.unlock().then(U)};return window.addEventListener("pointerdown",l,{once:!0}),window.addEventListener("keydown",l,{once:!0}),()=>{window.removeEventListener("pointerdown",l),window.removeEventListener("keydown",l)}},[]),u.useEffect(()=>{let l=!0;const A=()=>e.request("staff/settings").then(y=>{l&&p(y)}).catch(()=>{});A();const O=setInterval(A,1e4);return()=>{l=!1,clearInterval(O)}},[]),u.useEffect(()=>{if(!t||!s)return;const l=h.current,A=[];l&&t.orders.forEach(y=>{const F=l.get(y.order_number);!F&&s.notify_new_orders?A.push({id:`${y.order_number}-new`,title:"New order received",body:y.customer_name,detail:y.order_number}):F&&F!==y.order_status&&(y.order_status==="Cancelled"?s.notify_cancellations:s.notify_order_changes)&&A.push({id:`${y.order_number}-${y.order_status}`,title:y.order_status==="Cancelled"?"Order cancelled":"Order updated",body:`${y.customer_name} · ${y.order_status}`,detail:y.order_number})}),h.current=new Map(t.orders.map(y=>[y.order_number,y.order_status])),A.length&&(d(y=>[...A,...y.filter(F=>!A.some(D=>D.id===F.id))].slice(0,3)),j&&sn.play());const O=s.notify_low_stock?t.products.filter(y=>y.is_active&&y.stock<=s.low_stock_threshold).map(y=>`${y.id}:${y.stock}`).join("|"):"";O&&N.current!==null&&O!==N.current&&!A.length&&j&&sn.play(),N.current=O},[t,s,j]),u.useEffect(()=>{if(!g.length)return;const l=setTimeout(()=>d([]),1e4);return()=>clearTimeout(l)},[g]),!s)return null;const C=s.notify_low_stock?t.products.filter(l=>l.is_active&&l.stock<=s.low_stock_threshold):[],b=C.map(l=>`${l.id}:${l.stock}`).join("|"),E=C.length>0&&b!==m,x=n.jsx("svg",{width:"19",height:"19",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.7","aria-hidden":"true",children:n.jsx("path",{d:"M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"})});return n.jsxs(n.Fragment,{children:[n.jsx("button",{className:"notification-sound-toggle",title:j&&I?"Mute notification sound":"Enable notification sound",onClick:async()=>{const l=!j||!I;T(l);try{localStorage.setItem("elee.alert-sound",l?"on":"off")}catch{}if(l){const A=await sn.unlock();U(A),A&&sn.play()}},children:j&&I?"♪ Sound on":"♪ Enable sound"}),g.length||E?n.jsxs("aside",{className:"notification-stack","aria-label":"Store notifications","aria-live":"polite",children:[g.map(l=>n.jsxs("section",{className:"notification-toast",children:[n.jsx("span",{className:"notification-icon",children:x}),n.jsxs("div",{className:"notification-copy",children:[n.jsx("strong",{children:l.title}),n.jsx("p",{children:l.body}),n.jsx("small",{title:l.detail,children:l.detail})]}),n.jsx("button",{className:"notification-close","aria-label":`Dismiss ${l.title}`,onClick:()=>d(A=>A.filter(O=>O.id!==l.id)),children:"×"})]},l.id)),E&&n.jsxs("section",{className:"notification-toast stock-notification",children:[n.jsx("span",{className:"notification-icon",children:"!"}),n.jsxs("div",{className:"notification-copy",children:[n.jsx("strong",{children:"Stock needs attention"}),n.jsxs("p",{children:[C.length," ",C.length===1?"product is":"products are"," running low."]}),n.jsx("button",{className:"notification-details","aria-expanded":o,onClick:()=>i(l=>!l),children:o?"Hide products":"View products"}),o&&n.jsxs("ul",{children:[C.slice(0,5).map(l=>n.jsxs("li",{children:[l.name,n.jsxs("span",{children:[l.stock," ",l.unit]})]},l.id)),C.length>5&&n.jsxs("li",{children:["+",C.length-5," more in Products"]})]})]}),n.jsx("button",{className:"notification-close","aria-label":"Dismiss low stock notification",onClick:()=>{v(b),i(!1)},children:"×"})]})]}):null]})}function hr({api:e}){const[t,s]=u.useState(null),[p,g]=u.useState(!1),[d,m]=u.useState("");async function v(){try{s(await e.request("staff/recommendation-model")),m("")}catch(o){m(o.message)}}return u.useEffect(()=>{v();const o=setInterval(v,1e4);return()=>clearInterval(o)},[]),n.jsxs("section",{className:"model-training compact-model","aria-label":"AI recommendation status",children:[n.jsxs("div",{className:"model-status-bar",children:[n.jsxs("div",{className:"model-status-copy",children:[n.jsx("span",{className:`model-status-dot ${t!=null&&t.trained?"is-active":""}`,"aria-hidden":"true"}),n.jsxs("div",{children:[n.jsx("h2",{children:t?t.trained?"AI recommendations active":"AI is learning":"Checking AI status…"}),n.jsx("p",{children:t!=null&&t.trained?"Suggestions update automatically from completed orders.":"More completed orders are needed. Related products are used for now."})]})]}),(t==null?void 0:t.trained_at)&&n.jsxs("span",{className:"model-updated",children:["Updated ",new Date(t.trained_at).toLocaleString("en-PH",{month:"short",day:"numeric",hour:"numeric",minute:"2-digit",timeZone:"Asia/Manila"})]})]}),d&&n.jsx("p",{role:"alert",className:"error",children:d}),n.jsxs("details",{className:"model-details",children:[n.jsx("summary",{children:"Model details"}),n.jsxs("div",{className:"model-details-content",children:[t&&n.jsxs("dl",{className:"model-metrics",children:[n.jsxs("div",{children:[n.jsx("dt",{children:"Training orders"}),n.jsx("dd",{children:t.training_orders})]}),n.jsxs("div",{children:[n.jsx("dt",{children:"Products learned"}),n.jsx("dd",{children:t.training_products})]}),n.jsxs("div",{children:[n.jsx("dt",{children:"New orders"}),n.jsx("dd",{children:t.new_orders})]})]}),n.jsx("p",{children:"Item-item collaborative filtering · Automatically retrains after paid, completed orders."}),n.jsx("button",{disabled:p,onClick:async()=>{g(!0),m("");try{s(await e.request("staff/recommendation-model/train",{method:"POST"}))}catch(o){m(o.message)}finally{g(!1)}},children:p?"Training…":"Train / Retrain model"}),(t==null?void 0:t.trained)&&t.limited_data&&n.jsx("p",{role:"status",children:"Limited training data: suggestions are learned from a small order history and may change as more orders are completed."}),n.jsx("p",{children:"Manual retraining is optional. Initial training needs 3 eligible orders, including products bought together."})]})]})]})}const _=Gn(),jn=e=>new Intl.NumberFormat("en-PH",{style:"currency",currency:"PHP"}).format(e),Ln=[["dashboard","Dashboard"],["orders","Orders"],["products","Products"],["queuing","Order Queue"],["payments","Payments"],["customers","Customers"],["receipt-records","Receipt Records"],["ai-recommendations","Recommendations"],["settings","Settings"]],dn=e=>e.queue_position!==null;function xr({onLogin:e}){const[t,s]=u.useState(""),[p,g]=u.useState(!1),[d,m]=u.useState(!1);async function v(o){o.preventDefault();const i=new FormData(o.currentTarget);g(!0),s("");try{await _.login(i.get("email"),i.get("password")),e()}catch(h){s(h.message)}finally{g(!1)}}return n.jsx(cr,{children:n.jsxs("form",{onSubmit:v,"aria-busy":p,children:[t&&n.jsx("p",{className:"error",role:"alert",children:t}),n.jsx("div",{className:"form-group",children:n.jsxs("label",{children:["Email",n.jsx("input",{name:"email",type:"email",autoComplete:"username",required:!0})]})}),n.jsx("div",{className:"form-group",children:n.jsxs("label",{children:["Password",n.jsx("input",{name:"password",type:d?"text":"password",autoComplete:"current-password",required:!0})]})}),n.jsxs("label",{className:"check",children:[n.jsx("input",{type:"checkbox",checked:d,onChange:o=>m(o.target.checked)})," Show password"]}),n.jsxs("button",{className:"login-btn",disabled:p,children:[p&&n.jsx("span",{className:"login-spinner","aria-hidden":"true"}),p?"Signing in…":"Sign in"]})]})})}function fr(){const[e,t]=u.useState(""),[s,p]=u.useState(!1),[g,d]=u.useState(!1),[m,v]=u.useState(!1);async function o(i){i.preventDefault();const h=new FormData(i.currentTarget),j=new URLSearchParams(location.search);p(!0),t("");try{await _.request("admin/reset-password",{method:"POST",token:null,body:{email:j.get("email"),token:j.get("token"),password:h.get("password"),password_confirmation:h.get("password_confirmation")}}),_.forget(),d(!0),history.replaceState(null,"","/admin/reset-password")}catch(T){t(T.message)}finally{p(!1)}}return n.jsx("main",{className:"login-page",children:n.jsxs("section",{className:"login-card",children:[n.jsxs("div",{className:"brand",children:["ELEE",n.jsx("span",{children:"HARDWARE"})]}),n.jsx("h1",{children:"Set admin password"}),e&&n.jsx("p",{className:"error",role:"alert",children:e}),g?n.jsxs(n.Fragment,{children:[n.jsx("p",{children:"Password updated."}),n.jsx("a",{href:"/admin/login",children:"Go to sign in"})]}):n.jsxs("form",{onSubmit:o,children:[n.jsxs("label",{children:["New password",n.jsx("input",{name:"password",type:m?"text":"password",minLength:12,maxLength:255,autoComplete:"new-password",required:!0})]}),n.jsxs("label",{children:["Confirm password",n.jsx("input",{name:"password_confirmation",type:m?"text":"password",minLength:12,maxLength:255,autoComplete:"new-password",required:!0})]}),n.jsxs("label",{className:"check",children:[n.jsx("input",{type:"checkbox",checked:m,onChange:i=>v(i.target.checked)})," Show password"]}),n.jsx("button",{disabled:s,children:s?"Saving…":"Save password"})]})]})})}function br({product:e,onSave:t,onClose:s,busy:p,error:g}){return n.jsx("div",{className:"modal-backdrop api-dialog-backdrop",children:n.jsxs("section",{className:"api-dialog",role:"dialog","aria-modal":"true","aria-labelledby":"product-title",children:[n.jsx("h2",{id:"product-title",children:e!=null&&e.id?"Edit product":"Add product"}),g&&n.jsx("p",{className:"error",role:"alert",children:g}),n.jsxs("form",{onSubmit:d=>{d.preventDefault();const m=new FormData(d.currentTarget);t(e==null?void 0:e.id,{sku:m.get("sku"),name:m.get("name"),category:m.get("category"),unit:m.get("unit"),price_centavos:Math.round(Number(m.get("price"))*100),stock:Number(m.get("stock")),description:m.get("description")||null,image_url:m.get("image_url")||null,is_active:m.get("is_active")==="on"})},children:[n.jsxs("div",{className:"form-grid",children:[n.jsxs("label",{children:["SKU",n.jsx("input",{name:"sku",defaultValue:(e==null?void 0:e.sku)||"",maxLength:100,required:!0})]}),n.jsxs("label",{children:["Name",n.jsx("input",{name:"name",defaultValue:(e==null?void 0:e.name)||"",maxLength:255,required:!0})]}),n.jsxs("label",{children:["Category",n.jsx("input",{name:"category",defaultValue:(e==null?void 0:e.category)||"",maxLength:100,required:!0})]}),n.jsxs("label",{children:["Unit",n.jsx("input",{name:"unit",defaultValue:(e==null?void 0:e.unit)||"",maxLength:50,required:!0})]}),n.jsxs("label",{children:["Price (PHP)",n.jsx("input",{name:"price",type:"number",min:"0.01",max:"1000000",step:"0.01",defaultValue:(e==null?void 0:e.price)??"",required:!0})]}),n.jsxs("label",{children:["Available stock",n.jsx("input",{name:"stock",type:"number",min:"0",max:"1000000",step:"1",defaultValue:(e==null?void 0:e.stock)??"",required:!0})]})]}),n.jsxs("label",{children:["Description",n.jsx("textarea",{name:"description",defaultValue:(e==null?void 0:e.description)||"",maxLength:5e3})]}),n.jsxs("label",{children:["Image URL",n.jsx("input",{name:"image_url",type:"url",defaultValue:(e==null?void 0:e.image_url)||""})]}),n.jsxs("label",{className:"check",children:[n.jsx("input",{name:"is_active",type:"checkbox",defaultChecked:(e==null?void 0:e.is_active)??!0})," Visible to customers"]}),n.jsxs("div",{className:"actions",children:[n.jsx("button",{disabled:p,children:p?"Saving…":"Save product"}),n.jsx("button",{className:"secondary",type:"button",onClick:s,disabled:p,children:"Cancel"})]})]})]})})}function vr({order:e,onClose:t}){return n.jsx("div",{className:"modal-backdrop api-dialog-backdrop",children:n.jsxs("section",{className:"api-dialog",role:"dialog","aria-modal":"true","aria-labelledby":"order-title",children:[n.jsx("h2",{id:"order-title",children:e.order_number}),n.jsxs("p",{children:[e.customer_name," · ",e.mobile_number]}),n.jsx("p",{children:e.fulfillment_method==="store_pickup"?"Store pickup":`Delivery: ${e.address}`}),n.jsxs("p",{children:[e.order_status," · Payment: ",e.payment_status]}),e.delivery_notice&&n.jsx("p",{children:e.delivery_notice}),n.jsx("div",{className:"table-wrap",children:n.jsxs("table",{children:[n.jsx("thead",{children:n.jsxs("tr",{children:[n.jsx("th",{children:"Item"}),n.jsx("th",{children:"Quantity"}),n.jsx("th",{children:"Amount"})]})}),n.jsx("tbody",{children:e.items.map(s=>n.jsxs("tr",{children:[n.jsx("td",{children:s.name}),n.jsxs("td",{children:[s.quantity," ",s.unit]}),n.jsx("td",{children:jn(s.line_total)})]},s.product_id))})]})}),n.jsxs("p",{children:["Delivery fee: ",jn(e.delivery_fee)]}),n.jsxs("strong",{children:["Total: ",jn(e.total)]}),n.jsx("div",{className:"actions",children:n.jsx("button",{onClick:t,children:"Close"})})]})})}function yr(){const e=location.pathname.split("/").filter(Boolean).at(-1),[t,s]=u.useState(Ln.some(([c])=>c===e)?e:"dashboard"),[p,g]=u.useState(_.hasToken()),[d,m]=u.useState(null),[v,o]=u.useState(!1),[i,h]=u.useState(!1),[j,T]=u.useState(""),[I,U]=u.useState(""),[N,C]=u.useState(e==="queuing"?"active":"all"),[b,E]=u.useState(null),[x,l]=u.useState(null),A=u.useRef(!1),O=u.useRef(0);async function y({background:c=!1}={}){if(c&&A.current)return;const w=++O.current;A.current=!0,c||o(!0),T("");try{const[L,K,nn,bn]=await Promise.all([_.all("staff/orders"),_.all("staff/products"),_.request("staff/me"),_.request("staff/settings")]);w===O.current&&(m({orders:L,products:K,account:nn,store:bn}),!nn.is_admin&&t==="settings"&&s("dashboard"))}catch(L){if(w!==O.current)return;T(L.message),[401,403].includes(L.status)&&(_.forget(),g(!1),m(null))}finally{w===O.current&&(A.current=!1,c||o(!1))}}u.useEffect(()=>{p&&y()},[p]),u.useEffect(()=>{if(!p||i||b||x||t==="settings")return;const c=()=>{document.visibilityState==="visible"&&y({background:!0})},w=window.setInterval(c,1e4);return window.addEventListener("focus",c),()=>{window.clearInterval(w),window.removeEventListener("focus",c)}},[p,i,b,x,t]),u.useEffect(()=>{const c=()=>{const w=location.pathname.split("/").filter(Boolean).at(-1);s(Ln.some(([L])=>L===w)?w:"dashboard")};return window.addEventListener("popstate",c),()=>window.removeEventListener("popstate",c)},[]);function F(c){s(c),U(""),C(c==="queuing"?"active":"all"),history.pushState(null,"",`/admin/${c}`)}async function D(c,w,L="PATCH"){h(!0),T("");try{return await _.request(c,{method:L,body:w}),await y(),!0}catch(K){return T(K.message),!1}finally{h(!1)}}async function hn(){O.current++,A.current=!1,h(!0);try{await _.request("staff/logout",{method:"POST"}),_.forget(),m(null),g(!1),history.replaceState(null,"","/admin/login")}catch(c){c.status===401?(_.forget(),m(null),g(!1)):T(c.message)}finally{h(!1)}}if(!p)return n.jsx(xr,{onLogin:()=>{g(!0),history.replaceState(null,"",`/admin/${t}`)}});const Q=(d==null?void 0:d.orders)||[];d!=null&&d.products,Q.filter(dn);const xn=I.trim().toLowerCase();Q.filter(c=>(N==="all"||(N==="active"?dn(c):c.order_status===N))&&`${c.order_number} ${c.customer_name}`.toLowerCase().includes(xn));const X=new Map;Q.forEach(c=>{const w=X.get(c.mobile_number)||{name:c.customer_name,mobile:c.mobile_number,count:0,total:0};w.count++,w.total+=c.total,X.set(c.mobile_number,w)});function fn(c){const w=`staff/orders/${encodeURIComponent(c.order_number)}`;return n.jsxs("div",{className:"row-actions",children:[n.jsx("button",{className:"secondary",onClick:()=>l(c),children:"Details"}),c.order_status==="Pending"&&n.jsx("button",{disabled:i||v,onClick:()=>D(`${w}/status`,{status:"Processing"}),children:"Start processing"}),c.order_status==="Processing"&&n.jsx("button",{disabled:i||v,onClick:()=>D(`${w}/status`,{status:c.fulfillment_method==="store_pickup"?"Ready for Pickup":"Ready for Delivery"}),children:"Mark ready"}),dn(c)&&c.payment_status!=="Paid"&&(c.payment_method!=="cash_on_delivery"||c.order_status==="Ready for Delivery")&&n.jsx("button",{className:"secondary",disabled:i||v,onClick:()=>{confirm(c.payment_method==="cash_on_delivery"?"Confirm this order was delivered and cash was received? This completes the order.":"Confirm cash was received at the store?")&&D(`${w}/paid`)},children:c.payment_method==="cash_on_delivery"?"Confirm delivered & paid":"Record cash received"}),dn(c)&&c.payment_status==="Paid"&&c.order_status===(c.fulfillment_method==="delivery"?"Ready for Delivery":"Ready for Pickup")&&n.jsx("button",{disabled:i||v,onClick:()=>{confirm("Confirm this order was handed to the customer?")&&D(`${w}/complete`)},children:"Complete order"}),dn(c)&&c.payment_status!=="Paid"&&n.jsx("button",{className:"danger",disabled:i||v,onClick:()=>{confirm("Cancel this order and return its stock?")&&D(`${w}/status`,{status:"Cancelled"})},children:"Cancel"})]})}return n.jsxs(n.Fragment,{children:[t==="ai-recommendations"&&n.jsx(hr,{api:_}),d&&t!=="settings"&&n.jsx(gr,{api:_,data:d}),n.jsx(pr,{page:t,data:d,loading:v,busy:i,error:j,navigate:F,logout:hn,refresh:y,actions:fn,editProduct:c=>{T(""),E(c)},details:l,settings:n.jsx(mr,{api:_}),saveRecommendations:(c,w)=>D(`staff/products/${c}/recommendations`,{recommended_product_ids:w}),changeProduct:(c,w)=>D(`staff/products/${c}`,w),deleteProduct:c=>D(`staff/products/${c}`,void 0,"DELETE")},t),b&&n.jsx(br,{product:b,busy:i,error:j,onClose:()=>E(null),onSave:async(c,w)=>{await D(c?`staff/products/${c}`:"staff/products",w,c?"PATCH":"POST")&&E(null)}}),x&&n.jsx(vr,{order:x,onClose:()=>l(null)})]})}Vn.createRoot(document.getElementById("root")).render(location.pathname==="/admin/reset-password"?n.jsx(fr,{}):n.jsx(yr,{}));

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('store_settings', fn (Blueprint $table) => $table->longText('value')->change());
    }
    public function down(): void
    {
        // Retain text storage: converting names or models to integers loses data.
    }
};

import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createApiClient } from './api-client';
import { LegacyPage, OriginalLogin } from './legacy-design';
import { StoreSettings, StoreAlerts } from './store-settings';
import { ModelTraining } from './model-training';
import '../css/live-admin.css';
import '../css/brand-theme.css';
import '../css/ui-polish.css';
import '../css/typography.css';
import '../css/notifications.css';
import '../css/search-fields.css';

const api = createApiClient();
const money = value => new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(value);
const date = value => new Intl.DateTimeFormat('en-PH', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Manila' }).format(new Date(value));
const nav = [['dashboard', 'Dashboard'], ['orders', 'Orders'], ['products', 'Products'], ['queuing', 'Order Queue'], ['payments', 'Payments'], ['customers', 'Customers'], ['receipt-records', 'Receipt Records'], ['ai-recommendations', 'Recommendations'], ['settings', 'Settings']];
const active = order => order.queue_position !== null;

function Login({ onLogin }) {
    const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    async function submit(event) {
        event.preventDefault(); const fields = new FormData(event.currentTarget); setBusy(true); setError('');
        try { await api.login(fields.get('email'), fields.get('password')); onLogin(); }
        catch (error) { setError(error.message); } finally { setBusy(false); }
    }
    return <OriginalLogin><form onSubmit={submit} aria-busy={busy}>
        {error && <p className="error" role="alert">{error}</p>}
        <div className="form-group"><label>Email<input name="email" type="email" autoComplete="username" required /></label></div>
        <div className="form-group"><label>Password<input name="password" type={showPassword ? 'text' : 'password'} autoComplete="current-password" required /></label></div>
        <label className="check"><input type="checkbox" checked={showPassword} onChange={event => setShowPassword(event.target.checked)} /> Show password</label>
        <button className="login-btn" disabled={busy}>{busy && <span className="login-spinner" aria-hidden="true"/>}{busy ? 'Signing in…' : 'Sign in'}</button>
    </form></OriginalLogin>;
}

function PasswordReset() {
    const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
    const [done, setDone] = useState(false); const [show, setShow] = useState(false);
    async function submit(event) {
        event.preventDefault(); const form = new FormData(event.currentTarget);
        const query = new URLSearchParams(location.search); setBusy(true); setError('');
        try {
            await api.request('admin/reset-password', { method: 'POST', token: null, body: {
                email: query.get('email'), token: query.get('token'), password: form.get('password'), password_confirmation: form.get('password_confirmation'),
            } });
            api.forget(); setDone(true); history.replaceState(null, '', '/admin/reset-password');
        } catch (error) { setError(error.message); } finally { setBusy(false); }
    }
    return <main className="login-page"><section className="login-card"><div className="brand">ELEE<span>HARDWARE</span></div><h1>Set admin password</h1>
        {error && <p className="error" role="alert">{error}</p>}
        {done ? <><p>Password updated.</p><a href="/admin/login">Go to sign in</a></> : <form onSubmit={submit}>
            <label>New password<input name="password" type={show ? 'text' : 'password'} minLength={12} maxLength={255} autoComplete="new-password" required /></label>
            <label>Confirm password<input name="password_confirmation" type={show ? 'text' : 'password'} minLength={12} maxLength={255} autoComplete="new-password" required /></label>
            <label className="check"><input type="checkbox" checked={show} onChange={event => setShow(event.target.checked)} /> Show password</label>
            <button disabled={busy}>{busy ? 'Saving…' : 'Save password'}</button>
        </form>}
    </section></main>;
}

function ProductForm({ product, onSave, onClose, busy, error }) {
    return <div className="modal-backdrop api-dialog-backdrop"><section className="api-dialog" role="dialog" aria-modal="true" aria-labelledby="product-title">
        <h2 id="product-title">{product?.id ? 'Edit product' : 'Add product'}</h2>
        {error && <p className="error" role="alert">{error}</p>}
        <form onSubmit={event => {
            event.preventDefault(); const fields = new FormData(event.currentTarget);
            onSave(product?.id, {
                sku: fields.get('sku'), name: fields.get('name'), category: fields.get('category'), unit: fields.get('unit'),
                price_centavos: Math.round(Number(fields.get('price')) * 100), stock: Number(fields.get('stock')),
                description: fields.get('description') || null, image_url: fields.get('image_url') || null, is_active: fields.get('is_active') === 'on',
            });
        }}>
            <div className="form-grid">
                <label>SKU<input name="sku" defaultValue={product?.sku || ''} maxLength={100} required /></label>
                <label>Name<input name="name" defaultValue={product?.name || ''} maxLength={255} required /></label>
                <label>Category<input name="category" defaultValue={product?.category || ''} maxLength={100} required /></label>
                <label>Unit<input name="unit" defaultValue={product?.unit || ''} maxLength={50} required /></label>
                <label>Price (PHP)<input name="price" type="number" min="0.01" max="1000000" step="0.01" defaultValue={product?.price ?? ''} required /></label>
                <label>Available stock<input name="stock" type="number" min="0" max="1000000" step="1" defaultValue={product?.stock ?? ''} required /></label>
            </div>
            <label>Description<textarea name="description" defaultValue={product?.description || ''} maxLength={5000} /></label>
            <label>Image URL<input name="image_url" type="url" defaultValue={product?.image_url || ''} /></label>
            <label className="check"><input name="is_active" type="checkbox" defaultChecked={product?.is_active ?? true} /> Visible to customers</label>
            <div className="actions"><button disabled={busy}>{busy ? 'Saving…' : 'Save product'}</button><button className="secondary" type="button" onClick={onClose} disabled={busy}>Cancel</button></div>
        </form>
    </section></div>;
}

function OrderDetails({ order, onClose }) {
    return <div className="modal-backdrop api-dialog-backdrop"><section className="api-dialog" role="dialog" aria-modal="true" aria-labelledby="order-title">
        <h2 id="order-title">{order.order_number}</h2><p>{order.customer_name} · {order.mobile_number}</p>
        <p>{order.fulfillment_method === 'store_pickup' ? 'Store pickup' : `Delivery: ${order.address}`}</p><p>{order.order_status} · Payment: {order.payment_status}</p>
        {order.delivery_notice && <p>{order.delivery_notice}</p>}
        <div className="table-wrap"><table><thead><tr><th>Item</th><th>Quantity</th><th>Amount</th></tr></thead><tbody>
            {order.items.map(item => <tr key={item.product_id}><td>{item.name}</td><td>{item.quantity} {item.unit}</td><td>{money(item.line_total)}</td></tr>)}
        </tbody></table></div><p>Delivery fee: {money(order.delivery_fee)}</p><strong>Total: {money(order.total)}</strong>
        <div className="actions"><button onClick={onClose}>Close</button></div>
    </section></div>;
}


function App() {
    const initial = location.pathname.split('/').filter(Boolean).at(-1);
    const [page, setPage] = useState(nav.some(([key]) => key === initial) ? initial : 'dashboard');
    const [signedIn, setSignedIn] = useState(api.hasToken()); const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
    const [search, setSearch] = useState(''); const [filter, setFilter] = useState(initial === 'queuing' ? 'active' : 'all');
    const [editing, setEditing] = useState(null); const [details, setDetails] = useState(null);
    const autoLoading = useRef(false);
    const updateVersion = useRef(0);

    async function load({ background = false } = {}) {
        if (background && autoLoading.current) return;
        const version = ++updateVersion.current;
        autoLoading.current = true;
        if (!background) setLoading(true);
        setError('');
        try { const [orders, products, account, store] = await Promise.all([api.all('staff/orders'), api.all('staff/products'), api.request('staff/me'), api.request('staff/settings')]); if (version === updateVersion.current) { setData({ orders, products, account, store }); if (!account.is_admin && page === 'settings') setPage('dashboard'); } }
        catch (error) { if (version !== updateVersion.current) return; setError(error.message); if ([401, 403].includes(error.status)) { api.forget(); setSignedIn(false); setData(null); } }
        finally { if (version === updateVersion.current) { autoLoading.current = false; if (!background) setLoading(false); } }
    }
    useEffect(() => { if (signedIn) load(); }, [signedIn]);
    useEffect(() => {
        if (!signedIn || busy || editing || details || page === 'settings') return;
        const update = () => { if (document.visibilityState === 'visible') load({ background: true }); };
        const timer = window.setInterval(update, 10000);
        window.addEventListener('focus', update);
        return () => { window.clearInterval(timer); window.removeEventListener('focus', update); };
    }, [signedIn, busy, editing, details, page]);
    useEffect(() => {
        const back = () => { const key = location.pathname.split('/').filter(Boolean).at(-1); setPage(nav.some(([name]) => name === key) ? key : 'dashboard'); };
        window.addEventListener('popstate', back); return () => window.removeEventListener('popstate', back);
    }, []);
    function navigate(key) { setPage(key); setSearch(''); setFilter(key === 'queuing' ? 'active' : 'all'); history.pushState(null, '', `/admin/${key}`); }
    async function mutate(path, body, method = 'PATCH') {
        setBusy(true); setError('');
        try { await api.request(path, { method, body }); await load(); return true; }
        catch (error) { setError(error.message); return false; } finally { setBusy(false); }
    }
    async function logout() {
        updateVersion.current++; autoLoading.current = false;
        setBusy(true);
        try { await api.request('staff/logout', { method: 'POST' }); api.forget(); setData(null); setSignedIn(false); history.replaceState(null, '', '/admin/login'); }
        catch (error) { if (error.status === 401) { api.forget(); setData(null); setSignedIn(false); } else setError(error.message); }
        finally { setBusy(false); }
    }
    if (!signedIn) return <Login onLogin={() => { setSignedIn(true); history.replaceState(null, '', `/admin/${page}`); }} />;
    const orders = data?.orders || []; const products = data?.products || []; const queue = orders.filter(active); const query = search.trim().toLowerCase();
    const visible = orders.filter(order => (filter === 'all' || (filter === 'active' ? active(order) : order.order_status === filter)) && `${order.order_number} ${order.customer_name}`.toLowerCase().includes(query));
    const customers = new Map();
    orders.forEach(order => { const customer = customers.get(order.mobile_number) || { name: order.customer_name, mobile: order.mobile_number, count: 0, total: 0 }; customer.count++; customer.total += order.total; customers.set(order.mobile_number, customer); });
    function actions(order) {
        const path = `staff/orders/${encodeURIComponent(order.order_number)}`;
        return <div className="row-actions"><button className="secondary" onClick={() => setDetails(order)}>Details</button>
            {order.order_status === 'Pending' && <button disabled={busy || loading} onClick={() => mutate(`${path}/status`, { status: 'Processing' })}>Start processing</button>}
            {order.order_status === 'Processing' && <button disabled={busy || loading} onClick={() => mutate(`${path}/status`, { status: order.fulfillment_method === 'store_pickup' ? 'Ready for Pickup' : 'Ready for Delivery' })}>Mark ready</button>}
            {active(order) && order.payment_status !== 'Paid' && (order.payment_method !== 'cash_on_delivery' || order.order_status === 'Ready for Delivery') && <button className="secondary" disabled={busy || loading} onClick={() => { if (confirm(order.payment_method === 'cash_on_delivery' ? 'Confirm this order was delivered and cash was received? This completes the order.' : 'Confirm cash was received at the store?')) mutate(`${path}/paid`); }}>{order.payment_method === 'cash_on_delivery' ? 'Confirm delivered & paid' : 'Record cash received'}</button>}
            {active(order) && order.payment_status === 'Paid' && order.order_status === (order.fulfillment_method === 'delivery' ? 'Ready for Delivery' : 'Ready for Pickup') && <button disabled={busy || loading} onClick={() => { if (confirm('Confirm this order was handed to the customer?')) mutate(`${path}/complete`); }}>Complete order</button>}
            {active(order) && order.payment_status !== 'Paid' && <button className="danger" disabled={busy || loading} onClick={() => { if (confirm('Cancel this order and return its stock?')) mutate(`${path}/status`, { status: 'Cancelled' }); }}>Cancel</button>}
        </div>;
    }
    function orderTable(rows, manage = false) {
        return <div className="table-wrap"><table><thead><tr><th>Queue</th><th>Order</th><th>Customer</th><th>Placed</th><th>Fulfillment</th><th>Status</th><th>Total</th>{manage && <th>Actions</th>}</tr></thead><tbody>{rows.map(order => <tr key={order.order_number}>
            <td className="position">{order.queue_position ? `#${order.queue_position}` : '—'}</td><td><button className="text-button" onClick={() => setDetails(order)}>{order.order_number}</button><small>{order.queue_number}</small></td><td>{order.customer_name}</td><td>{date(order.created_at)}</td><td>{order.fulfillment_method === 'store_pickup' ? 'Store pickup' : 'Delivery'}</td><td><span className="badge">{order.order_status}</span><small>{order.payment_status}</small></td><td>{money(order.total)}</td>{manage && <td>{actions(order)}</td>}
        </tr>)}</tbody></table>{rows.length === 0 && <p className="empty">No orders found.</p>}</div>;
    }
    return <>
        {page === 'ai-recommendations' && <ModelTraining api={api}/>}
        {data && page !== 'settings' && <StoreAlerts api={api} data={data} />}
        <LegacyPage key={page} page={page} data={data} loading={loading} busy={busy} error={error}
            navigate={navigate} logout={logout} refresh={load} actions={actions} editProduct={product => { setError(''); setEditing(product); }}
            details={setDetails} settings={<StoreSettings api={api} />}
            saveRecommendations={(id,ids)=>mutate(`staff/products/${id}/recommendations`,{recommended_product_ids:ids})}
            changeProduct={(id,body)=>mutate(`staff/products/${id}`,body)} deleteProduct={id=>mutate(`staff/products/${id}`,undefined,'DELETE')} />
        {editing && <ProductForm product={editing} busy={busy} error={error} onClose={() => setEditing(null)} onSave={async (id, body) => { if (await mutate(id ? `staff/products/${id}` : 'staff/products', body, id ? 'PATCH' : 'POST')) setEditing(null); }} />}
        {details && <OrderDetails order={details} onClose={() => setDetails(null)} />}
    </>;
}
createRoot(document.getElementById('root')).render(location.pathname === '/admin/reset-password' ? <PasswordReset /> : <App />);

